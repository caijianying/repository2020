

/**
 * layer提供了5种层类型。可传入的值有：0（信息框，默认）1（页面层）2（iframe层）3（加载层）4（tips层）
 */
//提示框
function alertDiag(content){
	layer.open({
		title:"提示",
		type:0,
		content:content
  	}); 
}

function alertDiag(content,okCallBack){
	layer.open({
		title:"提示",
		type:0,
		yes: function(index, layero){
			 console.log(index);
			 console.log(layero);
			 okCallBack();
   		     layer.close(index); 
   		  },
		content:content
  	}); 
}

function alertPage(title,url,okCallBack,width,height){
	console.log(width);
	console.log(height);
	if(width==undefined) width="450px";
	if(height==undefined) height="550px";
	 layui.use('form', function(){
		  var form = layui.form;
		  
		  //监听提交
		  form.on('submit(formDemo)', function(data){
		    layer.msg(JSON.stringify(data.field));
		    return false;
		  });
		  
		  layer.open({
		   	  title: title,
		   	  type:2,
//		   	  shadeClose:true,
//		   	  time:1000,可以设置自动关闭 当前为1s
		   	  area: [width, height],
		   	  yes: function(index, layero){
		   		     okCallBack();
		   		     layer.close(index); 
		   		  }
		   	  ,content:url
		   	});
        	
		  /* 渲染表单 */
        form.render();
		});
}

function alertPage1(title,eleId,okCallBack){
	
	 layui.use('form', function(){
		  var form = layui.form;
		  
		  //监听提交
		  form.on('submit(formDemo)', function(data){
		    layer.msg(JSON.stringify(data.field));
		    return false;
		  });
		  
		  layer.open({
		   	  title: title,
		   	  type:1,
		   	  shadeClose:true,
//		   	  time:1000,可以设置自动关闭 当前为1s
		   	  yes: function(index, layero){
		   		     okCallBack();
		   		     layer.close(index); 
		   		  }
		   	  ,content:$(eleId).html()
		   	});
        	
		  /* 渲染表单 */
        form.render();
		});
}
function alertMsg(content,callBack){
	layer.msg(content, {
		  icon: 1,
		  time: 2000 //2秒关闭（如果不配置，默认是3秒）
		}, function(){
			callBack();
		}); 
}

//刷新页面
function refresh(){
	window.location.reload(true);
}
