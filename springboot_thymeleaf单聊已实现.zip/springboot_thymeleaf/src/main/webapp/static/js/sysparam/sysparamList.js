var sysparamList = (function() {
	return {
		init : function(){//初始化
			//新增
			$(".a-add").click(function(){
				sysparamList.Detail(null);
			});
			
			
			// 删除按钮(删除全部)
			$('#advertising_del').click(function() {
				var $checkedIds = $("#sysParamTable input[name='ids']:enabled:checked");
				var data=$checkedIds.serialize();
				
				if(data!=null  && $.trim(data)!=""){
					delConfirmDiag(function(){
						$.post('delete',data,function(data,status,xhr){
							if(status == "success"  && data.code =="0"){
								alertDiag("操作成功! ");
								Main.dataTableExamples["sysparamList"].fnDraw(false);//刷新表格
								
							}else{
								alertDiag("操作失败! ");
							}
						},"json");
					},"删除系统参数类型","");
					
				}else{
					alertDiag("请选择需要删除的系统参数类型! ");
				}
			});
			
			sysparamList.initDataTable();
		},
		initDataTable : function(){
			
			Main.dataTableExamples["sysparamList"] =  $('#sysParamTable').dataTable( {
				ajax : {//ajax获取数据源
					url : 'listData',
					dataSrc : "data",
					type : "POST"
				}, 
				autoWidth: false,
				ordering : false,//是否开启本地排序
				rowId : "gnssDataId",
				pagingType: "bootstrap_full_number",
				searching : false,//是否开启本地搜索
				serverSide : true,//指定是否从服务器端获取  数据 
				pageLength : 10,//默认每页显示数据的条目
				bDeferRender : true,//控制表格的延迟渲染，可以提高初始化的速度。
				deferRender : true,//控制表格的延迟渲染，可以提高初始化的速度。
				processing : true,//加载数据时是否显示正在加载信息 
				fixedHeader : true,
				columns : [
					{
						data : null,
						width : "6%",
						className:"center",
						title : "<label><input class='ace group-checkable' type='checkbox'><span class='lbl'></span></label>",
						render : function(data, type, row, meta) {
							return "<label><input class='ace' name='ids' value='"+ data.id+"' type='checkbox'><span class='lbl'></span></label>";
							}
					},
					{
						data :  "paramvalue",
						className:"center",
						name : "paramvalue",
						title : "参数值",
						render : function(data, type, row,meta) {
							if(data != null)return data; 
							return ""; 
						}
					},
					{
						data : "paramcode",
						className:"center",
						name : "paramcode",
						title : "参数编码",
						render : function(data, type, row,meta) {
							if(data != null)return data; 
							return ""; 
						}
					},
					{
						data : "paramtype",
						className:"center",
						name : "paramtype",
						title : "参数类型ID",
						render : function(data, type, row,meta) {
							if(data != null)return data; 
							return ""; 
						}
					},
					{
						data : "createtime",
						className:"center",
						name : "createtime",
						title : "创建时间",
						render : function(data, type, row,meta) {
							if(data != null && data !="")return moment(new Date(data)).format("YYYY-MM-DD");
							return ""; 
						}
					},
					{
						data : "effecttime",
						className:"center",
						name : "effecttime",
						title : "生效时间",
						render : function(data, type, row,meta) {
							if(data != null && data !="")return moment(new Date(data)).format("YYYY-MM-DD");
							return ""; 
						}
					},
					{
						data : "description",
						className:"center",
						name : "description",
						title : "参数说明",
						render : function(data, type, row,meta) {
							if(data != null)return data; 
							return ""; 
						}
					},
					{
						data : null,
						title : "操作",
						className:"center",
						render : function(data, type, row, meta) {
							var info = 	'<a href="javascript:;" class="ui-pg-div color-success a-lookOver" dataId='+ data.id +' title="查看">'+
                    		'<i class="ui-icon icon-eye-open"></i></a>';
							
							info += 	'<a href="javascript:;" class="ui-pg-div a-copyreader" dataId='+ data.id +' title="编辑">'+
                        		'<i class="ui-icon icon-pencil"></i></a>';
                        	
								info += '<a href="javascript:;" class="ui-pg-div color-red dxy-remove a-delete" dataId='+ data.id +' title="删除">'+
                        			'<i class="ui-icon icon-trash"></i></a>';
							
								/*'<a href="javascript:;" dataId='+ data.id +' class="ui-pg-div bootbox-options bootbox-options"  title="回复">'+
		                       '<i class="ui-icon icon-edit"></i></a>'; */
							return info;
						}
					}
				],
				language: {//中文化
			        sProcessing: "处理中...",
			        sLengthMenu: "显示 _MENU_ 项结果",
			        sZeroRecords: "没有找到匹配的数据！",
			        sInfo: '<div class="btn-group fr"><div class="add-ym padding-tb6">总共 <font color="red">_TOTAL_</font> 条记录 '+    
		                    '&nbsp;&nbsp;共 <font color="red">_PAGES_</font> 页&nbsp;&nbsp;'+
		                     ' 当前所在第 <font color="red">_PAGE_</font> 页</div>',
			        sInfoEmpty: "显示第 0 至 0 项结果，共 0 项",
			        sInfoFiltered: "",
			        sInfoPostFix: "",
			        sSearch: "搜索:",
			        sEmptyTable: "暂无数据！",
			        sLoadingRecords: "载入中...",
			        sInfoThousands: ",",
			        oPaginate: {
			            sFirst: "首页",
			            sLast: "末页",
			            sNext : "下一页",
						sPrevious : "上一页"
			        },
			        oAria: {
			            "sSortAscending": ": 以升序排列此列",
			            "sSortDescending": ": 以降序排列此列"
			        }
		    	},
		    	drawCallback : function(){//每次重绘后执行的方法
		    		//删除
					$(".a-delete").click(function(){
						var data = {ids:$(this).attr('dataId')};
						delConfirmDiag(function(){
							$.post('delete',data,function(data,status,xhr){
								if(status == "success"  && data.code =="0"){
									alertDiag("操作成功! ");
									Main.dataTableExamples["sysparamList"].fnDraw(false);//刷新表格
									
								}else{
									alertDiag("操作失败! ");
								}
							},"json");
						},"删除系统参数类型","");
					});
					
					
					//表格按钮全选
					$('table th input:checkbox').on('click' , function(){
						var that = this;
						$(this).closest('table').find('tr > td:first-child input:checkbox')
						.each(function(){
							this.checked = that.checked;
						});
							
					});
					
					//查看
					$(".a-lookOver").click(function(){
						var id = $(this).attr('dataId');
						var str = "?on=1&";
						if(id != undefined){
							str += "id=" + id;
						}
						showDialogModal4("查看","Detail" + str,600, 300);
						
					});
					
					//编辑
					$(".a-copyreader").click(function(){
						var id = $(this).attr('dataId');
						sysparamList.Detail(id);
					});
					
					
					
		    	}
			});
		},
    	//新增   修改
    	Detail : function checkView(id){
    		var str = "";
    		var title = "新增";
    		if(id != null && id != undefined){
    			str = "?id="+id;
    			title = "编辑";
    		}
    		showDialogModal(title,"Detail"+ str, 
    				function(data){
    					var str = sysparamDetail.validate();//验证   写在sysparamDetail.jsp  中
    					if(str != false){
    						$.post('add',str,function(data,status,xhr){
								if(status == "success"  && data.code =="0"){
									$(".ui-dialog-button [i-id = cancel]").click();
									alertDiag("操作成功! ");
									Main.dataTableExamples["sysparamList"].fnDraw(false);//刷新表格
								}else{
									alertDiag("操作失败! ");
								}
							},"json");
    					}
    					
    					
    					return false;
    				}, 600, 300, function(data){
    					
    				});
    	}
	}
})();


jQuery(document).ready(function() {
	sysparamList.init();//初始化
});