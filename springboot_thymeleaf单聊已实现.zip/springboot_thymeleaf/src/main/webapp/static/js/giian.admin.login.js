﻿$(function(){
	 /*
	    Background slideshow
	*/
	$.backstretch([
	  home_url + "/static/images/1.jpg"
	, home_url + "/static/images/2.jpg"
	, home_url + "/static/images/3.jpg"
	, home_url + "/static/images/4.jpg"
	, home_url + "/static/images/5.jpg"
	, home_url + "/static/images/6.jpg"
	, home_url + "/static/images/7.jpg"
	], {duration: 5000, fade: 750});
	
	 /*
    Tooltips
	*/
	$('.links a.home').tooltip();
	$('.links a.blog').tooltip();
	
	 $("#username").focus();//光标切入
	 $('#loginForm input').keypress(function(e) {
         if (e.which == 13) {
        	
             if ($('#loginForm').validate().form()) {
                 $('#loginForm').submit();
             }
             return false;
         }
     });
	
	//登录前验证：用户名密码不能空
	$("#loginForm").validate({
		rules: {
	       username: {
		        required: true,
		        minlength: 4
	       }
	    },
	    messages: {
	       username: {
		        required: "<span style='color:red'>  请输入用户名</span>",
		        minlength: "<span style='color:red'>  用户名应该在2个汉字或四个字符以上</span>"
	       }
	    },
		
	    submitHandler : function(form) {
			var loginpassword = $("#planpassword").val();
			//对密码进行加密后传送
			$("#enpassword").val($.md5(loginpassword));
			
			submitForm("#loginForm", home_url+"/login", null, function(data){
				_contentLoadTriggered=false;
				if(data.state.value==0) {
					setTimeout(function(){
						window.location.href = home_url+ data.result.home;
					},10);
					
		        } else {
		        	alertDiag(data.content);
		        }
			},'json');
			
			return false;
		}
	});
	
	//
	$("#planpassword").rules("add", {
         required:true,
         minlength: 6,
         messages: {
            required: "<span style='color:red'>  请输入密码</span>",
            minlength: "<span style='color:red'>  登录密码应该在6位或6位字符以上</span>"
         }
     });

})






















