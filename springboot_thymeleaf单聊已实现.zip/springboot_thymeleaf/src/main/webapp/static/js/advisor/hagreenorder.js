jQuery(document).ready(function() {
	
	//日历
	$('input[name=date-range-picker]').daterangepicker({
        startDate: moment().startOf('day'),
        endDate: moment(),
        //minDate: '01/01/2012',    //最小时间
        maxDate : moment(), //最大时间
        dateLimit : {
            days : 90
        }, //起止时间的最大间隔
        showDropdowns : true,
        showWeekNumbers : false, //是否显示第几周
        timePicker : true, //是否显示小时和分钟
        timePickerIncrement : 60, //时间的增量，单位为分钟
        timePicker12Hour : false, //是否使用12小时制来显示时间
        ranges : {
            //'最近1小时': [moment().subtract('hours',1), moment()],
            '今日': [moment().startOf('day'), moment()],
            '昨日': [moment().subtract('days', 1).startOf('day'), moment().subtract('days', 1).endOf('day')],
            '最近7日': [moment().subtract('days', 6), moment()],
            '最近30日': [moment().subtract('days', 29), moment()]
        },
        opens : 'right', //日期选择框的弹出位置
        buttonClasses : [ 'btn btn-default' ],
        applyClass : 'btn-small btn-primary blue',
        cancelClass : 'btn-small',
        format : 'YYYY-MM-DD HH:mm', //控件中from和to 显示的日期格式
        separator : '~',
        locale : {
            applyLabel : '确定',
            cancelLabel : '取消',
            fromLabel : '起始时间',
            toLabel : '结束时间',
            customRangeLabel : '自定义',
            daysOfWeek : [ '日', '一', '二', '三', '四', '五', '六' ],
            monthNames : [ '一月', '二月', '三月', '四月', '五月', '六月','七月', '八月', '九月', '十月', '十一月', '十二月' ],
            firstDay : 1
        }
    }, function(start, end, label) {//格式化日期显示框
        //$('#reportrange span').html(start.format('YYYY-MM-DD HH:mm') + ' - ' + end.format('YYYY-MM-DD HH:mm'));
        $("#startTime").html(start.format("YYYY-MM-DD HH:mm:ss"));
    	$("#endTime").html(end.format("YYYY-MM-DD HH:mm:ss"));
    	$("#start").val(start.format("YYYY-MM-DD HH:mm:ss"));
    	$("#end").val(end.format("YYYY-MM-DD HH:mm:ss"));
    });
});

//绿色订单搜索
function haGreenOrderSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//操作列
function actionformatter(cellvalue, options, rowObject){
    
	var info = '<a href="'+home_url+'/admin/advisor/order/hagreenorder/viewedit/'+rowObject.id+'" class="ui-pg-div" title="详情" target="_blank"><i class="ui-icon icon-edit blue"></i></a>';
    
    return info;                
}

//关闭订单
function closeHaGreenOrder(id,title,notice){
	
	var advisorOrderEdit = $("#advisorOrderEdit").val() != undefined ? true : false;
	
    if(advisorOrderEdit){
    	
        var myDialog = showDialogModal(title, home_url + "/admin/advisor/order/hagreenorder/viewclose/"+id, function(){
    		
    		//异步提交
    		submitForm("#closeForm", home_url + "/admin/advisor/order/hagreenorder/close", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag(notice,refreshPage);
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//完成订单
function completeHaGreenOrder(id) {
	
    var advisorOrderEdit = $("#advisorOrderEdit").val() != undefined ? true : false;
	
    if(advisorOrderEdit){
    	
    	completeConfirmDiag(function() {
    		
    		$.ajax({
    			
    		    type: "post",
    			url: home_url+"/admin/advisor/order/hagreenorder/complete/"+id,
    			data: {},
    		    dataType: "json",
    		    success: function(data){
    		    	if(data.state.value==0) {
    					alertDiag("服务已完成",refreshPage);
    				}else {
    			        alertDiag(data.content);
    			    }
    			},
    			error: function(){
    				alertDiag("订单完成失败，请稍后重试");
    			},
    		});
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//提交订单详情表单
function submitHaGreenOrderForm(){
	
	var advisorOrderEdit = $("#advisorOrderEdit").val() != undefined ? true : false;
	
    if(advisorOrderEdit){
    	
    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/advisor/order/hagreenorder/edit",
    		data: $("#haGreenOrderForm").serialize(),
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    				alertDiag("保存成功!",refreshPage);
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("保存失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//重置订单详情表单
function resetHaGreenOrderForm(){
	$("#haGreenOrderForm")[0].reset();
}

//新增提交客服联系记录
function submitServiceRecord(){
	
	var advisorOrderEdit = $("#advisorOrderEdit").val() != undefined ? true : false;
	
    if(advisorOrderEdit){
    	
    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/advisor/order/hagreenorder/add",
    		data: $("#haServiceRecordForm").serialize(),
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    				alertDiag("保存成功!",refreshPage);
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("保存失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//重置客服联系记录表单
function resetServiceRecord(){
	$("#haServiceRecordForm")[0].reset();
}

//编辑客服联系记录页
function editServiceRecord(id,telRecord){
	
	var str = "";
	if(telRecord == 1){
		str = "来电";
	}else if(telRecord == 2){
		str = "去电";
	}
	
	var advisorOrderEdit = $("#advisorOrderEdit").val() != undefined ? true : false;
	
    if(advisorOrderEdit){
    	
    	showDialogModal3(str+"详情", home_url + "/admin/advisor/order/hagreenorder/viewupdate/"+id,540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//编辑提交客服联系记录
function saveServiceRecord(isDraft){
	
	$("#isDraft").val(isDraft);
	
	$.ajax({
		type: "post",
		url: home_url + "/admin/advisor/order/hagreenorder/update",
		data: $("#serviceRecordForm").serialize(),
	    dataType: "json",
	    success: function(data){
		    if(data.state.value==0) {
				alertDiag("保存成功!",refreshPage);
			}else {
		        alertDiag(data.content);
		    }
		},
		error: function(){
		    alertDiag("保存失败,请稍后重试");
		},
	});
}