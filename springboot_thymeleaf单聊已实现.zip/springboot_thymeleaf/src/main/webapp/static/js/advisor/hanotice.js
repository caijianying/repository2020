﻿//公告搜索
function haNoticeSearch(){
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//新增公告
function addHaNotice(){
	
    var advisorNoticeEdit = $("#advisorNoticeEdit").val() != undefined ? true : false;
	
    if(advisorNoticeEdit){
    	
    	window.location.href = home_url + "/admin/advisor/hanotice/viewadd/";
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//编辑公告
function editHaNotice(id){
	
    var advisorNoticeEdit = $("#advisorNoticeEdit").val() != undefined ? true : false;
	
    if(advisorNoticeEdit){
    	
    	window.location.href = home_url + "/admin/advisor/hanotice/viewedit/"+id;
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//删除公告
function delHaNotice(id) {
	
    var advisorNoticeEdit = $("#advisorNoticeEdit").val() != undefined ? true : false;
	
    if(advisorNoticeEdit){
    	
    	delConfirmDiag(function() {
    		
    		$.ajax({
    			
    		    type: "post",
    			url: home_url+"/admin/advisor/hanotice/del/"+id,
    			data: {},
    		    dataType: "json",
    		    success: function(data){
    		    	if(data.state.value==0) {
    		    		alertDiag("删除成功!",function(){
    						//刷新表格
    						$("#haNotice").jqGrid().trigger("reloadGrid");
    					});
    				} else {
    		            alertDiag(data.content);
    		        }
    			},
    			error: function(){
    				alertDiag("删除失败，请稍后重试");
    			},
    		});
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}