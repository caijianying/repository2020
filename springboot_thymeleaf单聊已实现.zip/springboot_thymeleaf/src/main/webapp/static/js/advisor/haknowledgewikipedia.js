//知识百科搜索
function haKnowledgeWikipediaSearch(){
	jqGridRedraw($("#searchForm").serializeObject());
}

//新增知识百科
function addHaKnowledgeWikipedia(){
	
    var advisorKnowledgeEdit = $("#advisorKnowledgeEdit").val() != undefined ? true : false;
	
    if(advisorKnowledgeEdit){
    	
    	window.location.href = home_url + "/admin/advisor/haknowledgewikipedia/viewadd/";
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//编辑知识百科
function editHaKnowledgeWikipedia(id){
	
    var advisorKnowledgeEdit = $("#advisorKnowledgeEdit").val() != undefined ? true : false;
	
    if(advisorKnowledgeEdit){
    	
    	window.location.href = home_url + "/admin/advisor/haknowledgewikipedia/viewedit/"+id;
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//排序
function orderBy(id){
	
	var advisorKnowledgeEdit = $("#advisorKnowledgeEdit").val() != undefined ? true : false;
	
    if(advisorKnowledgeEdit){
    	
    	var myDialog = showDialogModal("排序", home_url + "/admin/advisor/haknowledgewikipedia/vieworderby/"+id, function(){
    		
    		//异步提交
    		submitForm("#orderByForm", home_url + "/admin/advisor/haknowledgewikipedia/orderby", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("排序成功!",function(){
    					//刷新表格
    					$("#haKnowledgeWikipedia").jqGrid().trigger("reloadGrid");
    					setTimeout(function(){
    						myDialog.close().remove();
    					},1)
    				});
    			}else {
    				alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//删除知识百科
function delHaKnowledgeWikipedia(id) {
	
    var advisorKnowledgeEdit = $("#advisorKnowledgeEdit").val() != undefined ? true : false;
	
    if(advisorKnowledgeEdit){
    	
    	delConfirmDiag(function() {
    		
    		$.ajax({
    			
    		    type: "post",
    			url: home_url+"/admin/advisor/haknowledgewikipedia/del/"+id,
    			data: {},
    		    dataType: "json",
    		    success: function(data){
    		    	if(data.state.value==0) {
    		    		alertDiag("删除成功!",function(){
    						//刷新表格
    						$("#haKnowledgeWikipedia").jqGrid().trigger("reloadGrid");
    					});
    				} else {
    		            alertDiag(data.content);
    		        }
    			},
    			error: function(){
    				alertDiag("删除失败，请稍后重试");
    			},
    		});
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//知识百科分类(单行)
function classify(id){
	var advisorKnowledgeEdit = $("#advisorKnowledgeEdit").val() != undefined ? true : false;
	
    if(advisorKnowledgeEdit){
    	//取消选中行打钩
    	$("#haKnowledgeWikipedia").jqGrid('resetSelection');
    	//$("#haKnowledgeWikipedia").jqGrid('setSelection',id);
    	//$("#haKnowledgeWikipedia").jqGrid('setSelection',$("#selRow").val(),false);
    	//var ids=$("#haKnowledgeWikipedia").jqGrid('getGridParam','selarrrow');
    	var myDialog = showDialogModal("分类", home_url + "/admin/advisor/haknowledgewikipedia/classfy/"+id, function(){
    		//处理分类结果
    		var typeIds = "";
    		 $.each($('#checkType input[type=checkbox]:checked'),function(){
    		      if(this.checked){
    		    	  typeIds = typeIds+$(this).val()+",";
    		    	  console.log(typeIds);
    		      }
    		 });
    		 $("#typeIds").val(typeIds);
    		//异步提交
    		submitForm("#typeForm", home_url + "/admin/advisor/haknowledgewikipedia/save", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("分类成功!",function(){
    					//刷新表格
    					$("#haKnowledgeWikipedia").jqGrid().trigger("reloadGrid");
    					setTimeout(function(){
    						myDialog.close().remove();
    					},1)
    				});
    			}else {
    				alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}
//知识百科分类(多行)
function changeType(){
	
	
var advisorKnowledgeEdit = $("#advisorKnowledgeEdit").val() != undefined ? true : false;
	
    if(advisorKnowledgeEdit){
    	//获取选中行的ids
    	var ids=$("#haKnowledgeWikipedia").jqGrid('getGridParam','selarrrow');
    	if (ids=="" ||ids==null) {
    		alertDiag("请选择要分类的行!");
    		return false;
		}
    	var hwIds = "";
    	for (var i = 0; i < ids.length; i++) {
    		hwIds+=(ids[i]+",");
		}
    	console.log(hwIds);
    	var myDialog = showDialogModal("分类更改",home_url + "/admin/advisor/haknowledgewikipedia/classfy/", function(){
    		//处理分类结果
    		var typeIds = "";
    		 $.each($('#checkType1 input[type=checkbox]:checked'),function(){
    		      if(this.checked){
    		    	  typeIds = typeIds+$(this).val()+",";
    		      }
    		 });
    		
    		//异步提交
    		submitForm("#typeForm", home_url + "/admin/advisor/haknowledgewikipedia/saveTotal?typeIds="+typeIds+"&&hwIds="+hwIds, null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("编辑成功!",function(){
    					//刷新表格
    					$("#haKnowledgeWikipedia").jqGrid().trigger("reloadGrid");
    					setTimeout(function(){
    						myDialog.close().remove();
    					},1)
    				});
    			}else {
    				alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

function editType(){
var advisorKnowledgeEdit = $("#advisorKnowledgeEdit").val() != undefined ? true : false;
	
    if(advisorKnowledgeEdit){
    	
    	var myDialog = showDialogModal("分类编辑", home_url + "/admin/advisor/haknowledgewikipedia/editType", function(){
    		
    		//异步提交
    		submitForm("#typeForm", home_url + "/admin/advisor/haknowledgewikipedia/doEdit", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("编辑成功!",function(){
    					//刷新表格
    					$("#haKnowledgeWikipedia").jqGrid().trigger("reloadGrid");
    					setTimeout(function(){
    						myDialog.close().remove();
    					},1)
    				});
    			}else {
    				alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}


