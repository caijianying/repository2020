//健康劵分配
function editHaCorpHealthTicket(cid){
	
    var myDialog = showDialogModal("健康劵分配", home_url + "/admin/advisor/hacorphealthticket/viewedit/"+cid, function(){
		
		//异步提交
		submitForm("#editForm", home_url + "/admin/advisor/hacorphealthticket/edit", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag(data.content,function(){
					//刷新表格
					$("#hacorphealthticketlog").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
		        alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}