//联系人搜索
function haContactsSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//新增联系人
function addHaContacts(){
	
	var myDialog = showDialogModal("新增", home_url + "/admin/advisor/user/hacontacts/viewadd/", function(){
		
		//异步提交
		submitForm("#addForm", home_url + "/admin/advisor/user/hacontacts/add", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("新增成功!",function(){
					//刷新表格
					$("#hacontacts").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
				alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//修改联系人
function editHaContacts(id){
	
    var myDialog = showDialogModal("编辑", home_url + "/admin/advisor/user/hacontacts/viewedit/"+id, function(){
		
		//异步提交
		submitForm("#editForm", home_url + "/admin/advisor/user/hacontacts/edit", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("编辑成功!",function(){
					//刷新表格
					$("#hacontacts").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
		        alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//删除联系人
function delHaContacts(id) {
	
	delConfirmDiag(function() {
		
		$.ajax({
			
		    type: "post",
			url: home_url+"/admin/advisor/user/hacontacts/del/"+id,
			data: {},
		    dataType: "json",
		    success: function(data){
		    	if(data.state.value==0) {
		    		alertDiag("删除成功!",function(){
						//刷新表格
						$("#hacontacts").jqGrid().trigger("reloadGrid");
					});
				} else {
		            alertDiag(data.content);
		        }
			},
			error: function(){
				alertDiag("删除失败，请稍后重试");
			},
		});
	});
}