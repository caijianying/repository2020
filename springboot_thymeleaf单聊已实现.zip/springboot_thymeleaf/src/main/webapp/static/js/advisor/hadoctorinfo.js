//医生用户搜索
function haDoctorInfoSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//邀请记录搜索
function userInviteSearch() {
	
	var searchField = $("#userInviteField").val();//获取输入框内容 
	var searchValue = $("#userInviteValue").val();//获取输入框内容
	
    $("#userInvite").jqGrid('setGridParam',{  
        datatype:'json', 
        postData:{'postDatas[1].searchField':searchField,'postDatas[1].searchValue':searchValue} //发送数据  
    }).trigger("reloadGrid"); //重新载入
	
	//jqGridRedraw($("#searchForm").serializeObject());
}

//邀请订单记录搜索
function userOrderSearch() {
	
	var searchField = $("#userOrderField").val();//获取输入框内容 
	var searchValue = $("#userOrderValue").val();//获取输入框内容
	
    $("#userOrder").jqGrid('setGridParam',{  
        datatype:'json', 
        postData:{'postDatas[1].searchField':searchField,'postDatas[1].searchValue':searchValue} //发送数据  
    }).trigger("reloadGrid"); //重新载入
	
	//jqGridRedraw($("#searchForm").serializeObject());
}

//操作列
function actionformatter(cellvalue, options, rowObject){
    
	var fun = "";
	var title = "";
	var css = "";
	
    if(rowObject.isValid == true){
		
    	fun = "javascript:disable('"+cellvalue+"');"
		title = "屏蔽";
		css = "ui-icon icon-ban-circle";
	}else{
		
		fun = "javascript:enable('"+cellvalue+"');"
		title = "解锁";
		css = "ui-icon icon-key";
	}

    var info = "";
    
   if(rowObject.checkState == 1){
		
       info = '<a href="javascript:checkHaDoctorInfo(\''+cellvalue+'\')" class="ui-pg-div" title="审核" target="_blank"><i class="ui-icon icon-ui-icon icon-pencil"></i></a>';
   }else{
		
       info = '<a href="'+home_url+'/admin/advisor/user/hadoctorinfo/view/'+cellvalue+'" class="ui-pg-div" title="查看" target="_blank"><i class="ui-icon icon-eye-open"></i></a>';
	   
	   if(rowObject.haDoctorInfoId != null && rowObject.haDoctorInfoId != undefined && rowObject.isValid == true){
	    	
	       info += '<a href="javascript:editHaDoctorInfo(\''+cellvalue+'\')" class="ui-pg-div" title="编辑" target="_blank"><i class="ui-icon icon-ui-icon icon-pencil"></i></a>';
	   }
	       info += '<a href="'+fun+'" class="ui-pg-div" title="'+title+'"><i class="'+css+'"></i></a>';
	}
	
	return info;                
}

//审核医生用户
function checkHaDoctorInfo(id){
	
	var advisorUserEdit = $("#advisorUserEdit").val() != undefined ? true : false;
	
    if(advisorUserEdit){
    	
    	window.location.href = home_url + "/admin/advisor/user/hadoctorinfo/viewcheck/"+id;
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//审核
function check(id){
	var myDialog = showDialogModal("审核", home_url + "/admin/advisor/user/hadoctorinfo/check/"+id, function(){
		//异步提交
		submitForm("#checkForm", home_url + "/admin/advisor/user/hadoctorinfo/check", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("审核完成!",function(){
					window.location.href = home_url + "/admin/advisor/user/hadoctorinfo";
				});
			}else {
				alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//新增医生用户
function addHaDoctorInfo(){
	
    var advisorUserEdit = $("#advisorUserEdit").val() != undefined ? true : false;
	
    if(advisorUserEdit){
    	
    	window.location.href = home_url + "/admin/advisor/user/hadoctorinfo/viewadd/";
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//新增医生用户
function add(){
	
	//密码进行md5加密
	if($("#passWordOne").val() != null && $("#passWordOne").val() != ""){
		
		var passWordOne = $("#passWordOne").val();
		passWordOne = $.md5(passWordOne)
		$("#password").val(passWordOne)
		
		var passWordTwo = $("#passWordTwo").val();
		passWordTwo = $.md5(passWordTwo)
		$("#confirmPassword").val(passWordTwo)
	}
	
	var provinceId = $("input[name='provinceId']").val();
	var cityId = $("input[name='cityId']").val();
	
	if(cityId == null || cityId == "" || cityId == undefined || cityId == -1){
  		alertDiag("请选择所在地");
  		return false;
  	}else{
  		$("#areaId").val(cityId);
  	}
	
	//异步提交
	submitForm("#addForm", home_url + "/admin/advisor/user/hadoctorinfo/add", null, function(data){
		_contentLoadTriggered=false;
		if(data.state.value==0) {
			alertDiag("新增成功!",function(){
				window.location.href = home_url + "/admin/advisor/user/hadoctorinfo";
			});
		}else {
			alertDiag(data.content);
	    }
	},'json');
	return false;
}

//编辑医生用户
function editHaDoctorInfo(id){
	
    var advisorUserEdit = $("#advisorUserEdit").val() != undefined ? true : false;
	
    if(advisorUserEdit){

    	window.location.href = home_url + "/admin/advisor/user/hadoctorinfo/viewedit/"+id;
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//编辑医生用户
function edit(){
	
	var provinceId = $("input[name='provinceId']").val();
	var cityId = $("input[name='cityId']").val();
	
	if(cityId == null || cityId == "" || cityId == undefined || cityId == -1){
  		alertDiag("请选择所在地");
  		return false;
  	}else{
  		$("#areaId").val(cityId);
  	}
	
	//异步提交
	submitForm("#editForm", home_url + "/admin/advisor/user/hadoctorinfo/edit", null, function(data){
		_contentLoadTriggered=false;
		if(data.state.value==0) {
			alertDiag("编辑成功!",function(){
				window.location.href = home_url + "/admin/advisor/user/hadoctorinfo";
			});
		}else {
			alertDiag(data.content);
	    }
	},'json');
	return false;
}

//医生用户禁用
function disable(id){
	
    var advisorUserEdit = $("#advisorUserEdit").val() != undefined ? true : false;
	
    if(advisorUserEdit){

    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/advisor/user/hadoctorinfo/disable/"+id,
    		data: {},
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    		    	alertDiag("医生已禁用!",function(){
    					//刷新表格
    					$("#hadoctorinfo").jqGrid().trigger("reloadGrid");
    				});
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("操作失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//医生用户解除禁用
function enable(id){
	
    var advisorUserEdit = $("#advisorUserEdit").val() != undefined ? true : false;
	
    if(advisorUserEdit){
    	
    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/advisor/user/hadoctorinfo/enable/"+id,
    		data: {},
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    				alertDiag("医生已解除禁用!",function(){
    					//刷新表格
    					$("#hadoctorinfo").jqGrid().trigger("reloadGrid");
    				});
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("操作失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}