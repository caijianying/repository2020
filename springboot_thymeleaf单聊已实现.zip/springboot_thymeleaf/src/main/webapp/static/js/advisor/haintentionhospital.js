//意向医院搜索
function haIntentionHospitalSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//新增意向医院
function addHaIntentionHospital(){
	
    var advisorHospitalEdit = $("#advisorHospitalEdit").val() != undefined ? true : false;
	
    if(advisorHospitalEdit){
    	
    	var myDialog = showDialogModal("新增", home_url + "/admin/advisor/haintentionhospital/viewadd/", function(){
    		
    		var intentionHospitalDepartmentsNames = "";
    		$("input[name='intentionHospitalDepartmentsName']").each(function(){
    			intentionHospitalDepartmentsNames = intentionHospitalDepartmentsNames + $(this).val() + ",";
    		});
    		intentionHospitalDepartmentsNames = intentionHospitalDepartmentsNames.substring(0,intentionHospitalDepartmentsNames.length-1);
    		$("#intentionHospitalDepartmentsNames").val(intentionHospitalDepartmentsNames);
    		
    		//异步提交
    		submitForm("#addForm", home_url + "/admin/advisor/haintentionhospital/add", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("新增成功!",function(){
    					//刷新表格
    					$("#haintentionhospital").jqGrid().trigger("reloadGrid");
    					setTimeout(function(){
    						myDialog.close().remove();
    					},1)
    				});
    			}else {
    				alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//修改意向医院
function editHaIntentionHospital(id){
	
    var advisorHospitalEdit = $("#advisorHospitalEdit").val() != undefined ? true : false;
	
    if(advisorHospitalEdit){
    	
        var myDialog = showDialogModal("编辑", home_url + "/admin/advisor/haintentionhospital/viewedit/"+id, function(){
    		
        	var intentionHospitalDepartmentsNames = "";
    		$("input[name='intentionHospitalDepartmentsName']").each(function(){
    			intentionHospitalDepartmentsNames = intentionHospitalDepartmentsNames + $(this).val() + ",";
    		});
    		intentionHospitalDepartmentsNames = intentionHospitalDepartmentsNames.substring(0,intentionHospitalDepartmentsNames.length-1);
    		$("#intentionHospitalDepartmentsNames").val(intentionHospitalDepartmentsNames);
        	
    		//异步提交
    		submitForm("#editForm", home_url + "/admin/advisor/haintentionhospital/edit", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("编辑成功!",function(){
    					//刷新表格
    					$("#haintentionhospital").jqGrid().trigger("reloadGrid");
    					setTimeout(function(){
    						myDialog.close().remove();
    					},1)
    				});
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//删除意向医院
function delHaIntentionHospital(id) {
	
    var advisorHospitalEdit = $("#advisorHospitalEdit").val() != undefined ? true : false;
	
    if(advisorHospitalEdit){
    	
    	delConfirmDiag(function() {
    		
    		$.ajax({
    			
    		    type: "post",
    			url: home_url+"/admin/advisor/haintentionhospital/del/"+id,
    			data: {},
    		    dataType: "json",
    		    success: function(data){
    		    	if(data.state.value==0) {
    		    		alertDiag("删除成功!",function(){
    						//刷新表格
    						$("#haintentionhospital").jqGrid().trigger("reloadGrid");
    					});
    				} else {
    		            alertDiag(data.content);
    		        }
    			},
    			error: function(){
    				alertDiag("删除失败，请稍后重试");
    			},
    		});
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}