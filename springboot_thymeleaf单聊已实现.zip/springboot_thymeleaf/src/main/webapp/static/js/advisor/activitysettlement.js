//联系人搜索
function activitysettlementSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//结算
function settlement() {
	
	settlementConfirmDiag(function() {
		
		$.ajax({
			
		    type: "post",
			url: home_url+"/admin/advisor/settlement/activitysettlement/settlement",
			data: {},
		    dataType: "json",
		    success: function(data){
		    	if(data.state.value==0) {
		    		alertDiag("结算成功!",function(){
						//刷新表格
						$("#activitysettlement").jqGrid().trigger("reloadGrid");
					});
				} else {
		            alertDiag(data.content);
		        }
			},
			error: function(){
				alertDiag("结算失败，请稍后重试");
			},
		});
	});
}