//个人用户搜索
function haUserInfoSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//邀请记录搜索
function userInviteSearch() {
	
	var searchField = $("#userInviteField").val();//获取输入框内容 
	var searchValue = $("#userInviteValue").val();//获取输入框内容
	
    $("#userInvite").jqGrid('setGridParam',{  
        datatype:'json', 
        postData:{'postDatas[1].searchField':searchField,'postDatas[1].searchValue':searchValue} //发送数据  
    }).trigger("reloadGrid"); //重新载入
	
	//jqGridRedraw($("#searchForm").serializeObject());
}

//邀请订单记录搜索
function userOrderSearch() {
	
	var searchField = $("#userOrderField").val();//获取输入框内容 
	var searchValue = $("#userOrderValue").val();//获取输入框内容
	
    $("#userOrder").jqGrid('setGridParam',{  
        datatype:'json', 
        postData:{'postDatas[1].searchField':searchField,'postDatas[1].searchValue':searchValue} //发送数据  
    }).trigger("reloadGrid"); //重新载入
	
	//jqGridRedraw($("#searchForm").serializeObject());
}

//操作列
function actionformatter(cellvalue, options, rowObject){
    
	var fun = "";
	var title = "";
	var css = "";
	
    if(rowObject.isValid == true){
		
    	fun = "javascript:disable('"+cellvalue+"');"
		title = "屏蔽";
		css = "ui-icon icon-ban-circle";
	}else{
		
		fun = "javascript:enable('"+cellvalue+"');"
		title = "解锁";
		css = "ui-icon icon-key";
	}

    var info = "";
    
    if(rowObject.userCheckState == 1){
		
    	info = '<a href="javascript:checkHaUserInfo(\''+cellvalue+'\')" class="ui-pg-div" title="审核" target="_blank"><i class="ui-icon icon-ui-icon icon-pencil"></i></a>';
	}else{
		
		info = '<a href="'+home_url+'/admin/advisor/user/hauserinfo/view/'+cellvalue+'" class="ui-pg-div" title="查看" target="_blank"><i class="ui-icon icon-eye-open"></i></a>';
		info += '<a href="'+fun+'" class="ui-pg-div" title="'+title+'"><i class="'+css+'"></i></a>';
	}
	
	return info;                
}

//审核个人用户
function checkHaUserInfo(id){
	
	var advisorUserEdit = $("#advisorUserEdit").val() != undefined ? true : false;
	
    if(advisorUserEdit){
    	
    	window.location.href = home_url + "/admin/advisor/user/hauserinfo/viewcheck/"+id;
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//审核
function check(id){
	var myDialog = showDialogModal("审核", home_url + "/admin/advisor/user/hauserinfo/check/"+id, function(){
		//异步提交
		submitForm("#checkForm", home_url + "/admin/advisor/user/hauserinfo/check", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("审核完成!",function(){
					window.location.href = home_url + "/admin/advisor/user/hauserinfo";
				});
			}else {
				alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//个人用户禁用
function disable(id){
	
    var advisorUserEdit = $("#advisorUserEdit").val() != undefined ? true : false;
	
    if(advisorUserEdit){
    	
    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/advisor/user/hauserinfo/disable/"+id,
    		data: {},
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    		    	alertDiag("医生已禁用!",function(){
    					//刷新表格
    					$("#hauserinfo").jqGrid().trigger("reloadGrid");
    				});
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("操作失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//个人用户解除禁用
function enable(id){
	
    var advisorUserEdit = $("#advisorUserEdit").val() != undefined ? true : false;
	
    if(advisorUserEdit){
    	
    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/advisor/user/hauserinfo/enable/"+id,
    		data: {},
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    				alertDiag("医生已解除禁用!",function(){
    					//刷新表格
    					$("#hauserinfo").jqGrid().trigger("reloadGrid");
    				});
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("操作失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}