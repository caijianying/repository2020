
/*根据分辨率高度调整主体内容是否显示滚动条 start*/
$(window).load(function(){
	var height=$(window).height();
	var cheight=height-200+"px";
	var cheight2=height-280+"px";
	var silde=height-91+"px";
	$(".content").css({"height":cheight});
	$(".overbox").css({"height":cheight2});
	$(".silde").css({"height":silde,"line-height":silde});
	
});

$(window).resize(function() {//判断窗体调整是否显示滚动条
	var height=$(window).height();
	var cheight=height-200+"px";
	var cheight2=height-280+"px";
	var silde=height-91+"px";
	$(".content").css({"height":cheight});
	$(".overbox").css({"height":cheight2});
	$(".silde").css({"height":silde,"line-height":silde});

});
/*根据分辨率高度调整主体内容是否显示滚动条 end*/

//删除按钮删除tr
$(".shanc").click(function(){
	$(this).parents("tr").hide();	
});	

/********全选 checkbox start*******/
$(".all").click(function(){
	if(this.checked){
		$(".list input[type='checkbox']").each(function(){this.checked=true;});
	}else{
		$(".list input[type='checkbox']").each(function(){this.checked=false;});
	}
});

$(".all2").click(function(){
	if(this.checked){
		$(".list2 input[type='checkbox']").each(function(){this.checked=true;});
	}else{
		$(".list2 input[type='checkbox']").each(function(){this.checked=false;});
	}
});

$(".list input[type='checkbox']").click(function(){ 
	var chknum = $(".list input[type='checkbox']").size();//选项总个数 
    var chk = 0; 
	$(".list input[type='checkbox']").each(function () {   
        if($(this).attr("checked")==true){
            chk++; 	
        } 
    }); 
    if(chknum==chk){//全选
        $(".all").attr("checked",true); 
    }else{//不全选 
        $(".all").attr("checked",false); 
    }
});
/********全选 checkbox end*******/	

//experts 能力证明添加
/*function addpand() {
	$(".prove .table tbody").append("<tr><td>2</td><td></td><td></td><td><a href=\"javascript:;\" class=\"btn btn-default btn-sm color_black\" title=\"查看\"><span class=\"glyphicon glyphicon-zoom-in\"></span></a></td></tr>");
};

//experts 服务案例资料添加
function addpand2() {
	$(".case .table tbody").append("<tr><td>2</td><td></td><td></td><td></td><td><a href=\"javascript:;\" class=\"btn btn-default btn-sm color_black\" title=\"查看\"><span class=\"glyphicon glyphicon-zoom-in\"></span></a></td></tr>");
};*/


//左侧
$(".silde").click(function(){
	$(this).toggleClass("sildeleft");
	$(this).siblings(".side-nav").toggleClass("sidenav");
	$(this).parents(".wrapper").toggleClass("wrapperwid");	
});

//i的宽和高
//var wi = $(".breadlist li a i").width();
//var mi = wi + 4 + "px";
//$(".breadlist li a i").css({"width":mi,"height":mi,"line-height":mi});

//后台管理 注销情况
$(".zhux").click(function(){
	$(this).parent("td").prev("td").html("已注销");
	$(this).parent("td").prev("td").css({"color":"#f00"});
});

//企业网用户总表 屏蔽情况
$(".list .pingb").click(function(){
	$(this).parent("td").prev("td").html("已屏蔽");
	$(this).parent("td").prev("td").css({"color":"#f00"});
});

/****点击查看大图 start****/
$(".pic_open").click(function(e){
	e.stopPropagation();
	var $ths_href=$(this).attr("href");
	var $picsrc=$(".picBigbox").find("img").attr("src");
	//alert($picsrc);
	$(".picBigbox").find("img").attr("src",$ths_href);
	$(".picBigbox").fadeIn(500);
	$(".popbg").fadeIn(0);
	return false;//阻止链接跳转
});
/****点击查看大图 end****/
	
/**关闭大图查看 start***/
$.fn.extend({'picClose':function(){//click方法
	$(".picBigbox").fadeOut(0);
	$(".popbg").fadeOut(0);
}
});
/**关闭大图查看 endt***/

//通过不通过切换
$(".tg").click(function(){
	$(".tgneir").removeClass("dn");
	$(".btgneir").addClass("dn");	
});
$(".btg").click(function(){
	$(".tgneir").addClass("dn");
	$(".btgneir").removeClass("dn");
	$("#ckshtg").scrollTop( $("#ckshtg")[0].scrollHeight );
});

//删除上传文件
$(".pop-condel").click(function(){
	$(this).parent("li").hide();	
});




















