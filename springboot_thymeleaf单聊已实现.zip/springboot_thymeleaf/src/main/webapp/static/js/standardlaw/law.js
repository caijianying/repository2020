/**
 * ****************************************
 * ************主页函数和方法*************
 * ****************************************
 */
jQuery(document).ready(function() {
	/**
	 * setStartDate(Date or string)：将日期范围选择器的当前所选开始日期设置为提供的日期
	 * setEndDate(Date or string)：将日期范围选择器的当前所选结束日期设置为提供的日期
	 */
	//日历
	$('#date-range-picker').daterangepicker({
        // startDate: moment().startOf('day'),
//        endDate: moment(),
        //minDate: '01/01/2012',    //最小时间
//        maxDate : moment(), //最大时间
        dateLimit : {
            days : 90
        }, //起止时间的最大间隔
        showDropdowns : true,
        showWeekNumbers : false, //是否显示第几周
        timePicker : true, //是否显示小时和分钟
        timePickerIncrement : 60, //时间的增量，单位为分钟
        timePicker12Hour : false, //是否使用12小时制来显示时间
        ranges : {
            //'最近1小时': [moment().subtract('hours',1), moment()],
            '今日': [moment().startOf('day'), moment()],
            '昨日': [moment().subtract('days', 1).startOf('day'), moment().subtract('days', 1).endOf('day')],
            '最近7日': [moment().subtract('days', 6), moment()],
            '最近30日': [moment().subtract('days', 29), moment()]
        },
        opens : 'right', //日期选择框的弹出位置
        buttonClasses : [ 'btn btn-default' ],
        applyClass : 'btn-small btn-primary blue',
        cancelClass : 'btn-small',
        format : 'YYYY-MM-DD', //控件中from和to 显示的日期格式
        separator : '~',
        locale : {
            applyLabel : '确定',
            cancelLabel : '取消',
            fromLabel : '起始时间',
            toLabel : '结束时间',
            customRangeLabel : '自定义',
            daysOfWeek : [ '日', '一', '二', '三', '四', '五', '六' ],
            monthNames : [ '一月', '二月', '三月', '四月', '五月', '六月','七月', '八月', '九月', '十月', '十一月', '十二月' ],
            firstDay : 1
        }
    }, function(start, end, label) {//格式化日期显示框
        //$('#reportrange span').html(start.format('YYYY-MM-DD HH:mm') + ' - ' + end.format('YYYY-MM-DD HH:mm'));
//    	console.log(start.format("YYYY-MM-DD HH:mm:ss"));
//    	console.log(end.format("YYYY-MM-DD HH:mm:ss"));
        $("#executeDateStartTime").html(start.format("YYYY-MM-DD"));
    	$("#executeDateEndTime").html(end.format("YYYY-MM-DD"));
    	$("#executeDateStart").val(start.format("YYYY-MM-DD"));
    	$("#executeDateEnd").val(end.format("YYYY-MM-DD"));
    });

	//日历
	$('#id-date-range-picker-1').daterangepicker({
//        startDate: moment().startOf('day'),
		"autoApply": true, //(日期刷新)选择日期后自动提交;只有在不显示时间的时候起作用timePicker:false
//        endDate: moment(),
        //minDate: '01/01/2012',    //最小时间
        maxDate : moment(), //最大时间
        dateLimit : {
            days : 90
        }, //起止时间的最大间隔
        showDropdowns : true,
        showWeekNumbers : false, //是否显示第几周
        timePicker : false, //是否显示小时和分钟
        timePickerIncrement : 60, //时间的增量，单位为分钟
        timePicker12Hour : false, //是否使用12小时制来显示时间
        ranges : {
            //'最近1小时': [moment().subtract('hours',1), moment()],
            '今日': [moment().startOf('day'), moment()],
            '昨日': [moment().subtract('days', 1).startOf('day'), moment().subtract('days', 1).endOf('day')],
            '最近7日': [moment().subtract('days', 6), moment()],
            '最近30日': [moment().subtract('days', 29), moment()]
        },
        opens : 'right', //日期选择框的弹出位置
        buttonClasses : [ 'btn btn-default' ],
        applyClass : 'btn-small btn-primary blue',
        cancelClass : 'btn-small',
        format : 'YYYY-MM-DD HH:mm:ss', //控件中from和to 显示的日期格式
        separator : '~',
        locale : {
            applyLabel : '确定',
            cancelLabel : '取消',
            fromLabel : '起始时间',
            toLabel : '结束时间',
            customRangeLabel : '自定义',
            daysOfWeek : [ '日', '一', '二', '三', '四', '五', '六' ],
            monthNames : [ '一月', '二月', '三月', '四月', '五月', '六月','七月', '八月', '九月', '十月', '十一月', '十二月' ],
            firstDay : 1,
        }
    }, function(start, end, label) {//格式化日期显示框
        //$('#reportrange span').html(start.format('YYYY-MM-DD HH:mm') + ' - ' + end.format('YYYY-MM-DD HH:mm'));
        $("#uploadDateStartTime").html(start.format("YYYY-MM-DD HH:mm"));
    	$("#uploadDateEndTime").html(end.format("YYYY-MM-DD HH:mm"));
    	$("#uploadDateStart").val(start.format("YYYY-MM-DD HH:mm"));
    	$("#uploadDateEnd").val(end.format("YYYY-MM-DD HH:mm"));
    });
	
	//ztree 编辑删除按钮
	jQuery('#gtreetable').gtreetable({
		'nodesWrapper' : 'data',
		'languages' : 'zh-CN',
	  'source': function (id) {
	    return {
	      type: 'GET',
	      url:  home_url + '/admin/datamaintenance/standardlaw/ztreeListData',
	      data: { 'pid': id },        
	      dataType: 'json',
	      error: function(XMLHttpRequest) {
	        alert(XMLHttpRequest.status+': '+XMLHttpRequest.responseText);
	      }
	    }
	  }
//	  ,'templateSelector' : '#gtreetable' 
	});
	
	$(".ui-jqgrid-bdiv").closest(".ui-jqgrid-bdiv").css({ 'overflow-x': 'hidden' });
	
	//生成项目层级树
	createTree();
	
//	setTimeout(function(){ 
//		//设置表头Demo
//
//		var colObj=$("#standardlaw").jqGrid('getGridParam','colModel');
//		//console.log(colObj);
//		$(colObj).each(function(index,item){
//			//<input type='radio' value='' class='ace tg' name='' /><span class='lbl'></span>
//			if (index==0||index ==1 || index == colObj.length-1 ) {
//				
//			}else{
//				switch (index) {
//				case 2:
//					var html = "<div class='align-left'><input type='checkbox' value='"+index+"'  class='ace tg sz' name='checkObj' disabled='disabled' checked /><span class='lbl'></span>"+item.label+"</div>";
//					break;
//				case 6:
//					var html = "<div class='align-left'><input type='checkbox' value='"+index+"' class='ace tg sz' name='checkObj'/><span class='lbl'></span>"+item.label+"</div>";
//					$("#standardlaw").setGridParam().hideCol(colObj[index].name);
//					break;
//				case 8:
//					var html = "<div class='align-left'><input type='checkbox' value='"+index+"'  class='ace tg sz' name='checkObj'/><span class='lbl'></span>"+item.label+"</div>";
//					$("#standardlaw").setGridParam().hideCol(colObj[index].name);
//					break;
//				case 10:
//					var html = "<div class='align-left'><input type='checkbox' value='"+index+"'  class='ace tg sz' name='checkObj'/><span class='lbl'></span>"+item.label+"</div>";
//					$("#standardlaw").setGridParam().hideCol(colObj[index].name);
//					break;
//				
//				default:
//					var html = "<div class='align-left'><input type='checkbox' value='"+index+"' v-name='"+item.label+"' class='ace tg sz' name='checkObj' checked/><span class='lbl'></span>"+item.label+"</div>";
//					break;
//				}
//				
//				$("#headObjs").append(html);
//			}
//		
//			
//		});
//		
//	}, 500);
//	$("#standardlaw").on('change'.function({
//		var colObj=$("#standardlaw").jqGrid('getGridParam','colModel');
//		if ($(this).is(':checked')) {
//			console.log("选中编号:"+$(this).val());
//			var index = $(this).val();
//			$("#standardlaw").setGridParam().showCol(colObj[index].name);
//			//console.log(colObj[index].label+"是否隐藏:"+colObj[index].hidden);
//		}
//	}))
	
	$("#isReset").val(false);
});


function createTree(){
	
	var setting = {
			edit: {
				enable : true,
				editNameSelectAll : true
				},
			async: {
		        enable: true,
		        autoParam: ["id"],
		        url: home_url+"/admin/datamaintenance/standardlaw/getTree",
		        dataFilter: filter
		    },
			view: {  
				expandSpeed: "",  
                addHoverDom: addHoverDom,  
                removeHoverDom: removeHoverDom,
		        dblClickExpand: false,
		        selectedMulti: false
		    }, 
			check: {
				enable: true,
				chkStyle: "radio",
			},
			data: {
				simpleData: {
					enable: true,
					idKey: "id",
					pIdKey: "pid"
				},
				key : {
	                name : "name",
	            }
			},
			callback:{
				beforeRemove: zTreeBeforeRemove,  //用于捕获节点被删除之前的事件回调函数，并且根据返回值确定是否允许删除操作
				beforeRename: zTreeBeforeRename,  //用于捕获节点编辑名称结束（Input 失去焦点 或 按下 Enter 键）之后，更新节点名称数据之前的事件回调函数，并且根据返回值确定是否允许更改名称的操作
				onRemove: zTreeOnRemove,
				onRename: zTreeOnRename,
				onAsyncSuccess:zTreeOnAsyncSuccess
				
			},
		    showLine : true,//是否显示节点间的连线
			expandSpeed : "fast", //设置 zTree节点展开、折叠时的动画速度或取消动画(三种默认定义："slow", "normal", "fast")或 表示动画时长的毫秒数值(如：1000)
		};
	   function zTreeBeforeRemove(treeId, treeNode){
		   console.log(treeNode);
		   if (treeNode.id != "") {
			   if (treeNode.id == 0) {
				   if (treeNode.pid != 0) {
					   alertDiag("根节点不能删除!");
					   return false;
				   }
			   }
		   }
		   
	   }
	   
	   function zTreeBeforeRename(treeId, treeNode){
		   if (treeNode.id != "") {
			   if (treeNode.id == 0) {
				   if (treeNode.pid != 0) {
					   alertDiag("根节点不能编辑!");
					   $.fn.zTree.init($("#treeDemo"), setting);
					   return false;
				   }
			   }
		   }
		  
	   }
	   
	   function zTreeOnRemove(event, treeId, treeNode) {
		   if (!(treeNode.id == 0 && treeNode.pid == 0)) {
			   removeNode(treeNode.id,treeNode.pid);
		   }
		  
		}
	   
	   function zTreeOnRename(event, treeId, treeNode, isCancel) {
			editNodeName(treeNode.id,treeNode.pid,treeNode.name);
		}
	   
	   function editNodeName(id,pid,name){
		   $.ajax({
			   url: home_url+"/admin/datamaintenance/standardlaw/ztree/editProjName",
			   data:{
				   id:id,
				   pid:pid,
				   name:name
			   },
			   type:'GET',
			   success:function(data){
				   if (data.state.value == 0) {
					   alertDiag("编辑成功!",function(){
						   $.fn.zTree.init($("#treeDemo"), setting);
					   });
				 }else{
					 alertDiag(data.content,function(){
						 $.fn.zTree.init($("#treeDemo"), setting);
					 });
				 }
			   }
		   })
	   }
	   function removeNode(id,pid){
		   $.ajax({
			   url: home_url+"/admin/datamaintenance/standardlaw/ztree/delProj",
			   type:'GET',
			   data:{
				   id:id,
				   pid:pid
				   },
			   success:function(data){
				   if (data.state.value == 0) {
					   alertDiag("删除成功!",function(){
						   $.fn.zTree.init($("#treeDemo"), setting);
					   });
				   }else{
					   $.fn.zTree.init($("#treeDemo"), setting);
					   alertDiag(data.content,function(){
						 
					   });
					   
				   }
			   }
		   })
	   }
	   
	   //ajax加载之后过滤
	   function filter(treeId, parentNode, childNodes) {
	   	if (!childNodes) return null;
	   	for (var i=0, l=childNodes.length; i<l; i++) {
	   	    childNodes[i].name = childNodes[i].name.replace(/\.n/g, '.');
	   	}
	   	return childNodes;
	   }
	   //初始化树
		$(document).ready(function(){
			$.fn.zTree.init($("#treeDemo"), setting);
		});
		
		//异步展开树
		function zTreeOnAsyncSuccess(event, treeId, treeNode, msg) {
		    if(treeNode==null){
			    var zTree = $.fn.zTree.getZTreeObj("treeDemo");
				nodes = zTree.getNodes();
				for (var i=0, l=nodes.length; i<l; i++) {
				    zTree.expandNode(nodes[i], true, false, false);
				}
				asyncNodes(zTree.getNodes());
				if (!goAsync) {
				    curStatus = "";
				}
			}
		};
			
		function asyncNodes(nodes) {
			if (!nodes) return;
			curStatus = "async";
			var zTree = $.fn.zTree.getZTreeObj("treeDemo");
			for (var i=0, l=nodes.length; i<l; i++) {
			    if (nodes[i].isParent && nodes[i].zAsync) {
			        asyncNodes(nodes[i].children);
			    } else {
			        goAsync = true;
			        zTree.reAsyncChildNodes(nodes[i], "refresh", true);
			    }
			}
		}
		
		var newCount = 1;  
        function addHoverDom(treeId, treeNode) {  
        	
            var sObj = $("#" + treeNode.tId + "_span");  
            if (treeNode.editNameFlag || $("#addBtn_" + treeNode.tId).length > 0) return;  
            var addStr = "<span class='button add' id='addBtn_" + treeNode.tId  
                + "' title='add node' onfocus='this.blur();' ></span>";
//            console.log("addHoverDom");
//            console.log(treeNode);
            if (treeNode.isParent) {
            	sObj.after(addStr);  
			}
            
            var btn = $("#addBtn_" + treeNode.tId);  
            if (btn) btn.bind("click", function () {
            	
            	if (!treeNode.isParent) {
            		alertDiag("请在上一级目录上添加!");
            		return false;  
				}
                var zTree = $.fn.zTree.getZTreeObj("treeDemo"); 
//                console.log(treeNode);
//                console.log(newCount);
                zTree.addNodes(treeNode, { id: "", parentid: treeNode.id, name: "请输入名称"});  
                return false;  
            });  
        }; 
        
        function removeHoverDom(treeId, treeNode) {  
            $("#addBtn_" + treeNode.tId).unbind().remove();  
        }; 
}

//二级联动值处理函数
function TwoLevelLink_domainValues(class1EleId,class2EleId,eleId){
	var class2Id = $(class2EleId).val();
//	console.log("选中1!"+class2Id);
//	console.log("选中2!"+$(class1EleId).val());
	if (class2Id == null ||class2Id == "" ) {
		$(eleId).val($(class1EleId).val());
	}else $(eleId).val(class2Id);
//	console.log("值："+$(eleId).val());

}
//法律法规搜索
function legalSearch() {
	TwoLevelLink_domainValues("#lawClassifyItem","#lawClassifyItem2","#lawClassId");
	TwoLevelLink_domainValues("#projItem","#projItem2","#projClassId");
//	console.log($("#date-range-picker").val());
	
	if ($("#date-range-picker").val() == "" || $("#date-range-picker").val() == null) {
		$("#executeDateStart").val("");
		$("#executeDateEnd").val("");
	}else{
		$("#executeDateStart").val($("#date-range-picker").val().split('~')[0]);
		$("#executeDateEnd").val($("#date-range-picker").val().split('~')[1]);
	}
//	console.log($("#executeDateStart").val());
//	console.log($("#executeDateEnd").val());
//	console.log($("#date-range-picker").val());
	if ($("#id-date-range-picker-1").val() == "" || $("#id-date-range-picker-1").val() == null) {
		$("#uploadDateStart").val("");
		$("#uploadDateEnd").val("");
	}else{
		$("#uploadDateStart").val($("#id-date-range-picker-1").val().split('~')[0]);
		$("#uploadDateEnd").val($("#id-date-range-picker-1").val().split('~')[1]);
	}
//	console.log($("#uploadDateStart").val());
//	console.log($("#uploadDateEnd").val());
//	console.log($("#id-date-range-picker-1").val());
	if (isNull("#search")==true && isNull("#reset-zt")==true && isNull("#reset-hy")==true && isNull("#lawClassifyItem")==true && isNull("#lawClassifyItem2")==true && isNull("#projItem")==true  && isNull("#projItem2")==true && isNull("#executeDateStart") && isNull("#executeDateEnd") && isNull("#uploadDateStart") && isNull("#uploadDateEnd")) {
		$("#isReset").val(true);
	}else 	$("#isReset").val(false);
//	console.log($("#isReset").val());
	jqGridRedraw($("#searchForm").serializeObject());
	
	
}

//加上文件url
function webLnkformatter(cellvalue, options, rowObject){
	if (rowObject.ossUrl == undefined || rowObject.ossUrl == "") {
		var info = cellvalue;
	}else {
		var info = '<a href="'+rowObject.ossUrl+'" target="_blank">'+cellvalue+'</a>';
	}
	return info;
}

function isNull(eleId){
	if ($(eleId).val()==null || $(eleId).val()==undefined ||$(eleId).val()=="") {
		return true;
	}else return false;
}
//新增法律法规
function addLegal(){
	var myDialog = showDialogModal("新增", home_url + "/admin/datamaintenance/standardlaw/viewadd/", function(){
		/**
		 * model.addAttribute("lawIndex", standardLawLegClassifyService.getlawIndex());
		model.addAttribute("standardIndex", standardLawLegClassifyService.getStandardIndex());
		model.addAttribute("readIndex", standardLawLegClassifyService.getReadIndex());
		 */
		var readIndex = "${readIndex}";
		var standardIndex = "${standardIndex}";
		var lawIndex = "${lawIndex}";
		
		//需求变更  代替修订信息为一个输入框 by 王自强
//		if ($("#lawClass").val() != readIndex) {
//			//处理代替修订信息 replaceBox
//			var content1,content2;
//			console.log("replaceBox："+$("#replaceBox").prop("checked"));
//			console.log("replaceByBox："+$("#replaceByBox").prop("checked"));
//			if ($("#replaceBox").prop("checked")!= undefined && $("#replaceBox").prop("checked")) {
//				var keyword = $("#keyword1").text();
////				if (!ifHaveBookMark("#replaceInput")) {
////					content1 = keyword +"《"+ ($("#replaceInput").val())+"》";
////				}else{
////					content1 = keyword + ($("#replaceInput").val());
////				}
//				
//				content1 = keyword +"《"+ ($("#replaceInput").val())+"》";
//			}
//			console.log("描述content1："+content1);
//			if ($("#replaceByBox").prop("checked")!= undefined && $("#replaceByBox").prop("checked")) {
//				var keyword = $("#keyword2").text();
//				if (keyword == '被代替') {
////					if (!ifHaveBookMark("#replaceByInput")) {
////						content2 = "被" +"《"+ ($("#replaceByInput").val())+"》"+"代替";
////					}else{
////						content2 = "被" + ($("#replaceByInput").val())+"代替";
////					}
//					content2 = "被" +"《"+ ($("#replaceByInput").val())+"》"+"代替";
//				}else {
//					
////					if (!ifHaveBookMark("#replaceByInput")) {
////						content2 =keyword +"《"+ ($("#replaceByInput").val())+"》";
////					}else {
////						content2 =keyword + ($("#replaceByInput").val());
////					}
//					content2 =keyword +"《"+ ($("#replaceByInput").val())+"》";
//					
//				}
//				if ($("#lawClass").val() == lawIndex) {
//					content2 = content2 +  $("#keyword3").text();
//				}
//			}
//			console.log("描述content2："+content2);
//			if (content1 == undefined) {
//				content1="";
//			}
//			if (content2 == undefined) {
//				content2="";
//			}
//			
//			console.log("描述："+(content1+content2));
//			if (($("#replaceBox").prop("checked")==false && $("#replaceByBox").prop("checked") == false)||(content1 == "" && content2 == "")) {
//				//判断都不选或者都不填 数据不变
//			}else {
//				$("#replaceRelationship").val(content1+" "+content2);
//			}
//			
//			
//		
//		}
		
		//二级法律效力和二级项目赋值
		TwoLevelLink_domainValues("#lawClass","#lawClass2","#lawClassId_add");
		TwoLevelLink_domainValues("#proj","#projectClassNo2Index","#projClassId_add");
		//处理源文件名的书名号
		var rcontent = $("#content").val();
		if (!(rcontent==undefined ||rcontent==""||rcontent==null)) {
			if (ifHaveBookMark("#content")) {
				$("#fileName").val(rcontent.substring(rcontent.indexOf("《")+1,rcontent.length-1));
			}else {
				$("#fileName").val(rcontent);
			}
		}
	
		//处理解读文件名的书名号
		var content = $("#readContent").val();
		if (!(content==undefined ||content==""||content==null)) {
			if (ifHaveBookMark("#readContent")) {
				$("#readFileName").val(content.substring(content.indexOf("《")+1,content.length-1));
			}else {
				$("#readFileName").val(content);
			}
		}
		
		
		//异步提交
		submitForm("#addForm", home_url + "/admin/datamaintenance/standardlaw/add", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				$("#replaceBox").attr("checked",false);
				$("#replaceByBox").attr("checked",false);
				$("#replaceByInput").val("");
				$("#replaceInput").val("");
				alertDiag("新增成功!",function(){
					//刷新表格
					$("#standardlaw").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
		        alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//编辑法律法规
function editLegal(id){
	
	var myDialog = showDialogModal("编辑", home_url + "/admin/datamaintenance/standardlaw/viewedit/"+id, function(){
		
		var readIndex = "${readIndex}";
		var standardIndex = "${standardIndex}";
		var lawIndex = "${lawIndex}";
		
//		if ($("#lawClass").val() != readIndex) {
//			//处理代替修订信息 replaceBox
//			var content1,content2;
//			console.log("replaceBox："+$("#replaceBox").prop("checked"));
//			console.log("replaceByBox："+$("#replaceByBox").prop("checked"));
//			if ($("#replaceBox").prop("checked")!= undefined && $("#replaceBox").prop("checked")) {
//				var keyword = $("#keyword1").text();
////				if (!ifHaveBookMark("#replaceInput")) {
////					content1 = keyword +"《"+ ($("#replaceInput").val())+"》";
////				}else{
////					content1 = keyword + ($("#replaceInput").val());
////				}
//				
//				content1 = keyword +"《"+ ($("#replaceInput").val())+"》";
//			}
//			console.log("描述content1："+content1);
//			if ($("#replaceByBox").prop("checked")!= undefined && $("#replaceByBox").prop("checked")) {
//				var keyword = $("#keyword2").text();
//				if (keyword == '被代替') {
////					if (!ifHaveBookMark("#replaceByInput")) {
////						content2 = "被" +"《"+ ($("#replaceByInput").val())+"》"+"代替";
////					}else{
////						content2 = "被" + ($("#replaceByInput").val())+"代替";
////					}
//					content2 = "被" +"《"+ ($("#replaceByInput").val())+"》"+"代替";
//				}else {
//					
////					if (!ifHaveBookMark("#replaceByInput")) {
////						content2 =keyword +"《"+ ($("#replaceByInput").val())+"》";
////					}else {
////						content2 =keyword + ($("#replaceByInput").val());
////					}
//					content2 =keyword +"《"+ ($("#replaceByInput").val())+"》";
//				}
//				if ($("#lawClass").val() == lawIndex) {
//					content2 = content2 +  $("#keyword3").text();
//				}
//			}
//			console.log("描述content2："+content2);
//			if (content1 == undefined) {
//				content1="";
//			}
//			if (content2 == undefined) {
//				content2="";
//			}
//			console.log("描述："+(content1+content2));
//			if (($("#replaceBox").prop("checked")==false && $("#replaceByBox").prop("checked") == false)||(content1 == "" && content2 == "")) {
//				//判断都不选或者都不填 数据不变
//			}else {
//				$("#replaceRelationship").val(content1+" "+content2);
//			}
//		
//		}

		//二级法律效力和二级项目赋值
		TwoLevelLink_domainValues("#lawClass","#lawClass2","#lawClassId_e");
		TwoLevelLink_domainValues("#proj","#projectClassNo2Index","#projClassId_e");
		
		//处理源文件名的书名号
		var rcontent = $("#content").val();
		if (!(rcontent==undefined ||rcontent==""||rcontent==null)) {
			if (ifHaveBookMark("#content")) {
				$("#fileName").val(rcontent.substring(rcontent.indexOf("《")+1,rcontent.length-1));
			}else {
				$("#fileName").val(rcontent);
			}
		}
	
		//处理解读文件名的书名号
		var content = $("#readContent").val();
		if (!(content==undefined ||content==""||content==null)) {
			if (ifHaveBookMark("#readContent")) {
				$("#readFileName").val(content.substring(content.indexOf("《")+1,content.length-1));
			}else {
				$("#readFileName").val(content);
			}
		}
		
		//非失效状态隐藏的数据删除
		if ($("#lawStatus")==1 || $("#lawStatus")==3) {
			$("#cancelDate").val("");
		}
		//异步提交
		submitForm("#editForm", home_url + "/admin/datamaintenance/standardlaw/edit", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("编辑成功!",function(){
					//刷新表格
					$("#standardlaw").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
		        alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}


//删除法律法规
function delLegal(id){
	var rowObject = $("#standardlaw").jqGrid('getRowData',id);
	//console.log(rowObject);
	var content = null;
	if (rowObject.lawClassName != "解读") {
		content="此法律法规的解读文件也会一并删除，确定删除吗?";
	}
	delConfirmDiag(function() {
		
		$.ajax({
			
		    type: "post",
			url: home_url + "/admin/datamaintenance/standardlaw/del",
			data: {id:id},
		    dataType: "json",
		    success: function(data){
		    	if(data.state.value==0) {
		    		alertDiag("删除成功!",function(){
						//刷新表格
						$("#standardlaw").jqGrid().trigger("reloadGrid");
					});
				} else {
		            alertDiag(data.content);
		        }
			},
			error: function(){
				alertDiag("删除失败，请稍后重试");
			},
		});
	},'删除',content);

}
//设置表头
//function setTableHead(){
//	//console.log($("#headSettings").html());
//
//	var myDialog = dialog({
//		title : "表头设置",
//		width : "400px",
//		height :"200px",
//		content:$("#headSettings").html(),
//		lock : true,
//		okValue : '确定',
//		ok : function(){
//			//console.log($("#headObjs input[name=checkObj]:checked").val());
//			$("#headObjs").empty();
//			$("#headObjs input[name=checkObj]").each(function(){
//				var colObj=$("#standardlaw").jqGrid('getGridParam','colModel');
//				if ($(this).is(':checked')) {
//					console.log("选中编号:"+$(this).val());
//					var index = $(this).val();
//					$("#standardlaw").setGridParam().showCol(colObj[index].name);
//					//console.log(colObj[index].label+"是否隐藏:"+colObj[index].hidden);
//				}else {
//					var index = $(this).val();
//					$("#standardlaw").setGridParam().hideCol(colObj[index].name);
//				}
//				
//			});
//			
//			var colObj=$("#standardlaw").jqGrid('getGridParam','colModel');
//			
//			$(colObj).each(function(index,item){
//				//console.log(index+"--"+item.label+"--"+item.hidden);
//				var html;
//				if (index==0||index ==1 || index == colObj.length-1 ) {
//					
//				}else if (index==2) {
//					html = "<div class='align-left'><input type='checkbox' value='"+index+"'  class='ace tg sz' name='checkObj' disabled='disabled' checked /><span class='lbl'></span>"+item.label+"</div>";
//				}else if (item.hidden) {
//					html = "<div class='align-left'><input type='checkbox' value='"+index+"'  class='ace tg sz' name='checkObj'/><span class='lbl'></span>"+item.label+"</div>";
//				}else{
//					html =  "<div class='align-left'><input type='checkbox' value='"+index+"'  class='ace tg sz' name='checkObj' checked/><span class='lbl'></span>"+item.label+"</div>";
//				}
//				
//				$("#headObjs").append(html);
//			})
//		},
//		cancelValue : '取消',
//		cancel : function() {
//		}
//	});
//	myDialog.showModal();
//}


//修改项目
function changePro(){
		//获取选中行的ids
		var ids=$("#standardlaw").jqGrid('getGridParam','selarrrow');
		if (ids=="" ||ids==null) {
			alertDiag("请选择要修改项目的行!");
			return false;
		}
//		console.log(ids);
		var lawIds = "";
    	for (var i = 0; i < ids.length; i++) {
    		lawIds+=(ids[i]+",");
    		
    		var rowData = $("#standardlaw").jqGrid('getRowData',ids[i]);
    		if (rowData.lawClassName == "解读") {
//    			$("#alert-warning1").removeClass('hide');
    			alertDiag("请选择法律效力不为解读的行!");
    			return false;
			}
		}
    	
    	
    	var myDialog = showDialogModal("修改项目", home_url + "/admin/datamaintenance/standardlaw/page_changeProj", function(){
    		
    		if ($("#changeProjItem2").val()=="" ||$("#changeProjItem2").val()==undefined ) {
    			alertDiag("请选择项目!");
    			return false;
			}
    		TwoLevelLink_domainValues("#changeProjItem","#changeProjItem2","#projClassId_changeProj");
    		//异步提交
    		submitForm("#changeProj", home_url + "/admin/datamaintenance/standardlaw/changeProj?ids="+lawIds, null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				
    				alertDiag("修改成功!",function(){
    					//刷新表格
    					$("#standardlaw").jqGrid().trigger("reloadGrid");
    					setTimeout(function(){
    						myDialog.close().remove();
    					},1)
    				});
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
    	
}

function  delByBatch(){
	//获取选中行的ids
	var ids=$("#standardlaw").jqGrid('getGridParam','selarrrow');
	if (ids=="" ||ids==null) {
		alertDiag("请选择要删除的行!");
		return false;
	}
	console.log(ids);
	var lawIds = "";
	var content="确定要删除吗？";
	for (var i = 0; i < ids.length; i++) {
		lawIds+=(ids[i]+",");
		var rowData = $("#standardlaw").jqGrid('getRowData',ids[i]);
		if (rowData.lawClassName != "解读") {
			content = "法律法规下可能有解读文件,确定删除吗?";
		}
	}
	
	delConfirmDiag(function() {
		
		$.ajax({
			
		    type: "GET",
			url: home_url + "/admin/datamaintenance/standardlaw/delLawByBatch",
			data: {lawIds:lawIds},
		    dataType: "json",
		    success: function(data){
		    	if(data.state.value==0) {
		    		alertDiag("删除成功!",function(){
						//刷新表格
						$("#standardlaw").jqGrid().trigger("reloadGrid");
					});
				} else {
		            alertDiag(data.content);
		        }
			},
			error: function(){
				alertDiag("删除失败，请稍后重试");
			},
		});
	},'删除',content);
}

//重置按钮
function resetSearch(){
	//实施时间
	$("#executeDateStartTime").text("");
	$("#executeDateEndTime").text("");
	$("#executeDateStart").val("");
	$("#executeDateEnd").val("");
	$("#date-range-picker").val("");
	//上传时间
	$("#uploadDateStartTime").text("");
	$("#uploadDateEndTime").text("");
	$("#uploadDateStart").val("");
	$("#uploadDateEnd").val("");
	$("#id-date-range-picker-1").val("");
	//文号和标准名称
	$("#search").val("");
	//状态
	$("#reset-zt").val("");
	//行业
	$("#reset-hy").val("");
	//法律效力
	$("#lawClassifyItem").val("");
	$("#lawClassifyItem2").val("");
	$("#lawClassifyItem2").parent().addClass('hide');
	
	//项目
	$("#projItem").val("");
	$("#projItem2").val("");
	$("#projItem2").parent().addClass('hide');
	
	$("#isReset").val(true);
	//刷新表格
//	$("#standardlaw").jqGrid().trigger("reloadGrid");
}

//法律法规2级联动
function TwoLevelLink_classify(listenEleId,appendEleId,content){
	$(listenEleId).on('change',function(){
		$(appendEleId).empty();
		if ($(this).val()!='') {
			

			var id = $(this).val();
			$(appendEleId).parent().removeClass('hide');
			$.ajax({
				url:home_url+"/admin/datamaintenance/standardlaw/getLawClassify",
				type:"GET",
				data:{
					id:id
				},
				success:function(data){
					if (data.result == "" ||data.result == undefined) {
						$(appendEleId).parent().addClass('hide');
					}else {
						var optEle="<option value=''>"+content+"</option>";
						$(data.result).each(function(index,item){
							
							optEle += "<option value="+item.id+">"+item.name+"</option>"
						});
						
						$(appendEleId).append(optEle);
					}
					
				}
			});
		
		}else {
			$(appendEleId).parent().addClass('hide');
		}
	})
}
//项目二级联动
function TwoLevelLink_projClassify(listenEleId,appendEleId,content){
	
	$(listenEleId).on('change',function(){
		$(appendEleId).empty();
		if ($(this).val()!='') {
			var id = $(this).val();
			$(appendEleId).parent().removeClass('hide');
			$.ajax({
				url:home_url+"/admin/datamaintenance/standardlaw/getProj",
				type:"GET",
				data:{
					id:id
				},
				success:function(data){
					var optEle="<option value=''>"+content+"</option>";
					$(data.result).each(function(index,item){
						console.log(item);
						optEle += "<option value="+item.id+">"+item.projName+"</option>"
					});
					
					$(appendEleId).append(optEle);
				}
			});
		}else {
			$(appendEleId).parent().addClass('hide');
		}
	})
}
/**
 * ****************************************
 * ************新增编辑共用函数*************
 * ****************************************
 */
//取消隐藏
function  cancleHide(){
//	console.log("取消隐藏");
	//取消隐藏
	//文号
	$("#wh").removeClass("hide");
	//所属项目
	$("#ssxm").removeClass("hide");
	//所属行业
	$("#sshy").removeClass("hide");
	//颁布部门
	$("#bbbm").removeClass("hide");
	//状态
	$("#zt").removeClass("hide");
	//颁布日期
	$("#bbrq").removeClass("hide");
	//实施日期
	$("#ssrq").removeClass("hide");
	//失效日期
	$("#lnvalidDate").removeClass("hide");
	//代替修订
	$("#changeItems").removeClass("hide");
	//解读文件
	$("#jdwj").removeClass('hide');
	//解读名称
	$("#readNameId").removeClass('hide');
	//描述
	$("#descrip").removeClass("hide");
}


//新增、编辑页 搜索法律法规
function searchLaw(isEmpty){
	
//	console.log(isEmpty);
	if (isEmpty==true) {
		$("#belongs input[name=lawId]").parent().remove();
	}
	if ($("#lawSearch").val()=='') {
		alertDiag("请输入标准名称或文号!");
	}else {
		var name_no = $("#lawSearch").val();
		$.ajax({
			url:home_url+"/admin/datamaintenance/standardlaw/getLawByName_no",
			type:"GET",
			data:{name_no:name_no},
			success:function(data){
				
				if (data.state.value == 0) {
					console.log(data.result);
					//$("#lawSearch").val("");
					$("#belongs input[name=lawId]").parent().remove();
					if (data.result.length == 1) {
						var html = "<div class='align-left'><label> <input name='lawId' type='radio' value='"+data.result[0].id+"' class='ace' checked='cheked' /><span class='lbl'>"+data.result[0].fileName+"("+data.result[0].fileNo+")</span></label></div>";
						$("#belongs").append(html);
					}else {
						$(data.result).each(function(index,item){
							var html = "<div class='align-left'><label > <input name='lawId' type='radio' value='"+item.id+"' class='ace'  /><span class='lbl'>"+item.fileName+"("+item.fileNo+")</span></label></div>";
							$("#belongs").append(html);
						});
					}
					
				}else {
					
					alertDiag(data.content);
					
				}
				
			}
		});
	}
}

//判断是否添加书名号
function ifHaveBookMark(EleId){
	var content = $(EleId).val();
	if (content.indexOf("《") == 0 && content.indexOf("》") == content.length-1) {
		return true;
	}else if(content.indexOf("《") == -1 && content.indexOf("》") == -1){
		return false;
	}
}
//
////单纯做一个监听
function listen(ELeId,inputId){
	//监听
	$(ELeId).bind("input propertychange",function(event){
		var content = $(ELeId).val();
		
		$(inputId).val(content);
		
	});
}

function selectLawClass_simple(lawIndex,standardIndex,readIndex){
	//所属法律法规标准 隐藏
	$("#ssfffgbz").addClass("hide");
	if ($("#lawClass").val()=="") {
		cancleHide();
	}
	
	if($("#lawClass").val() == lawIndex){
		$("#keyword1").text("修订为");
		$("#keyword2").text("由");
		$("#keyword3").removeClass('hide');
		
		cancleHide();
	}
	if($("#lawClass").val() ==standardIndex){
		$("#keyword1").text("代替");
		$("#keyword2").text("被代替");
		$("#keyword3").addClass('hide');
		
		cancleHide();
	}
	
	if($("#lawClass").val() ==readIndex){
		//清空并隐藏
		//文号
		$("#wh").addClass("hide");
		$("#fileNo").val("");
		//所属项目
		$("#ssxm").addClass("hide");
		$("#projectClassNo1").val("");
		$("#proj").val("");
		//状态(选中解读时，新增|编辑的时候去掉状态 后台处理该状态 需求变更 by 王自强)
		$("#zt").addClass("hide");
		//所属行业
		$("#sshy").addClass("hide");
		//颁布部门
		$("#bbbm").addClass("hide");
		$("#departmentIssued").val("");
		//所属法律法规标准 显示
		$("#ssfffgbz").removeClass("hide");
		//颁布日期
		$("#bbrq").addClass("hide");
		$("#releaseDate").val("");
		//实施日期
		$("#ssrq").addClass("hide");
		$("#executeDate").val("");
		//失效日期
		$("#lnvalidDate").addClass("hide");
		$("#cancelDate").val("");
		//代替修订
 		$("#changeItems").addClass("hide");
 		$("#replaceRelationship").val("");
 		//解读文件
 		$("#jdwj").addClass('hide');
 		$("#readFileText").val("");
 		$("#readFile_upload").val("");
 		//解读名称
 		$("#readNameId").addClass('hide');
 		$("#readContent").val("");
 		$("#readFileName").val("");
		//描述
 		$("#descrip").addClass("hide");
 		$("#descripArea").val("");
		
	}
	$("#lawClassNo1Name").val($("#lawClass option:selected").text());
}
function selectLawClass_ajax(){
	$.ajax({
		url:home_url + "/admin/datamaintenance/standardlaw/getLawClass1Ids/",
		type:"GET",
		success:function(data){
			console.log(data.result);
			selectLawClass_simple(data.result[0],data.result[1],data.result[2]);
		}
	})
}
//选中法律法规效力事件
function selectLawClass(){
	selectLawClass_ajax();
}

function lnvalid_ajax(lawIndex,standardIndex,readIndex){
	if($("#lawClass").val() == readIndex){
		//赋值
		$("#lawStatus").val($("#legalStatus").val());
		$("#status").val($("#legalStatus option:selected").text());
		
	}
	if ($("#lawClass").val == standardIndex) {
		$("#keyword3").addClass('hide');
	}
	//赋值
	$("#lawStatus").val($("#legalStatus").val());
	$("#status").val($("#legalStatus option:selected").text());
	
	if ($("#legalStatus").val() != 2) {
		$("#replaceByBox").addClass('hide');
		$("#keyword2").addClass('hide');
		//$("#replaceBy").addClass('hide');
		$("#keyword3").addClass('hide');
		$("#replaceByInput").addClass('hide');
	}
	if ($("#legalStatus").val() == 2) {
		$("#replaceByBox").removeClass('hide');
		$("#keyword2").removeClass('hide');
		//$("#replaceBy").addClass('hide');
		if ($("#lawClass").val() == lawIndex) {
			//选中法律法规 显示修订
			 $("#keyword3").removeClass('hide');
		}else  {
			$("#keyword3").addClass('hide');
		}
		$("#replaceByInput").removeClass();
	}
	if($("#legalStatus").val() == 4 ||$("#legalStatus").val() == 2){
		
		$("#lnvalidDate").show();
	}else{
		
		$("#lnvalidDate").hide();
	}
}
//状态选中事件
function lnvalid(){
	if ($("#legalStatus").val() == undefined || $("#legalStatus").val() == "") {
		if ($("#lawClass").val == undefined || $("#lawClass").val == "") {
			$("#keyword3").addClass('hide');
		}
		return false;
	}
	
	$.ajax({
		url:home_url + "/admin/datamaintenance/standardlaw/getLawClass1Ids/",
		type:"GET",
		success:function(data){
			
			lnvalid_ajax(data.result[0],data.result[1],data.result[2]);
		}
	})
	
}
//项目选中事件
function selectProj(){
	if ($("#proj").val()==""||$("#proj").val()== undefined) {
		return false;
	}
//	console.log("项目:"+$("#proj option:selected").text());
	$("#projectClassNo1").val($("#proj option:selected").text());
	
	
}
