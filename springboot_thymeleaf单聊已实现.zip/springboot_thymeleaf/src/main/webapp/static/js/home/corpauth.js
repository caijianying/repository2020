//操作列
function actionformatter(cellvalue, options, rowObject){
    
	var info = '<a href="javascript:corpAuthEdit(\''+rowObject.id+'\')" class="ui-pg-div"><i class="ui-icon icon-pencil"></i></a>';
	//info += '<a href="'+home_url+'/admin/account/companyservicerecord?cid='+cellvalue+'" class="ui-pg-div" target="_blank"><i class="ui-icon icon-ui-icon icon-edit blue"></i></a>';
	return info;                
}

//企业名称
function fullnameformatter(cellvalue, options, rowObject){
	
    var accountCompanyView = $("#accountCompanyView").val() != undefined ? true : false;
	
	var info = "";
	
	if(accountCompanyView){
		
		info = '<a href="'+home_url+'/admin/account/companyaccount/viewcompany/'+rowObject.cid+'" target="_blank">'+cellvalue+'</a>';
	}else{
		
		info = cellvalue;
	}
	return info;
}

//审核
function corpAuthEdit(id){
	
	var accountCompanyEdit = $("#accountCompanyEdit").val() != undefined ? true : false;
	
	if(accountCompanyEdit){
		
		var myDialog = showDialogModal("审核", home_url + "/admin/home/corpauth/viewedit/"+id, function(){
			//异步提交
			submitForm("#editForm", home_url + "/admin/home/corpauth/edit", null, function(data){
				_contentLoadTriggered=false;
				if(data.state.value==0) {
					alertDiag("审核完成!",function(){
						//刷新表格
						$("#corpauth").jqGrid().trigger("reloadGrid");
						setTimeout(function(){
							myDialog.close().remove();
						},1)
					});
				}else {
			        alertDiag(data.content);
			    }
			},'json');
			return false;
		}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}