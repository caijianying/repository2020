//用户名称
function usernameformatter(cellvalue, options, rowObject){
	
	var accountUserView = $("#accountUserView").val() != undefined ? true : false;
	
	var info = "";
	
	if(accountUserView){
		
		info = '<a href="'+home_url+'/admin/account/useraccount/viewuser/'+rowObject.businessId+'" target="_blank">'+cellvalue+'</a>';
	}else{
		
		info = cellvalue;
	}
	return info;
}

//企业名称
function fullnameformatter(cellvalue, options, rowObject){
	
	var accountCompanyView = $("#accountCompanyView").val() != undefined ? true : false;
	
    var info = "";
	
	if(accountCompanyView){
		
		info = '<a href="'+home_url+'/admin/account/companyaccount/viewcompany/'+rowObject.businessId+'" target="_blank">'+cellvalue+'</a>';
	}else{
		
		info = cellvalue;
	}
	return info;
}

//用户操作列
function userAccountEdit(cellvalue, options, rowObject){
    
	var accountUserView = $("#accountUserView").val() != undefined ? true : false;
	
	var info = "";
	
	if(accountUserView){
		
		info = '<a href="'+home_url+'/admin/account/userservicerecord?uid='+cellvalue+'" class="ui-pg-div" target="_blank"><i class="ui-icon icon-ui-icon icon-edit blue"></i></a>';
	}else{
		
		info = '<a href="javascript:alertDiag(\'该用户无此操作权限\')" class="ui-pg-div" target="_blank"><i class="ui-icon icon-ui-icon icon-edit blue"></i></a>';
	}
	return info;                
}

//企业操作列
function companyAccountEdit(cellvalue, options, rowObject){
    
    var accountCompanyView = $("#accountCompanyView").val() != undefined ? true : false;
	
	var info = "";
	
	if(accountCompanyView){
		
		info = '<a href="'+home_url+'/admin/account/companyservicerecord?cid='+cellvalue+'" class="ui-pg-div" target="_blank"><i class="ui-icon icon-ui-icon icon-edit blue"></i></a>';
	}else{
		
		info = '<a href="javascript:alertDiag(\'该用户无此操作权限\')" class="ui-pg-div" target="_blank"><i class="ui-icon icon-ui-icon icon-edit blue"></i></a>';
	}
	return info;             
}