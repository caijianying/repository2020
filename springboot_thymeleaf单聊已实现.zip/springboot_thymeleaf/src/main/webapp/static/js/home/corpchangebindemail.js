//企业名称
function fullnameformatter(cellvalue, options, rowObject){
	
	var accountCompanyView = $("#accountCompanyView").val() != undefined ? true : false;
	
	var info = "";
	
	if(accountCompanyView){
		
		info = '<a href="'+home_url+'/admin/account/companyaccount/viewcompany/'+rowObject.cid+'" target="_blank">'+cellvalue+'</a>';
	}else{
		
		info = cellvalue;
	}
	return info;
}

//审核
function corpChangeBindEmailEdit(id){
	
	var homeEmailEdit = $("#homeEmailEdit").val() != undefined ? true : false;
	
	if(homeEmailEdit){
		
		var myDialog = showDialogModal("审核", home_url + "/admin/home/corpchangebindemail/viewedit/"+id, function(){
			//异步提交
			submitForm("#editForm", home_url + "/admin/home/corpchangebindemail/edit", null, function(data){
				_contentLoadTriggered=false;
				if(data.state.value==0) {
					alertDiag("审核完成!",function(){
						//刷新表格
						$("#corpchangebindemail").jqGrid().trigger("reloadGrid");
						setTimeout(function(){
							myDialog.close().remove();
						},1)
					});
				}else {
			        alertDiag(data.content);
			    }
			},'json');
			return false;
		}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}	
}