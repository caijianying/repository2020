//操作列
function actionformatter(cellvalue, options, rowObject){
    
	var info = '<a href="javascript:userCertificationEdit(\''+rowObject.id+'\')" class="ui-pg-div"><i class="ui-icon icon-pencil"></i></a>';
	//info += '<a href="'+home_url+'/admin/account/userservicerecord?cid='+cellvalue+'" class="ui-pg-div" target="_blank"><i class="ui-icon icon-ui-icon icon-edit blue"></i></a>';
	return info;                
}

//用户名称
function usernameformatter(cellvalue, options, rowObject){
	
    var accountUserView = $("#accountUserView").val() != undefined ? true : false;
	
	var info = "";
	
	if(accountUserView){
		
		info = '<a href="'+home_url+'/admin/account/useraccount/viewuser/'+rowObject.userId+'" target="_blank">'+cellvalue+'</a>';
	}else{
		
		info = cellvalue;
	}
	return info;
}

//审核
function userCertificationEdit(id){
	
    var accountUserEdit = $("#accountUserEdit").val() != undefined ? true : false;
	
	if(accountUserEdit){
		
		var myDialog = showDialogModal("审核", home_url + "/admin/home/usercertification/viewedit/"+id, function(){
			//异步提交
			submitForm("#editForm", home_url + "/admin/home/usercertification/edit", null, function(data){
				_contentLoadTriggered=false;
				if(data.state.value==0) {
					alertDiag("审核完成!",function(){
						//刷新表格
						$("#usercertification").jqGrid().trigger("reloadGrid");
						setTimeout(function(){
							myDialog.close().remove();
						},1)
					});
				}else {
			        alertDiag(data.content);
			    }
			},'json');
			return false;
		}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}	
}