$(function(){
	jQuery('#gtreetable').gtreetable({
		'nodesWrapper' : 'data',
		'languages' : 'zh-CN',
	  'source': function (id) {
	    return {
	      type: 'GET',
	      url: '/agent/agentbusiness/ztreeListData',
	      data: { 'pid': id },        
	      dataType: 'json',
	      error: function(XMLHttpRequest) {
	        alert(XMLHttpRequest.status+': '+XMLHttpRequest.responseText);
	      }
	    }
	  }
//	  ,'templateSelector' : '#gtreetable' 
	});
	
	$(".ui-jqgrid-bdiv").closest(".ui-jqgrid-bdiv").css({ 'overflow-x': 'hidden' });
});

var setting = {
    view : {
    	selectedMulti: false
	},
	edit : {
		enable : true,
		editNameSelectAll : true
	},
	async: {
        enable: true,
        autoParam: ["id"],
        url: home_url+"/admin/agent/agentbusiness/getTree",
        dataFilter: filter
    },
				
	data : {
		key: {
			name: "name"
		},
		simpleData : {
		   enable : true,//设置 zTree 是否开启异步加载模式
		   idKey : "id", // id编号命名     
           pIdKey : "pId", // 父id编号命名 
		}
	},
	showLine : true,//是否显示节点间的连线
	expandSpeed : "fast", //设置 zTree节点展开、折叠时的动画速度或取消动画(三种默认定义："slow", "normal", "fast")或 表示动画时长的毫秒数值(如：1000)    
	 
};

$(document).ready(function() {
	// 初始化树节点
	$.fn.zTree.init($("#treeDemo"), setting);
});

function zTreeOnAsyncSuccess(event, treeId, treeNode, msg) {
    if(treeNode==null){
	    var zTree = $.fn.zTree.getZTreeObj("treeDemo");
		nodes = zTree.getNodes();
		for (var i=0, l=nodes.length; i<l; i++) {
		    zTree.expandNode(nodes[i], true, false, false);
		}
		asyncNodes(zTree.getNodes());
		if (!goAsync) {
		    curStatus = "";
		}
	}
};
	
function asyncNodes(nodes) {
	if (!nodes) return;
	curStatus = "async";
	var zTree = $.fn.zTree.getZTreeObj("treeDemo");
	for (var i=0, l=nodes.length; i<l; i++) {
	    if (nodes[i].isParent && nodes[i].zAsync) {
	        asyncNodes(nodes[i].children);
	    } else {
	        goAsync = true;
	        zTree.reAsyncChildNodes(nodes[i], "refresh", true);
	    }
	}
}
	
//ajax加载之后过滤
function filter(treeId, parentNode, childNodes) {
	if (!childNodes) return null;
	for (var i=0, l=childNodes.length; i<l; i++) {
	    childNodes[i].name = childNodes[i].name.replace(/\.n/g, '.');
	}
	return childNodes;
}

//新增业务员
function addAgentBusiness(){
	
	var myDialog = showDialogModal("新增", home_url + "/admin/agent/agentbusiness/viewadd/", function(){
		
		//异步提交
		submitForm("#addForm", home_url + "/admin/agent/agentbusiness/add", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("新增成功!",function(){
					//刷新表格
					$("#agentbusiness").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
				alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//修改业务员
function editAgentBusiness(id){
	
    var myDialog = showDialogModal("编辑", home_url + "/admin/agent/agentbusiness/viewedit/"+id, function(){
		
		//异步提交
		submitForm("#editForm", home_url + "/admin/agent/agentbusiness/edit", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("编辑成功!",function(){
					//刷新表格
					$("#agentbusiness").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
		        alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//删除业务员
function delAgentBusiness(id) {
	
	delConfirmDiag(function() {
		
		$.ajax({
			
		    type: "post",
			url: home_url+"/admin/agent/agentbusiness/del/"+id,
			data: {},
		    dataType: "json",
		    success: function(data){
		    	if(data.state.value==0) {
		    		alertDiag("删除成功!",function(){
						//刷新表格
						$("#agentbusiness").jqGrid().trigger("reloadGrid");
					});
				} else {
		            alertDiag(data.content);
		        }
			},
			error: function(){
				alertDiag("删除失败，请稍后重试");
			},
		});
	});
}