//******代理商管理页********
function agentBasicInfoSearch(){
	if ($(".agentArea").val()==null||$(".agentArea").val()=="") {
		$(".cityId").val("");
		$(".areaId").val("");
	}
	jqGridRedraw($("#searchForm").serializeObject());
}
//操作列
function optformatter(cellvalue, options, rowObject){
    
	var fun = "";
	var title = "";
	var css = "";
	
    if(rowObject.isForbidden == false){
		
    	fun = "javascript:disable('"+cellvalue+"');"
		title = "屏蔽";
		css = "ui-icon icon-ban-circle";
	}else{
		
		fun = "javascript:enable('"+cellvalue+"');"
		title = "解锁";
		css = "ui-icon icon-key";
	}
    
    var eye_btn = '<a href="'+home_url+'/admin/agent/agentbasicinfo/basic_info?agentBusinessId='+rowObject.agentBusinessId+'" class="ui-pg-div" target="_blank"><i class="ui-icon icon-ui-icon icon-eye-open blue"></i></a>'; 
    
    var agentBasicinfoEdit = $("#agentBasicinfoEdit").val() != undefined ? true : false;
	
    var edit_btn = "";
    
    if(agentBasicinfoEdit){
    	
    	edit_btn = '<a href="'+home_url+'/admin/agent/agentbasicinfo/viewedit?agentBusinessId='+rowObject.agentBusinessId+'" class="ui-pg-div" target="_blank"><i class="ui-icon icon-ui-icon icon-pencil"></i></a>';
    	
    }else{
		
    	edit_btn = '<a href="javascript:alertDiag(\'该用户无此操作权限\')" class="ui-pg-div" target="_blank"><i class="ui-icon icon-ui-icon icon-pencil"></i></a>';
	}
    var ban_btn = '<a href="'+fun+'" class="ui-pg-div" title="'+title+'"><i class="'+css+'"></i></a>';
	
	var btn = eye_btn + edit_btn + ban_btn;
	
	return btn;   
} 

function addAgentBasicinfo(){
	
    var agentBasicinfoEdit = $("#agentBasicinfoEdit").val() != undefined ? true : false;
	
    if(agentBasicinfoEdit){
    	
    	window.location.href = home_url + "/admin/agent/agentbasicinfo/viewadd/";
	}else{
		
		alertDiag("该用户无此操作权限");
	}	
}

//代理商禁用
function disable(agentBusinessId){
	
    var agentBasicinfoEdit = $("#agentBasicinfoEdit").val() != undefined ? true : false;
	
    if(agentBasicinfoEdit){
    	
    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/agent/agentbasicinfo/disable/"+agentBusinessId,
    		data: {},
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    		    	alertDiag("用户已禁用!",function(){
    					//刷新表格
    					$("#agentbasicinfo").jqGrid().trigger("reloadGrid");
    				});
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("操作失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//代理商解除禁用
function enable(agentBusinessId){
	
    var agentBasicinfoEdit = $("#agentBasicinfoEdit").val() != undefined ? true : false;
	
    if(agentBasicinfoEdit){
    	
    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/agent/agentbasicinfo/enable/"+agentBusinessId,
    		data: {},
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    				alertDiag("代理商已解除禁用!",function(){
    					//刷新表格
    					$("#agentbasicinfo").jqGrid().trigger("reloadGrid");
    				});
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("操作失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//******代理商新增页********
function ztreeConfirm(){
	console.log("nodename:"+$(".NodeName").text())
		if ($(".NodeName").text()=="") {
			alertDiag("请选择业务员!");
			//$("#myModal").attr("aria-hidden",false);
		}else{
			var ele = $("#businessName");
		    ele.text($(".NodeName").text());
		    ele.removeClass("hide");
		    $("#businessAdd").remove();
		    $("#cancel").click();
		}
	 	
}

function createTree(zNodes){
	var setting = {
			view: {  
		        dblClickExpand: false  
		    }, 
			check: {
				enable: true,
				chkStyle: "radio",
			},
			data: {
				simpleData: {
					enable: true,
					idKey: "id",
					pIdKey: "pid"
				},
				key : {
	                name : "name",
	                checked: "isChecked"
	            }
			},
			callback: {  
				onCheck: zTreeOnCheck,
		        beforeCheck: zTreeBeforeCheck, 
		    }  
		
		};

	
		console.log(zNodes);
		var code;		
		function setCheck() {
			var type = $("#level").attr("checked")? "level":"all";
			setting.check.radioType = type;
			showCode('setting.check.radioType = "' + type + '";');
			$.fn.zTree.init($("#treeDemo"), setting,zNodes);
		}
		function showCode(str) {
			if (!code) code = $("#code");
			code.empty();
			code.append("<li>"+str+"</li>");
		}
		
	  //回调函数

	   function zTreeBeforeCheck(treeId, treeNode) {
		  	
	        return !(treeNode.isParent&&treeNode.id==0);//当是父节点 返回false 不让选取
	   }
	   function zTreeOnCheck(event, treeId, treeNode) {
				if (treeNode.isChecked) {
					console.log("选中!!treeNodeName:"+treeNode.name);
				    var e = $(".NodeName");
				    e.text(treeNode.name);
				   
				    //赋值pid
				    $("#parentId").val(treeNode.id);
				}
		   		
			
		}
		$(document).ready(function(){
			setCheck();			
			$("#level").bind("change", setCheck);
			$("#all").bind("change", setCheck);
		});
}
function formTree(){
	$.ajax({
        url : home_url + '/admin/agent/agentbasicinfo/add/ztreeListData',
        async : true,
        dataType : 'json',
        success : function(data) {
            console.log(data);
            //生成树
            createTree(data.result);
        },
        error : function() {
        	alertDiag("生成树失败！！！")
        }
    });
	
}
//添加提成比例
function addPayment(){
	
	var html = "";
	html = '<div class="bili-jisuan-group mt10 paymentItem">'
		+ '<input  type="number" class="paymentRows"   placeholder="请填写金额（数字）"> '
		+ '- <input  type="number" class="paymentOffset"   placeholder="请填写金额（数字）"> '
		+ ': <input  type="number" class="paymentScale"  placeholder="请填写比例（数字）"> %'
		+ '</div>';
	$("#paymentsSpan").append(html);
}


//弹框单选行政区域(代理区域)
function addForm_district_selected(data){
	console.info(data);
	var html = '';
	html = '<div class="city-picker-selector  mb10" >'
		+ '<div class="province area_item">'
		+ '	<a href="javascript:;" class="area_item_in reveal df-color" >'+data.provinceName+'</a>'
		+ '	<input type="hidden" class="province_selected" " value="'+data.provinceId+'" >'
		+ '</div>'
		+ '<div class="city area_item">'
		+ '	<a href="javascript:;" class="area_item_in reveal df-color forbid">'+data.cityName+'</a>'
		+ '	<input type="hidden" class="city_selected"  "  value="'+data.cityId+'" >'
		+ '</div>'
		+ '<div class="area area_item">'
		+ '	<a href="javascript:;" class="area_item_in reveal df-color forbid">'+data.areaName+'</a>'
		+ '	<input type="hidden" class="addForm_area_selected"  value="'+data.areaId+'" >'
		+ '</div>'
		+ '</div>'
		+ '<div class="clear"></div>';
	$("#cityPicker-groupDIV").append(html);
	
}
//弹框单选行政区域(代理商所在区域)
function addForm_area_selected(data){
	console.info(data);
	var html = '';
	html = '<div class="city-picker-selector1  mb10" >'
		+ '<div class="province area_item">'
		+ '	<a href="javascript:;" class="rea_item_in reveal df-color" >'+data.provinceName+'</a>'
		+ '	<input type="hidden" class="province_selected" " value="'+data.provinceId+'" >'
		+ '</div>'
		+ '<div class="city area_item">'
		+ '	<a href="javascript:;" class="rea_item_in reveal df-color forbid">'+data.cityName+'</a>'
		+ '	<input type="hidden" class="city_selected"  name="cityId"  value="'+data.cityId+'" >'
		+ '</div>'
		+ '<div class="area area_item">'
		+ '	<a href="javascript:;" class="rea_item_in reveal df-color forbid">'+data.areaName+'</a>'
		+ '	<input type="hidden" class="addForm_area_selected" name="areaId" value="'+data.areaId+'" >'
		+ '</div>'
		+ '</div>'
		+ '<div class="clear"></div>';
	$("#area-cityPicker-groupDIV").append(html);
	$("#agentAreaAdd").remove();
	
}

function createPromCode(){
	var treeObj=$.fn.zTree.getZTreeObj("treeDemo");
    
	
    //获取业务员
      var nodes=treeObj.getCheckedNodes(true);
    	if (nodes[0]==undefined) {
    		alertDiag("请选择业务员！");
    		return false;
		} 
     console.log("业务员姓名:"+nodes[0].name); 
	 console.log("业务员:"+nodes[0].id); 
	 console.log("业务员pid:"+nodes[0].pid); 
	
	$.ajax({
		url:home_url+"/admin/agent/agentbasicinfo/createPromCode",
		data:{
			businessId:nodes[0].id,
		},
		type:'POST',
		success:function(data){
			console.log(data);
			if (data.state.value==0) {
				$("#promCode_show").removeClass("hide");
				$("#promCode_show").text(data.result);
				$("#create_btn").remove();
				$("#promCode").val(data.result);
				
			}else {
				alertDiag(data.content);
			}
			
		},
		error: function(){
		    alertDiag("操作失败,请稍后重试");
		},
	})

}


function addForm_createAgentAreaIndex(){
	//生成行政区划索引值(代理区域)
       var areaModelItemIndex = 0;
        $(".city-picker-selector").each(function() {
        	$(this).children(".provice").each(function() {
        		$(this).children(".province_selected").attr("name", "areaModels["+(areaModelItemIndex)+"].proviceId");
        	})
        	
        	$(this).children(".city").each(function() {
        		$(this).children(".city_selected").attr("name", "areaModels["+(areaModelItemIndex)+"].cityId");
        	})
        	
        	$(this).children(".area").each(function() {
        		$(this).children(".addForm_area_selected").attr("name", "areaModels["+(areaModelItemIndex)+"].areaId");
        	})
        	
        	areaModelItemIndex ++;
        });
        console.log("生成ok,areaModelItemIndex="+areaModelItemIndex); 
}

function addForm_createAgentPaymentIndex(){
	//生成提成比例索引值 
    var paymentItemIndex = 0;
    $(".paymentItem").each(function() {
    	
    	$(this).children(".paymentOffset").attr("name", "payments["+(paymentItemIndex)+"].paymentOffset");
    	$(this).children(".paymentRows").attr("name", "payments["+(paymentItemIndex)+"].paymentRows");
    	$(this).children(".paymentScale").attr("name", "payments["+(paymentItemIndex)+"].paymentScale");
    	paymentItemIndex++;
    });		
}

function submitAddForm(){
	var treeObj=$.fn.zTree.getZTreeObj("treeDemo"),
    nodes=treeObj.getCheckedNodes(true);
    if (nodes[0]==undefined) {
		alertDiag("请选择业务员！");
		return false;
	   }
	 console.log("业务员:"+nodes[0].name);  
	 console.log("推广码:"+$("#promCode_show").text());  
	 if ($("#promCode_show").text()=="") {
		 alertDiag("请生成推广码！");
		 return false;
	} 
	 if ($("#fileField").attr("value")==null) {
		 alertDiag("请选择文件上传！");
			return false;
	}
	
	addForm_createAgentAreaIndex();
	
	addForm_createAgentPaymentIndex();
	
	 console.log($("#agent_add_form").serialize());
     	//异步提交
		 submitForm("#agent_add_form", home_url + "/admin/agent/agentbasicinfo/agentAdd", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag(data.content,function(){
					window.location.href = home_url + "/admin/agent/agentbasicinfo";
				});
				
			}else {
		        alertDiag(data.content);
		    }
		},'json');
}

//******代理商编辑页********

