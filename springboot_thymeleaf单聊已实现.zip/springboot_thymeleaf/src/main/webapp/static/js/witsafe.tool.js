/**
 * 通用对话框调用JS
 */
// 弹窗提示配置
function loaddefaultface(obj){
	obj.onerror = null;
	obj.src = home_url  + "/static/images/default_headpic.png";
}

/**
 * 企业基本信息查看器
 * @param cid
 */
function qiyeView(cid){
	showDialogModal("查看企业基本信息", home_url + "/ajax/company/view/"+cid, function(data){}, 650, 300);
}

/**
 * 查看用户基本信息
 * @param cid
 */
function userView(uid){
	showDialogModal("查看用户基本信息", home_url + "/ajax/user/view/"+uid, function(data){}, 650, 300);
}

//多选职业病危害因素
function multiSelectHarmfactor(callback) {
	// 弹出对话框
	var myDialog = dialog({
		title : '选择职业病危害因素',
		width : 800,
		height : 600,
		lock : true,
		okValue : '确定',
		ok : function() {
			var chk_value = [];
			
			
			//$('input[name="mselect_harmfactor_check_input"]:checked').each(
					
			$('li[name="checks"]').each(
					function() {
						var type = new Object();
						type.id = $(this).val();
						type.name = $(this).text();
						type.type = $(this).attr("rtype");
						//type.name = $(this).attr("valuetext");

						chk_value.push(type);
					});

			if (chk_value.length == 0) {
				alertDiag("还没有选择任何内容！");
				return false;
			}

			if (isFunction(callback)) {
				callback(chk_value);
			}
		},
		cancelValue : '取消',
		cancel : function() {
		}
	});
	// 获取多选页面内容（该内容最终生成静态文件）
	getSimplePage(home_url + '/admin/tool/mselect/harmfactors', function(data) {
		myDialog.content(data);
		// 为已选中的打勾
    });

	myDialog.showModal();
}

//多选医院
function multiSelectHospital(callback) {
	// 弹出对话框
	var myDialog = dialog({
		title : '选择医院',
		width : 600,
		height : 'auto',
		lock : true,
		okValue : '确定',
		ok : function() {
			var chk_value = [];
			
			$("input:checkbox[name='haIntentionHospital']:checked").each(
					function() {
						var type = new Object();
						type.id = $(this).attr("id");
						type.name = $(this).val();
						
						chk_value.push(type);
					});

			if (chk_value.length == 0) {
				alertDiag("还没有选择任何内容！");
				return false;
			}

			if (isFunction(callback)) {
				callback(chk_value);
			}
		},
		cancelValue : '取消',
		cancel : function() {
		}
	});
	// 获取多选页面内容（该内容最终生成静态文件）
	getSimplePage(home_url + '/admin/tool/mselect/hospital', function(data) {
		myDialog.content(data);
		// 为已选中的打勾
    });

	myDialog.showModal();
}

//弹出
function doctorGoodAt(id,callback){
	
	var myDialog = showDialogModal("选择", home_url + "/admin/tool/mselect/doctorgoodat/"+id, function(){
		
		var doctorGoodAt = "";
		var doctorGoodAtName = "";
		$('input[name="a"]:checked').each(function(){ 
			
			doctorGoodAt = doctorGoodAt + $(this).attr("id") + ",";
			doctorGoodAtName = doctorGoodAtName + $(this).val() + ",";
			
			if($(this).attr("paramGroup") == "doctor_disease_good_at"){
				$("#isOccDoctor").val("true");
			}
		}); 
        doctorGoodAt = doctorGoodAt.substring(0,doctorGoodAt.length-1);
		doctorGoodAtName = doctorGoodAtName.substring(0,doctorGoodAtName.length-1);

		var doctorGoodAtText = "";
		$("input[name='b']").each(function(){
			doctorGoodAtText = doctorGoodAtText + $(this).val() + ",";
		});
		doctorGoodAtText = doctorGoodAtText.substring(0,doctorGoodAtText.length-1);
		
		callback(doctorGoodAt,doctorGoodAtName,doctorGoodAtText);
		
	}, 600, "auto");
}

