﻿//专家实名认证
jQuery(function($) {
	var tpl = $("#tpl").html();
	//预编译模板
    var template = Handlebars.compile(tpl);
    
    Main.dataTableExamples["sample-table-1"] = $('#sample-table-1').dataTable({
		ajax: {
				type : "POST",
                url: "SpecBaseinfo/list"
            },
            serverSide: true,
            autoWidth: false,
            order: [],			//取消默认排序查询,否则复选框一列会出现小箭头
            processing: false,	//隐藏加载提示,自行处理
            searching: false,	//禁用原生搜索
            ordering : false,//是否开启本地排序
            pagingType: "bootstrap_full_number",
            columns: [
                {"data": null, "title": "序号", "className":"center", "width" : "80px", "targets" : "1"},
                {"data": "name", "title": "真实姓名", "className":"center"
                	,"render" : function(data, type, row,meta){
                		return '<a href="javascript:;" class="a-lookOver"  dataId='+ row.uid +'>'+ data +'</a>';
                	}},
                {"data": "uname", "title": "联系电话", "className":"center", "render" : function(data, type, row,meta) {
							if(data==undefined) return "——";
							return data; 
						}},
                {"data": "updatedatetime", "title": "申请时间 ", "className":"center", "render" : function(data, type, row,meta) {
							if(data != null && data !=""){
								return moment(new Date(data)).format("YYYY-MM-DD HH:mm");
							}
							return ""; 
						}},
//                {"data": "checkdatetime", "title": "认证时间 ", "className":"center", "render" : function(data, type, row,meta) {
//							if(data != null && data !=""){
//								return moment(new Date(data)).format("YYYY-MM-DD HH:mm");
//							}
//							return ""; 
//						}},
//                {"data": "checkstate", "title": "认证结果 ", "className":"center", "render" : function(data, type, row,meta) {
//							if(data == 1){
//								return "<font color='blue'>待认证</font>"; 
//							}else 	if(data == 2){
//								return "<font color='green'>认证通过</font>"; 
//							}else 	if(data == 3){
//								return "<font color='red'>认证失败</font>("+row.checkresult+")"; 
//							}
//						}},
                {"data": null, "title": "操作 ", "className":"center", "width" : "150px", "render" : function(data, type, row,meta) {
							var context =
	                        {
	                            func: [
	                                {"name": "查看", "fn": "checkView(\'" + row.id + "\')", "type": "eye-open"},
	                            ]
	                        };
	                        var html = template(context);
	                        return html;
						}}
            ]
           ,
            language: {//中文化
			        sProcessing: "处理中...",
			        sLengthMenu: "显示 _MENU_ 项结果",
			        sZeroRecords: "没有找到匹配的数据！",
			        sInfo: '<div class="btn-group fr"><div class="add-ym padding-tb6">总共 <font color="red">_TOTAL_</font> 条记录 '+    
		                    '&nbsp;&nbsp;共 <font color="red">_PAGES_</font> 页&nbsp;&nbsp;'+
		                     ' 当前所在第 <font color="red">_PAGE_</font> 页</div>',
			        sInfoEmpty: "显示第 0 至 0 项结果，共 0 项",
			        sInfoFiltered: "",
			        sInfoPostFix: "",
			        sSearch: "搜索:",
			        sEmptyTable: "暂无数据！",
			        sLoadingRecords: "载入中...",
			        sInfoThousands: ",",
			        oPaginate: {
			            sFirst: "首页",
			            sLast: "末页",
			            sNext : "下一页",
						sPrevious : "上一页"
			        },
			        oAria: {
			            "sSortAscending": ": 以升序排列此列",
			            "sSortDescending": ": 以降序排列此列"
			        }
		    	},
		    drawCallback : function(){//每次重绘后执行的方法
		    	var api = this.api();
				var startIndex= api.context[0]._iDisplayStart;
				// 获取到本页开始的条数
				api.column(0).nodes().each(function(cell, i) {
					// 此处 startIndex + i + 1;会出现翻页序号不连续，主要是因为startIndex的原因,去掉即可。
					cell.innerHTML = startIndex + i + 1;
					// cell.innerHTML = i + 1;
				}); 
				
				//查看用户信息
				$(".a-lookOver").click(function(){
					var id = $(this).attr('dataId');
		    		var page = Main.dataTableExamples["sample-table-1"].api().page();
		    		window.location.hash="#!"+ page + ",1";//用来记录跳转时dt的page 后面的数字标记为跳转的地方
		    		var id = $(this).attr('dataId');
		    		//后面的1用来区分从哪里跳过去的
		    		window.location.href=home_url + "/admin/account/UserAccount/getUser/"+id + window.location.hash;
				});
				
				var page = window.location.hash.replace("#!","");//返回的时候获取page
				if(page != ""){//dt跳页   page是页数
					window.location.hash="";//清空
					setTimeout(function(){//不知道什么原因跳转不延时一下  不会跳转
						Main.dataTableExamples["sample-table-1"].dataTable().fnPageChange(parseInt(page));
					},1)
					
			    }
				
				
				
		    }
            
    });
});
//查看认证详情
function checkView(id){
	showDialogModal("查看专家认证信息", 
		home_url + "/admin/home/SpecBaseinfo/detail/"+id, 
		function(data){
			//异步提交
			submitForm("#specInfoCheckForm", home_url + "/admin/home/SpecBaseinfo/checkState", null, function(data){
				_contentLoadTriggered=false;
				if(data.code==0) {
					alertDiag("已处理完成! " , refreshPage );
		        } else {
		        	alertDiag(data.content);
		        }
			},'json');
			
			return false;
		}, 600, 450, function(data){
			$('#specInfoCheckForm input[name="checkresult"]').typeahead({
		      source: function(query, process) {
		         return ["证件不符合！", "姓名不符合！", "身份证不符合！", "信息不正确！"];
		      },
		      highlighter: function(item) {
		          return "==>" + item + "<==";
		       },
		  
		       updater: function(item) {
		          //console.log("'" + item + "' selected.");
		          return item;
		       }
		   });
		});
}

//查看待实名认证详情
function baseinfoCheckView(id){
	showDialogModal("查看专家认证信息", 
		home_url + "/admin/home/SpecBaseinfo/detail/"+id, 
		function(data){
			//异步提交
			submitForm("#specInfoCheckForm", home_url + "/admin/home/SpecBaseinfo/checkState", null, function(data){
				_contentLoadTriggered=false;
				if(data.code==0) {
					alertDiag("已处理完成! " , refreshPage );
		        } else {
		        	alertDiag(data.content);
		        }
			},'json');
			
			return false;
		}, 600, 450, function(data){
			$('#specInfoCheckForm input[name="checkresult"]').typeahead({
		      source: function(query, process) {
		         return ["证件不符合！", "姓名不符合！", "身份证不符合！", "信息不正确！"];
		      },
		      highlighter: function(item) {
		          return "==>" + item + "<==";
		       },
		  
		       updater: function(item) {
		          //console.log("'" + item + "' selected.");
		          return item;
		       }
		   });
		});
}

function tg(){
	$(".btgneir").hide();
}

function btg(){
	$(".btgneir").show();
}
