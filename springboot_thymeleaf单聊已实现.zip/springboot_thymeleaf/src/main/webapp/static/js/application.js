window.onload = function() {
	var config = {
		id: "tg1",
		width: "800",
		renderTo: "div1",
		headerAlign: "left",
		headerHeight: "30",
		dataAlign: "left",
		indentation: "20",
		folderOpenIcon: "/static/images/zjjs_down.png",
		folderCloseIcon: "/static/images/zjjs_right.png",
		/*defaultLeafIcon: "static/images/zjjs_right.png",*/
		hoverRowBackground: "false",
		folderColumnIndex: "2",
		itemClick: "itemClickEvent",
		columns: [
		{
			headerText: "企业名称",
			dataField: "Companyname",
			headerAlign: "center",
			width:"18%",
		},
		{
			headerText: "产品",
			dataField: "product",
			headerAlign: "center",
			dataAlign: "center",
			width:"18%",
			/*,width: "100"
			hidden: false */
		},
		{
			headerText: "付款时间",
			dataField: "payTime",
			headerAlign: "center",
			dataAlign: "center",
			handler: "customOrgName",
			width:"15%",
			/*width: "100"*/
		},
		{
			headerText: "付款金额（元）",
			dataField: "money",
			headerAlign: "center",
			dataAlign: "center",
			width:"12%",
			/*width: "100"*/
		},
		{
			headerText: "提成（元）",
			dataField: "moneyGet",
			headerAlign: "center",
			dataAlign: "center",
			/*width: "100"*/
			width:"12%",
		},
		{
			headerText: "结算状态",
			dataField: "state",
			headerAlign: "center",
			dataAlign: "center",
			/*width: "50"*/
		},{
			headerText: "确认结算",
			dataField: "sure",
			headerAlign: "center",
			dataAlign: "center",
			/*width: "50"*/
		}],
		data: [
		/*state:0 已结算;1 未结算
		* sure:0 已结算;1 未结算
		*//*<button class='btn btn-default' disabled='disabled'>确认结算</button>*/
		{
			payTime: "2018年3月",money: "90000",moneyGet:"90000",state: "0",sure:"1",
			children: [{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "0",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "0",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "0",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "0",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "0",sure:""},
			]
		},{
			payTime: "2018年4月",money: "90000",moneyGet:"90000",state: "0",sure:"0",
			children: [{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
			]
		},
		{
			payTime: "2018年5月",money: "90000",moneyGet:"90000",state: "0",sure:"1",
			children: [{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
			]
		},
		{
			payTime: "2018年6月",money: "90000",moneyGet:"90000",state: "1",sure:"0",
			children: [{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "0",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "0",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
			]
		},
		{
			payTime: "2018年7月",money: "90000",moneyGet:"90000",state: "1",sure:"0",
			children: [{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "0",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
				{Companyname:"龙市科技",product:"职业健康管理系统",payTime: "2018/3/1",money: "90000",moneyGet:"90000",state: "1",sure:""},
			]
		}
		]
	};
	//debugger;
	var treeGrid = new TreeGrid(config);
	treeGrid.show()
}