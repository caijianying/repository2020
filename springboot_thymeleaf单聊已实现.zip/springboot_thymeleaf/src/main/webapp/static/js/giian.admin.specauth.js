﻿//专业家
$(function(){
	
})

//审核通过
function checkYes(id){
	delConfirmDiag(function(){
		var url= home_url + "/homePage/specauth/checkyes/"+id;
		post(url, {},function (data) {
			_contentLoadTriggered=false;
            if(data.code==0) {
            	alertDiag("审核成功!", refreshPage);
            } 
        });
		
		
	}, "审核?", "是否同意对该专家实名认证审核通过?");
}

//审核不通过
function checkNo(id){
	//初始化表单内容
	$('#companysoftCheckNoForm')[0].reset()
	//
	$("#checkid").val(id);
	
	var myDialog = dialog({
		title : '审核不通过原因',
		content : $('#shbtg'),
		lock : true,
		okValue : '提交',
		ok : function() {
			
			var checkresult = $("#checkresult").val();
			if(checkNull(checkresult)){
				alertDiag("请填写不通过原因!");
				return false;
			}
			
			submitForm("#companysoftCheckNoForm", home_url + "/homePage/companytry/checkno", null, function(data){
				_contentLoadTriggered=false;
				if(data.code==0) {
					alertDiag("已处理完成! " , refreshPage );
		        } else {
		        	alertDiag(data.content);
		        }
			},'json');
			
			return false;
		},
		cancelValue : '取消',
		cancel : function() {
		}
	});
	
	myDialog.showModal();
}


//查看专家
function specView(id){
	showDialogModal3("查看专家认证信息", home_url + "/homePage/specauth/detail/"+id, function(data){}, 450, 300);
}
















