//企业搜索
function companySearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//登录日志搜索
function userLoginLogSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//企业软件日志搜索
function corpSoftLogSearch() {
	
	var searchField = $("#searchField").val();//获取下拉页内容 
	var searchValue = $("#searchValue").val();//获取下拉页内容
	
    if(searchValue != $("#type").val()){
	
    	$("#corpsoftlog").jqGrid('setGridParam',{  
            datatype:'json', 
            postData:{'postDatas[0].searchField':searchField,'postDatas[0].searchValue':searchValue} //发送数据  
        }).trigger("reloadGrid"); //重新载入
    	
    	$("#type").val(searchValue);
	}
}

//操作列
function companyAccountEdit(id){
    
	window.open(home_url+"/admin/account/companyservicerecord?cid="+id);                 
}

//企业名称
function fullnameformatter(cellvalue, options, rowObject){
	
    var accountCompanyView = $("#accountCompanyView").val() != undefined ? true : false;
	
	var info = "";
	
	if(accountCompanyView){
		
		info = '<a href="'+home_url+'/admin/account/companyaccount/viewcompany/'+rowObject.id+'" target="_blank">'+cellvalue+'</a>';
	}else{
		
		info = cellvalue;
	}
	return info;
}

//企业认证
function corpAuthView(id){
	
	var accountCompanyEdit = $("#accountCompanyEdit").val() != undefined ? true : false;
	
    if(accountCompanyEdit){
    	
    	var myDialog = showDialogModal("审核", home_url + "/admin/home/corpauth/viewedit/"+id, function(){
    		//异步提交
    		submitForm("#editForm", home_url + "/admin/home/corpauth/edit", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("审核完成!",refreshPage);
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//企业试用
function corpSoftTryView(id){
	
	var accountCompanyEdit = $("#accountCompanyEdit").val() != undefined ? true : false;
	
    if(accountCompanyEdit){
    	
    	var myDialog = showDialogModal("审核", home_url + "/admin/home/corpsofttry/viewedit/"+id, function(){
    		//异步提交
    		submitForm("#editForm", home_url + "/admin/home/corpsofttry/edit", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("审核完成!",refreshPage);
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//企业付费
function corpSoftPaylogView(id){
	
	var accountCompanyEdit = $("#accountCompanyEdit").val() != undefined ? true : false;
	
    if(accountCompanyEdit){
    	
    	var myDialog = showDialogModal("审核", home_url + "/admin/home/corpsoftpaylog/viewedit/"+id, function(){
    		//异步提交
    		submitForm("#editForm", home_url + "/admin/home/corpsoftpaylog/edit", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("审核完成!",refreshPage);
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//初始化
function initialization(cid){
	
    var accountCompanyEdit = $("#accountCompanyEdit").val() != undefined ? true : false;
	
    if(accountCompanyEdit){
    	
    	bootbox.dialog({
    		title:"提示",
    		message: "是否进行初始化？",
    		buttons: 			
    		{
    			"button" :
    			{
    				"label" : "否",
    				"className" : "btn-sm"
    			},
    			"click" :
    			{
    				"label" : "是",
    				"className" : "btn-sm btn-primary",
    				"callback": function() {
    					
    					post(home_url+"/admin/account/companyservicerecord/initpassword?cid="+cid, null, function(data){
    						_contentLoadTriggered=false;
    						if(data.state.value==0) {
    							alertDiag(data.content);
    						} else {
    				            alertDiag(data.content);
    				        }
    					});
    				}
    			},
    		}
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//企业试用
function  viewtry(id,softId){
	
    var myDialog = showDialogModal3("企业试用", home_url + "/admin/account/companyservicerecord/corpsofttry?cid="+id+"&softId="+softId, 540, 250);
}

//服务期
function editServiceDate(id,softId){
	
    var accountCompanyEdit = $("#accountCompanyEdit").val() != undefined ? true : false;
	
    if(accountCompanyEdit){
    	
    	var myDialog = showDialogModal("服务期", home_url + "/admin/account/companyservicerecord/servicedate?cid="+id+"&softId="+softId, function(){
    		
    		var date1 = new Date($("#date").val());
    		var date2 = new Date($("#edate").val());
    		
    		if(date2.getTime() < date1.getTime()){
    			
    			alertDiag("修改到期时间不能在原本到期时间之前");
    		}else{
    		
    			//异步提交
    			submitForm("#serviceDateForm", home_url + "/admin/account/companyservicerecord/editservicedate?date="+$("#data").val(), null, function(data){
    				_contentLoadTriggered=false;
    				if(data.state.value==0) {
    					alertDiag("编辑成功!",refreshPage);
    				}else {
    			        alertDiag(data.content);
    			    }
    			},'json');
    		}
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//企业套餐
function editSpace(id,corpSoftId,softId){
	
    var accountCompanyEdit = $("#accountCompanyEdit").val() != undefined ? true : false;
	
    if(accountCompanyEdit){
    
    	var myDialog = showDialogModal("企业套餐", home_url + "/admin/account/companyservicerecord/corpsoftspace?cid="+id+"&corpSoftId="+corpSoftId+"&softId="+softId, function(){
    		
    		//异步提交
    		submitForm("#corpSoftSpaceForm", home_url + "/admin/account/companyservicerecord/editcorpsoftspace", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("编辑成功!",refreshPage);
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//新增提交客服联系记录
function submitServiceRecord(){
	
    var accountCompanyEdit = $("#accountCompanyEdit").val() != undefined ? true : false;
	
    if(accountCompanyEdit){
    
    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/account/companyservicerecord/add",
    		data: $("#companyServiceRecordForm").serialize(),
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    				alertDiag("保存成功!",refreshPage);
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("保存失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//重置客服联系记录表单
function resetServiceRecord(){
	$("#companyServiceRecordForm")[0].reset();
}

//编辑客服联系记录页
function editServiceRecord(id,telRecord){
	
	var str = "";
	if(telRecord == 1){
		str = "来电";
	}else if(telRecord == 2){
		str = "去电";
	}
	
    var accountCompanyEdit = $("#accountCompanyEdit").val() != undefined ? true : false;
	
    if(accountCompanyEdit){
    	
    	showDialogModal3(str+"详情", home_url + "/admin/account/companyservicerecord/viewedit/"+id,540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//编辑提交客服联系记录
function saveServiceRecord(isDraft){
	
	$("#isDraft").val(isDraft);
	
	$.ajax({
		type: "post",
		url: home_url + "/admin/account/companyservicerecord/edit",
		data: $("#serviceRecordForm").serialize(),
	    dataType: "json",
	    success: function(data){
		    if(data.state.value==0) {
				alertDiag("保存成功!",refreshPage);
			}else {
		        alertDiag(data.content);
		    }
		},
		error: function(){
		    alertDiag("保存失败,请稍后重试");
		},
	});
}