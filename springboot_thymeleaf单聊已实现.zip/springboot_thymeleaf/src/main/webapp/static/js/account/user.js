//用户搜索
function userSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//操作列
function actionformatter(cellvalue, options, rowObject){
    
	var fun = "";
	var title = "";
	var css = "";
	
    if(rowObject.isForbidden == false){
		
    	fun = "javascript:disable('"+cellvalue+"');"
		title = "屏蔽";
		css = "ui-icon icon-ban-circle";
	}else{
		
		fun = "javascript:enable('"+cellvalue+"');"
		title = "解锁";
		css = "ui-icon icon-key";
	}

    var info = '<a href="'+home_url+'/admin/account/userservicerecord?uid='+rowObject.id+'" class="ui-pg-div" target="_blank"><i class="ui-icon icon-ui-icon icon-edit blue"></i></a>';
	info += '<a href="'+fun+'" class="ui-pg-div" title="'+title+'"><i class="'+css+'"></i></a>';
	
	return info;                
}

//用户名称
function usernameformatter(cellvalue, options, rowObject){
	
    var accountUserView = $("#accountUserView").val() != undefined ? true : false;
 	
	var info = "";
	
	if(accountUserView){
		
		info = '<a href="'+home_url+'/admin/account/useraccount/viewuser/'+rowObject.id+'" target="_blank">'+cellvalue+'</a>';
	}else{
		
		info = cellvalue;
	}
	return info;
}

//用户禁用
function disable(id){
	
	var accountUserEdit = $("#accountUserEdit").val() != undefined ? true : false;
	
    if(accountUserEdit){
    	
    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/account/useraccount/disable/"+id,
    		data: {},
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    		    	alertDiag("用户已禁用!",function(){
    					//刷新表格
    					$("#useraccount").jqGrid().trigger("reloadGrid");
    				});
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("操作失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//用户解除禁用
function enable(id){
	
	var accountUserEdit = $("#accountUserEdit").val() != undefined ? true : false;
	
    if(accountUserEdit){
	
	    $.ajax({
		    type: "post",
		    url: home_url + "/admin/account/useraccount/enable/"+id,
		    data: {},
		    dataType: "json",
		    success: function(data){
		        if(data.state.value==0) {
		            alertDiag("用户已解除禁用!",function(){
		        	    //刷新表格
		        	    $("#useraccount").jqGrid().trigger("reloadGrid");
		            });
		        }else {
		        	alertDiag(data.content);
		        }
		    },
		    error: function(){
		        alertDiag("操作失败,请稍后重试");
		    },
        });
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//用户认证
function userCertificationView(id){
	
	var accountUserEdit = $("#accountUserEdit").val() != undefined ? true : false;
	
    if(accountUserEdit){
		
    	var myDialog = showDialogModal("审核", home_url + "/admin/home/usercertification/viewedit/"+id, function(){
    		//异步提交
    		submitForm("#editForm", home_url + "/admin/home/usercertification/edit", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("审核完成!",refreshPage);
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//初始化
function initialization(uid){
	
	var accountUserEdit = $("#accountUserEdit").val() != undefined ? true : false;
	
    if(accountUserEdit){
    	
    	bootbox.dialog({
    		title:"提示",
    		message: "是否进行初始化？",
    		buttons: 			
    		{
    			"button" :
    			{
    				"label" : "否",
    				"className" : "btn-sm"
    			},
    			"click" :
    			{
    				"label" : "是",
    				"className" : "btn-sm btn-primary",
    				"callback": function() {
    					
    					post(home_url+"/admin/account/userservicerecord/initpassword?id="+uid, null, function(data){
    						_contentLoadTriggered=false;
    						if(data.state.value==0) {
    							alertDiag(data.content);
    						} else {
    				            alertDiag(data.content);
    				        }
    					});
    				}
    			},
    		}
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//新增提交客服联系记录
function submitServiceRecord(){
	
	var accountUserEdit = $("#accountUserEdit").val() != undefined ? true : false;
	
    if(accountUserEdit){
    	
    	$.ajax({
    		type: "post",
    		url: home_url + "/admin/account/userservicerecord/add",
    		data: $("#userServiceRecordForm").serialize(),
    	    dataType: "json",
    	    success: function(data){
    		    if(data.state.value==0) {
    				alertDiag("保存成功!",refreshPage);
    			}else {
    		        alertDiag(data.content);
    		    }
    		},
    		error: function(){
    		    alertDiag("保存失败,请稍后重试");
    		},
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//重置客服联系记录表单
function resetServiceRecord(){
	$("#userServiceRecordForm")[0].reset();
}

//编辑客服联系记录页
function editServiceRecord(id,telRecord){
	
	var str = "";
	if(telRecord == 1){
		str = "来电";
	}else if(telRecord == 2){
		str = "去电";
	}
	
	var accountUserEdit = $("#accountUserEdit").val() != undefined ? true : false;
	
    if(accountUserEdit){

    	showDialogModal3(str+"详情", home_url + "/admin/account/userservicerecord/viewedit/"+id,540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//编辑提交客服联系记录
function saveServiceRecord(isDraft){
	
	$("#isDraft").val(isDraft);
	
	$.ajax({
		type: "post",
		url: home_url + "/admin/account/userservicerecord/edit",
		data: $("#serviceRecordFrom").serialize(),
	    dataType: "json",
	    success: function(data){
		    if(data.state.value==0) {
				alertDiag("保存成功!",refreshPage);
			}else {
		        alertDiag(data.content);
		    }
		},
		error: function(){
		    alertDiag("保存失败,请稍后重试");
		},
	});
}

//操作列
function orderidformatter(cellvalue, options, rowObject){
	
    var advisorOrderView = $("#advisorOrderView").val() != undefined ? true : false;
	
	var info = "";
	
	if(advisorOrderView){
		
		if(rowObject.orderType == 1){
			
			info = '<a href="'+home_url+'/admin/advisor/order/hatelorder/viewedit/'+cellvalue+'" class="ui-pg-div" target="_blank">'+cellvalue+'</a>';
		}else if(rowObject.orderType == 2){
			
			info = '<a href="'+home_url+'/admin/advisor/order/hanetorder/viewedit/'+cellvalue+'" class="ui-pg-div" target="_blank">'+cellvalue+'</a>';
		}
	}else{
		
		info = cellvalue;
	}
	return info;              
}

//刘博遗产 误删！！！
//
////换绑手机号
//function bind(uid){
//	
//	bootbox.dialog({
//		title:"修改",
//		message: "<table class=\"table table-bordered center caib-pail\"><tbody class=\"center\"><tr><td class=\"active\">新手机号</td><td><input type=\"text\" id=\"token\"></td></tr></tbody></table>",
//		buttons: 			
//		{
//			"button" :
//			{
//				"label" : "取消",
//				"className" : "btn-sm"
//			},
//			"click" :
//			{
//				"label" : "绑定",
//				"className" : "btn-sm btn-primary",
//				"callback": function() {
//					
//					var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
//					if(!myreg.test($("#token").val())){ 
//						alertDiag("请输入有效的手机号码！"); 
//					    return ; 
//					} 
//					
//					$.ajax({
//						type: "post",
//						url: home_url + "/admin/account/UserAccount/bind",
//						data: {id:uid,token:$("#token").val()},
//					    dataType: "json",
//					    success: function(data){
//					    	if(data.code == 0){
//					    		alertDiag(data.content,refreshPage);
//					    	}else{
//					    		alertDiag(data.content);
//					    	}
//						    
//						},
//						error: function(){
//						    alertDiag("绑定失败,请稍后重试");
//						},
//					});
//				}
//			},
//		}
//	});
//}