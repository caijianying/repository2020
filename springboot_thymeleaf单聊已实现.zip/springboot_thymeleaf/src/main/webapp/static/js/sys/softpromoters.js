//搜索
function softPromotersSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//新增活跃企业推广人
function addSoftPromoters(){
	
	var myDialog = showDialogModal("新增", home_url + "/admin/sys/softpromoters/viewadd/", function(){
		
		//异步提交
		submitForm("#addForm", home_url + "/admin/sys/softpromoters/add", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("新增成功!",function(){
					//刷新表格
					$("#softpromoters").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
				alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//修改活跃企业推广人
function editSoftPromoters(id){
	
    var myDialog = showDialogModal("编辑", home_url + "/admin/sys/softpromoters/viewedit/"+id, function(){
		
		//异步提交
		submitForm("#editForm", home_url + "/admin/sys/softpromoters/edit", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("编辑成功!",function(){
					//刷新表格
					$("#softpromoters").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
		        alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//删除活跃企业推广人
function delSoftPromoters(id) {
	
	delConfirmDiag(function() {
		
		$.ajax({
			
		    type: "post",
			url: home_url+"/admin/sys/softpromoters/del/"+id,
			data: {},
		    dataType: "json",
		    success: function(data){
		    	if(data.state.value==0) {
		    		alertDiag("删除成功!",function(){
						//刷新表格
						$("#softpromoters").jqGrid().trigger("reloadGrid");
					});
				} else {
		            alertDiag(data.content);
		        }
			},
			error: function(){
				alertDiag("删除失败，请稍后重试");
			},
		});
	});
}

////重置密码
//function reset(id){
//	var id = id;
//	bootbox.dialog({
//		title:"重置密码",
//		message: '<tbody> '
//			+'<tr>'
//				+'<td class="active" width="80">密码 </td>'
//				+'<td><input name="password" id="password" type="password" required placeholder="管理员密码"></td>'
//				+'<td class="active" width="80">确认密码</td>'
//				+'<td><input type="password" name="confirm_password" id="confirm_password" placeholder="确认密码"></td>'
//			+'</tr>'
//		+'</tbody>',
//		buttons:			
//		{
//			
//			"button" :
//			{
//				"label" : "取消",
//				"className" : "btn-sm"
//			},
//			
//			"click" :
//			{
//				"label" : "确认",
//				"className" : "btn-sm btn-primary",
//				"callback": function() {
//					var password = $("#password").val();//密码
//					var confirm_password = $("#confirm_password").val();//确认密码
//					if(password == ""){
//						alert("密码不能为空! ");
//						return false;
//					}
//					if(password != confirm_password){
//						alert("两次输入密码不相同 ");
//						return false;
//					}
//					
//					password = $.md5(password);
//					
//					var data = {"id" : id,
//							"password" : password
//							};
//					
//					$.post('adminAdd',data,function(data,status,xhr){
//						if(status == "success" && data.content == 1){
//							alertDiag(data.result);
//							var data=new Object();
//							jqGridRedraw(data);//刷新表格
//						}else{
//							alertDiag(data.content);
//						}
//					},"json");
//				}
//			},
//			
//			}
//		});
//	
//}
//
////删除
//function del(id){
//	var data = {id:id};
//	delConfirmDiag(function(){
//		$.post('adminCancel',data,function(data,status,xhr){
//			if(status == "success"  && data.content =="1"){
//				alertDiag("操作成功! ");
//				var data=new Object();
//				jqGridRedraw(data);//刷新表格
//			}else{
//				alertDiag("操作失败! ");
//			}
//		},"json");
//	},"删除子管理员","");
//}
//
//	//新增   详情   页面上有验证   
//function edit(id){
//	var str = "";
//	var title = "添加子管理员";
//	if(id != null && id != undefined){
//		str = "?id="+id;
//		title = "编辑子管理员";
//	}
//	showDialogModal(title,"detail"+ str, 
//			function(data){
//				var str = adminDetail.validate();//验证   写在AdminUserDetail.jsp  中
//				if(str != false){
//					
//					$.post('adminAdd',str,function(data,status,xhr){
//						if(status == "success"  && data.content =="1"){
//							$(".ui-dialog-button [i-id = cancel]").click();
//							alertDiag(data.result);
//							var data=new Object();
//							jqGridRedraw(data);//刷新表格
//						}else{
//							alertDiag(data.result);
//						}
//					},"json");
//				}
//				
//				
//				return false;
//			}, 600, 450, function(data){
//				
//			});
//}