//类型
function issysformatter(cellvalue, options, rowObject){
	
	if(cellvalue){
		
		return "系统提供";
	}else{
		return "创建";
	}
}

//操作列
function actionformatter(cellvalue, options, rowObject){
    
	var info = '<a href="javascript:viewJurisdiction(\''+ cellvalue +'\')" class="ui-pg-div" title="查看"><i class="ui-icon icon-eye-open"></i></a>';
	
	return info;                
}

//查看权限
function viewJurisdiction(id){
	showDialogModal3("查看", home_url + "/admin/sys/jurisdiction/view/"+id,540,800);
}