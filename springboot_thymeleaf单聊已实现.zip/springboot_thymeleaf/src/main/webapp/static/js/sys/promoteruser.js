//企业登录总次数
function logintotalformatter(cellvalue, options, rowObject){
	
	var info = "<a href='javascript:loginTotal(\""+rowObject.cid+"\")'>"+cellvalue+"</a>";
	return info;
}

//企业软件登录次数详情
function loginTotal(cid){
	
    var myDialog = showDialogModal3("企业软件登录次数", home_url + "/admin/sys/promoteruser/view/"+cid, 540, "auto");
}

//导出
function excel() {

	location.href = home_url+"/admin/sys/promoteruser/export?promoterName="+$("#promoterName").val()+"&promocode="+$("#promocode").val();
}