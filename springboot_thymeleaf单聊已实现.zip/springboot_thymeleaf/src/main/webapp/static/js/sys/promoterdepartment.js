//企业名称
function departmentformatter(cellvalue, options, rowObject){
	
	var info = '<a href="'+home_url+'/admin/sys/promoterdepartment/promoter/'+rowObject.id+'?departmentName='+cellvalue+'" target="_blank">'+cellvalue+'</a>';
	return info;
}

//新增推广人部门
function addPromoterDepartment(){
	
	var myDialog = showDialogModal("新增", home_url + "/admin/sys/promoterdepartment/viewadd", function(){
		
		//异步提交
		submitForm("#addForm", home_url + "/admin/sys/promoterdepartment/add", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("新增成功!",function(){
					//刷新表格
					$("#promoterDepartment").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
				alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//修改推广人部门
function editPromoterDepartment(id){
	
    var myDialog = showDialogModal("编辑", home_url + "/admin/sys/promoterdepartment/viewedit/"+id, function(){
		
		//异步提交
		submitForm("#editForm", home_url + "/admin/sys/promoterdepartment/edit", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("编辑成功!",function(){
					//刷新表格
					$("#promoterDepartment").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
		        alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//删除推广人部门
function delPromoterDepartment(id) {
	
	delConfirmDiag(function() {
		
		$.ajax({
			
		    type: "post",
			url: home_url+"/admin/sys/promoterdepartment/del/"+id,
			data: {},
		    dataType: "json",
		    success: function(data){
		    	if(data.state.value==0) {
		    		alertDiag("删除成功!",function(){
						//刷新表格
						$("#promoterDepartment").jqGrid().trigger("reloadGrid");
					});
				} else {
		            alertDiag(data.content);
		        }
			},
			error: function(){
				alertDiag("删除失败，请稍后重试");
			},
		});
	});
}