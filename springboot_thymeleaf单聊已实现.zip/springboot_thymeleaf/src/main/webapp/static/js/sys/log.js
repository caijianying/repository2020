//日志搜索
function logSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}