//推广码搜索
function promoterSearch() {
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//推广码
function promotercodeformatter(cellvalue, options, rowObject){
	
	var info = '<a href="'+home_url+'/admin/sys/promoteruser?promoterName='+rowObject.promoterName+'&promocode='+cellvalue+'" target="_blank">'+cellvalue+'</a>';
	return info;
}

//新增推广码
function addPromoter(){
	
	var myDialog = showDialogModal("新增", home_url + "/admin/sys/promoter/viewadd", function(){
		
		//异步提交
		submitForm("#addForm", home_url + "/admin/sys/promoter/add", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("新增成功!",function(){
					//刷新表格
					$("#promoter").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
				alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//修改推广码
function editPromoter(id){
	
    var myDialog = showDialogModal("编辑", home_url + "/admin/sys/promoter/viewedit/"+id, function(){
		
		//异步提交
		submitForm("#editForm", home_url + "/admin/sys/promoter/edit", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("编辑成功!",function(){
					//刷新表格
					$("#promoter").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
		        alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//删除推广码
function delPromoter(id) {
	
	delConfirmDiag(function() {
		
		$.ajax({
			
		    type: "post",
			url: home_url+"/admin/sys/promoter/del/"+id,
			data: {},
		    dataType: "json",
		    success: function(data){
		    	if(data.state.value==0) {
		    		alertDiag("删除成功!",function(){
						//刷新表格
						$("#promoter").jqGrid().trigger("reloadGrid");
					});
				} else {
		            alertDiag(data.content);
		        }
			},
			error: function(){
				alertDiag("删除失败，请稍后重试");
			},
		});
	});
}