//角色
function rolenameformatter(cellvalue, options, rowObject){
	
    return rowObject.adminSecRole.roleName;
}

//操作列
function actionformatter(cellvalue, options, rowObject){
    
	var info = '<a href="javascript:editAdmin(\''+ cellvalue +'\','+ rowObject.adminSecRole.dataScope +')" class="ui-pg-div" title="编辑"><i class="ui-icon icon-pencil"></i></a>';
	info += '<a href="javascript:editPassWord(\''+ cellvalue +'\','+ rowObject.adminSecRole.dataScope +')" class="ui-pg-div" title="修改密码"><i class="ui-icon icon-refresh"></i></a>';
	if(rowObject.adminSecRole.dataScope != 1){
		info += '<a href="javascript:delAdmin(\''+ cellvalue +'\','+ rowObject.adminSecRole.dataScope +')" class="ui-pg-div" title="删除"><i class="ui-icon icon-trash red"></i></a>';
	}
	
	return info;                
}

//新增子管理员
function addAdmin(){
	
    var sysAccountEdit = $("#sysAccountEdit").val() != undefined ? true : false;
	
    if(sysAccountEdit){
    	
    	var myDialog = showDialogModal("新增", home_url + "/admin/sys/admin/viewadd/", function(){
    		
    		//密码进行md5加密
    		if($("#passWordOne").val() != null && $("#passWordOne").val() != ""){
    			
    			var passWordOne = $("#passWordOne").val();
    			passWordOne = $.md5(passWordOne)
    			$("#password").val(passWordOne)
    			
    			var passWordTwo = $("#passWordTwo").val();
    			passWordTwo = $.md5(passWordTwo)
    			$("#confirmPassword").val(passWordTwo)
    		}
    		
    		//异步提交
    		submitForm("#addForm", home_url + "/admin/sys/admin/add", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("新增成功!",function(){
    					//刷新表格
    					$("#admin").jqGrid().trigger("reloadGrid");
    					setTimeout(function(){
    						myDialog.close().remove();
    					},1)
    				});
    			}else {
    				alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//修改子管理员
function editAdmin(id,adminDataScope){
	
    var flag = false;
	
	var adminId = $("#adminId").val();
	var dataScope = $("#dataScope").val();
	
	if(dataScope == 1){
		
		flag = true;
	}else if(dataScope == 2){
		
		if(adminId == id){
			
			flag = true;
		}else if(adminDataScope == 3){
			
			flag = true;
		}
	}else if(dataScope == 3){
		
        if(adminId == id){
			
			flag = true;
		}
	}
	
	if(flag){
		
        var myDialog = showDialogModal("编辑", home_url + "/admin/sys/admin/viewedit/"+id, function(){
    		
    		//异步提交
    		submitForm("#editForm", home_url + "/admin/sys/admin/edit", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				alertDiag("编辑成功!",function(){
    					//刷新表格
    					$("#admin").jqGrid().trigger("reloadGrid");
    					setTimeout(function(){
    						myDialog.close().remove();
    					},1)
    				});
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//修改密码
function editPassWord(id,adminDataScope){
	
	var flag = false;
	
	var adminId = $("#adminId").val();
	var dataScope = $("#dataScope").val();
	
	if(dataScope == 1){
		
		flag = true;
	}else if(dataScope == 2){
		
		if(adminId == id){
			
			flag = true;
		}else if(adminDataScope == 3){
			
			flag = true;
		}
	}else if(dataScope == 3){
		
        if(adminId == id){
			
			flag = true;
		}
	}
	
	if(flag){
		
		var myDialog = showDialogModal("修改密码", home_url + "/admin/sys/admin/password/"+id, function(){
	    	
	    	//密码进行md5加密
			if($("#passWordOne").val() != null && $("#passWordOne").val() != ""){
				
				var passWordOne = $("#passWordOne").val();
				passWordOne = $.md5(passWordOne)
				$("#password").val(passWordOne)
				
				var passWordTwo = $("#passWordTwo").val();
				passWordTwo = $.md5(passWordTwo)
				$("#confirmPassword").val(passWordTwo)
			}
			
			//异步提交
			submitForm("#passWordForm", home_url + "/admin/sys/admin/password", null, function(data){
				_contentLoadTriggered=false;
				if(data.state.value==0) {
					alertDiag("修改成功!",function(){
						//刷新表格
						$("#admin").jqGrid().trigger("reloadGrid");
						setTimeout(function(){
							myDialog.close().remove();
						},1)
					});
				}else {
					alertDiag(data.content);
			    }
			},'json');
			return false;
		}, 540, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//删除子管理员
function delAdmin(id,adminDataScope) {
	
    var sysAccountEdit = $("#sysAccountEdit").val() != undefined ? true : false;
	
    if(sysAccountEdit){
    	
    	var flag = false;
    	
    	var adminId = $("#adminId").val();
    	var dataScope = $("#dataScope").val();
    	
    	if(dataScope == 1){
    		
    		flag = true;
    	}else if(dataScope == 2){
    		
    		if(adminId == id){
    			
    			flag = true;
    		}else if(adminDataScope == 3){
    			
    			flag = true;
    		}
    	}else if(dataScope == 3){
    		
            if(adminId == id){
    			
    			flag = true;
    		}
    	}
    	
    	if(flag){
    		
            delConfirmDiag(function() {
        		
        		$.ajax({
        			
        		    type: "post",
        			url: home_url+"/admin/sys/admin/del/"+id,
        			data: {},
        		    dataType: "json",
        		    success: function(data){
        		    	if(data.state.value==0) {
        		    		alertDiag("删除成功!",function(){
        						//刷新表格
        						$("#admin").jqGrid().trigger("reloadGrid");
        					});
        				} else {
        		            alertDiag(data.content);
        		        }
        			},
        			error: function(){
        				alertDiag("删除失败，请稍后重试");
        			},
        		});
        	});
    	}else{
    		
    		alertDiag("该用户无此操作权限");
    	}
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}


////重置密码
//function reset(id){
//	var id = id;
//	bootbox.dialog({
//		title:"重置密码",
//		message: '<tbody> '
//			+'<tr>'
//				+'<td class="active" width="80">密码 </td>'
//				+'<td><input name="password" id="password" type="password" required placeholder="管理员密码"></td>'
//				+'<td class="active" width="80">确认密码</td>'
//				+'<td><input type="password" name="confirm_password" id="confirm_password" placeholder="确认密码"></td>'
//			+'</tr>'
//		+'</tbody>',
//		buttons:			
//		{
//			
//			"button" :
//			{
//				"label" : "取消",
//				"className" : "btn-sm"
//			},
//			
//			"click" :
//			{
//				"label" : "确认",
//				"className" : "btn-sm btn-primary",
//				"callback": function() {
//					var password = $("#password").val();//密码
//					var confirm_password = $("#confirm_password").val();//确认密码
//					if(password == ""){
//						alert("密码不能为空! ");
//						return false;
//					}
//					if(password != confirm_password){
//						alert("两次输入密码不相同 ");
//						return false;
//					}
//					
//					password = $.md5(password);
//					
//					var data = {"id" : id,
//							"password" : password
//							};
//					
//					$.post('adminAdd',data,function(data,status,xhr){
//						if(status == "success" && data.content == 1){
//							alertDiag(data.result);
//							var data=new Object();
//							jqGridRedraw(data);//刷新表格
//						}else{
//							alertDiag(data.content);
//						}
//					},"json");
//				}
//			},
//			
//			}
//		});
//	
//}
//
////删除
//function del(id){
//	var data = {id:id};
//	delConfirmDiag(function(){
//		$.post('adminCancel',data,function(data,status,xhr){
//			if(status == "success"  && data.content =="1"){
//				alertDiag("操作成功! ");
//				var data=new Object();
//				jqGridRedraw(data);//刷新表格
//			}else{
//				alertDiag("操作失败! ");
//			}
//		},"json");
//	},"删除子管理员","");
//}
//
//	//新增   详情   页面上有验证   
//function edit(id){
//	var str = "";
//	var title = "添加子管理员";
//	if(id != null && id != undefined){
//		str = "?id="+id;
//		title = "编辑子管理员";
//	}
//	showDialogModal(title,"detail"+ str, 
//			function(data){
//				var str = adminDetail.validate();//验证   写在AdminUserDetail.jsp  中
//				if(str != false){
//					
//					$.post('adminAdd',str,function(data,status,xhr){
//						if(status == "success"  && data.content =="1"){
//							$(".ui-dialog-button [i-id = cancel]").click();
//							alertDiag(data.result);
//							var data=new Object();
//							jqGridRedraw(data);//刷新表格
//						}else{
//							alertDiag(data.result);
//						}
//					},"json");
//				}
//				
//				
//				return false;
//			}, 600, 450, function(data){
//				
//			});
//}