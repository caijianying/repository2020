//推广企业统计
var companyList = (function() {
	return {
		init : function(){//初始化
			
			//搜索 
			$('#seek').click(function(){
				companyList.jqGridRedraw();
			});
//			
//			$("#keyword").keypress(function(e){//回车搜索
//				 if (e.which == 13) {
//					 companyList.jqGridRedraw();
//		         }
//			});
//    		
//    		//导出
//    		$("#jqGridPager").siblings(".btnblod").find(".a-excel").click(function(e){
//    			e.preventDefault();
//    			location.href = home_url + "/DLive/shield/export";
//    		});
			
    		companyList.initjqGrid();
		},
    	initjqGrid : function(){
    		//table  和   页脚的id
    		var grid_selector = "#jqGrid";
    		var pager_selector = "#jqGridPager";
    		
    		jQuery(grid_selector).jqGrid({
    			url : home_url + '/admin/sys/promotercompany/companyListData',
    			datatype : "json",
    			height : 'auto',
    			viewrecords : true,//显示总记录数 
    			autowidth: true,//自动匹配宽度 
    			rowNum : 10,//默认每页显示
    			pager : pager_selector,//表格数据关联的分页条，html元素
    			multiselect : false,//生成多选列
    			multiboxonly : false,//全选
    			rownumbers: true,//生成序号列
    			colNames:[ '企业ID','企业名称','企业登录总次数'],
    			colModel : [ 
                    {name:"cid",index:"", width:30,editable: false,sortable : false,hidden : true,key : true,
	                    formatter : function(cellvalue, options, rowObject){
		                    if(cellvalue != null && cellvalue != undefined)
			                    return cellvalue;
		                    return "";
	                    }
                    },        
					{name:"fullname",index:"", width:30,editable: false,sortable : false,
						formatter : function(cellvalue, options, rowObject){
							if(cellvalue != null && cellvalue != undefined)
								return '<a href="'+home_url+'/admin/account/companyaccount/viewcompany/'+rowObject.cid+'" target="_blank">'+cellvalue+'</a>';
							return "";
						}
					},
					{name:"loginTotal",index:"", width:30,editable: false,sortable : false,
						formatter : function(cellvalue, options, rowObject){
							if(cellvalue != null && cellvalue != undefined)
								return "<a href='javascript:loginTotal(\""+rowObject.cid+"\")'>"+cellvalue+"</a>";
							return "";
						}
					}
    			],
    			subGrid : true,//开启子表格支持  
    			//展开子表格时，将触发此选项定义的事件方法
    			subGridRowExpanded: showThirdLevelChildGrid,
//    			subGridRowColapsed : function(subgrid_id, row_id){//当点击“-”收起子表格时，将触发此选项定义的事件方法；
//    			},
    			loadComplete : function() {//重绘回调函数
    	    	}
    		});
    		
    		// 表格下方操作
    		jQuery(grid_selector).jqGrid(
    			'navGrid',
    			pager_selector,
    			{
    				add : false,
    				edit : false,
    				//editfunc : false,
    				del : false,
    				view : false,
    				search : false,
    				refresh : false,
    				refreshicon : 'icon-refresh green',
    				beforeRefresh : function(){//刷新前触发事件
    				$("#keyword").val("");//清空关键字
    			}
    		})	
    	},
    	jqGridRedraw : function(){//重绘
    		
    		var searchField = $("#searchField").val();//获取输入框内容 
    		var searchValue = $("#searchValue").val();//获取输入框内容
    		
	        $("#jqGrid").jqGrid('setGridParam',{  
	            datatype:'json', 
	            postData:{'postDatas[0].searchField':searchField,'postDatas[0].searchValue':searchValue} //发送数据  
	        }).trigger("reloadGrid"); //重新载入  
    	}
	}
})();


jQuery(document).ready(function() {
	companyList.init();//初始化
});

//扩展父行的事件处理程序接收两个参数，即网格的ID和行的主键
function showThirdLevelChildGrid(parentRowID, parentRowKey) {
	var childGridID = parentRowID + "_table";
	var childGridPagerID = parentRowID + "_pager";
	
	// 将父行主键发送到服务器，以便我们知道要显示哪个网格
	var childGridURL = home_url + '/admin/sys/promotercompany/paylogListData/' + parentRowKey ;

	// 将表和pager HTML元素添加到父网格行——我们将在这里呈现子网格
	$('#' + parentRowID).append('<table id=' + childGridID + '></table><div id=' + childGridPagerID + ' class=scroll></div>');

	$("#" + childGridID).jqGrid({
		url: childGridURL,
		mtype: "POST",
		datatype: "json",
		height : 'auto',
		rownumbers: true,//生成序号列
		colNames: ['姓名','推广码','软件名称','购买年限','付费方式'],
		colModel: [
			{name:"promoterName",index:"", width:30,editable: false,sortable : false,
				formatter : function(cellvalue, options, rowObject){
					if(cellvalue != null && cellvalue != undefined)
						return cellvalue;
					return "";
				},
				cellattr: function(rowId, tv, rawObject, cm, rdata) {
			        //合并单元格
			        return 'id=\'promoterName' + rowId + "\'";
			    }
			},
			{name:"promocode",index:"", width:30,editable: false,sortable : false,
				formatter : function(cellvalue, options, rowObject){
					if(cellvalue != null && cellvalue != undefined)
						return '<a href="'+home_url+'/admin/sys/promoteruser?promoterName='+rowObject.promoterName+'&promocode='+cellvalue+'" target="_blank">'+cellvalue+'</a>';
					return "";
				}},
			{name:"softName",index:"", width:30,editable: false,sortable : false,
				formatter : function(cellvalue, options, rowObject){
					if(cellvalue != null && cellvalue != undefined)
						return cellvalue;
					return "";
				}},
			{name:"payCount",index:"", width:30,editable: false,sortable : false,
				formatter : function(cellvalue, options, rowObject){
					if(cellvalue != null && cellvalue != undefined)
						return cellvalue;
					return "";
				}},
			{name:"payTypeName",index:"", width:30,editable: false,sortable : false,
				formatter : function(cellvalue, options, rowObject){
					if(cellvalue != null && cellvalue != undefined)
						return cellvalue;
					return "";
				}},
		],
		loadonce: true,
		autowidth : true,
		height : 'auto',
		autoheight: true,
		rowNum: 999999,
		gridComplete: function() {
			Merger("#"+childGridID, 'shieldtypeName');
		}
//		pager: "#" + childGridPagerID
	});

}

//表格合并函数
function Merger(gridName, CellName) {
    //得到显示到界面的id集合
    var mya = $(gridName).getDataIDs();
    //当前显示多少条
    var length = mya.length;
    
    for (var i = 0; i < length; i++) {
        //从上到下获取一条信息
        var before = $( gridName ).jqGrid('getRowData', mya[i]);
        //定义合并行数
        var rowSpanTaxCount = 1;
        for (j = i + 1; j <= length; j++) {
            //和上边的信息对比 如果值一样就合并行数+1 然后设置rowspan 让当前单元格隐藏
            var end = $(gridName).jqGrid('getRowData', mya[j]);
            if (before[CellName] == end[CellName] ){//}&& before.warningmarkid == end.warningmarkid) {
                rowSpanTaxCount++;
                $(gridName).setCell(mya[j], CellName, '', { display: 'none' });
            } else {
                rowSpanTaxCount = 1;
                break;
            }
            $("#" + CellName + "" + mya[i] + "").attr("rowspan", rowSpanTaxCount);
        }
    }
}

//企业软件登录次数详情
function loginTotal(cid){
	
    var myDialog = showDialogModal3("企业软件登录次数", home_url + "/admin/sys/promotercompany/view/"+cid, 540, "auto");
}

//导出
function excel() {

	location.href = home_url+"/admin/sys/promotercompany/export?fullname="+$("#searchValue").val();
}