$(function(){
	jQuery('#gtreetable').gtreetable({
		'nodesWrapper' : 'data',
		'languages' : 'zh-CN',
	  'source': function (id) {
	    return {
	      type: 'GET',
	      url: '/sys/area/listData',
	      data: { 'pid': id },        
	      dataType: 'json',
	      error: function(XMLHttpRequest) {
	        alert(XMLHttpRequest.status+': '+XMLHttpRequest.responseText);
	      }
	    }
	  }
//	  ,'templateSelector' : '#gtreetable' 
	});
});

var setting = {
    view : {
    	selectedMulti: false,
    	addHoverDom : addHoverDom,
		removeHoverDom : removeHoverDom,
	},
	edit : {
		enable : true,
		editNameSelectAll : true,
		showRenameBtn: showRenameBtn,//是否显示编辑按钮
		renameTitle: "编辑节点名称",//编辑按钮提示文字
		showRemoveBtn : showRemoveBtn,//是否显示删除按钮
		removeTitle: "删除节点"//删除按钮提示文字
	},
	async: {
        enable: true,
        autoParam: ["id"],
        url: home_url+"/admin/sys/area/getTree",
        dataFilter: filter
    },
				
	data : {
		key: {
			name: "name"
		},
		simpleData : {
		   enable : true,//设置 zTree 是否开启异步加载模式
		   idKey : "id", // id编号命名     
           pIdKey : "pId", // 父id编号命名 
		}
	},
	showLine : true,//是否显示节点间的连线
	expandSpeed : "fast", //设置 zTree节点展开、折叠时的动画速度或取消动画(三种默认定义："slow", "normal", "fast")或 表示动画时长的毫秒数值(如：1000)    
	callback : { //回调函数   
		beforeEditName: beforeEditName,//编辑节点事件
       	beforeRemove: beforeRemove//删除节点事件
    }   
};

$(document).ready(function() {
	// 初始化树节点
	$.fn.zTree.init($("#treeDemo"), setting);
});

function zTreeOnAsyncSuccess(event, treeId, treeNode, msg) {
    if(treeNode==null){
	    var zTree = $.fn.zTree.getZTreeObj("treeDemo");
		nodes = zTree.getNodes();
		for (var i=0, l=nodes.length; i<l; i++) {
		    zTree.expandNode(nodes[i], true, false, false);
		}
		asyncNodes(zTree.getNodes());
		if (!goAsync) {
		    curStatus = "";
		}
	}
};
	
function asyncNodes(nodes) {
	if (!nodes) return;
	curStatus = "async";
	var zTree = $.fn.zTree.getZTreeObj("treeDemo");
	for (var i=0, l=nodes.length; i<l; i++) {
	    if (nodes[i].isParent && nodes[i].zAsync) {
	        asyncNodes(nodes[i].children);
	    } else {
	        goAsync = true;
	        zTree.reAsyncChildNodes(nodes[i], "refresh", true);
	    }
	}
}
	
//ajax加载之后过滤
function filter(treeId, parentNode, childNodes) {
	if (!childNodes) return null;
	for (var i=0, l=childNodes.length; i<l; i++) {
	    childNodes[i].name = childNodes[i].name.replace(/\.n/g, '.');
	}
	return childNodes;
}

//显示新增节点按钮
function addHoverDom(treeId, treeNode) {
	if(treeNode.id != 0 && treeNode.sysAreaLevel != 4){
		var sObj = $("#" + treeNode.tId + "_span");
		if (treeNode.editNameFlag || $("#addBtn_" + treeNode.tId).length > 0)
			return;
		var addStr = "<span class='button add' id='addBtn_" + treeNode.tId
				+ "' title='新增下级组织' onfocus='this.blur();'></span>";
		sObj.after(addStr);
		var btn = $("#addBtn_" + treeNode.tId);
		if (btn)
			btn.bind("click", function() {
				addArea(treeNode);
			});
	}
};

//隐藏新增节点按钮
function removeHoverDom(treeId, treeNode) {
	$("#addBtn_" + treeNode.tId).unbind().remove();
};

//新增节点
function addArea(treeNode){
	
    var sysAreaEdit = $("#sysAreaEdit").val() != undefined ? true : false;
	
    if(sysAreaEdit){
    	
    	var myDialog = showDialogModal("新增", home_url + "/admin/sys/area/viewadd/"+treeNode.id, function(){
    		//异步提交
    		submitForm("#addForm", home_url + "/admin/sys/area/add", null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0) {
    				refreshNode();
    				setTimeout(function(){
    					myDialog.close().remove();
    				},1)
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 600, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//是否显示编辑按钮
function showRenameBtn (treeId, treeNode) {
	if(treeNode.id == 0 || treeNode.sysAreaLevel == 1){
		return false;
	}else{
		return true;
	}
};

//是否显示删除按钮
function showRemoveBtn (treeId, treeNode) {
	if(treeNode.id == 0 || treeNode.sysAreaLevel == 1){
		return false;
	}else{
		return true;
	}
};

//编辑节点
function beforeEditName (treeId, treeNode) {
	
    var sysAreaEdit = $("#sysAreaEdit").val() != undefined ? true : false;
	
    if(sysAreaEdit){
    	
    	var myDialog = showDialogModal("编辑", home_url + "/admin/sys/area/viewedit/"+treeNode.id, function(){
    		//异步提交
    		submitForm("#editForm", home_url + "/admin/sys/area/edit", null, function(data){
    			_contentLoadTriggered=false;
    			
    			var zTree = $.fn.zTree.getZTreeObj("treeDemo"),  
    		    type = "refresh",  
    		    silent = false,  
    		    nodes = zTree.getSelectedNodes();  
    		    /*根据 zTree 的唯一标识 tId 快速获取节点 JSON 数据对象*/  
    		    var parentNode = zTree.getNodeByTId(treeNode.parentTId);  
    		    /*选中指定节点*/  
    		    zTree.selectNode(parentNode); 
    			
    			if(data.state.value==0) {
    				refreshNode();
    				setTimeout(function(){
    					myDialog.close().remove();
    				},1)
    			}else {
    		        alertDiag(data.content);
    		    }
    		},'json');
    		return false;
    	}, 600, "auto");
	}else{
		
		alertDiag("该用户无此操作权限");
		return false;
	}
};

//删除节点
function beforeRemove (treeId, treeNode) {
	
    var sysAreaEdit = $("#sysAreaEdit").val() != undefined ? true : false;
	
    if(sysAreaEdit){
    	
    	post(home_url+"/admin/sys/area/sysarea/"+treeNode.id, null, function(data){
    		_contentLoadTriggered=false;
    	    
    		if(data.state.value==0) {
    			
    			var zTree = $.fn.zTree.getZTreeObj("treeDemo"),  
    		    type = "refresh",  
    		    silent = false,  
    		    nodes = zTree.getSelectedNodes();  
    		    /*根据 zTree 的唯一标识 tId 快速获取节点 JSON 数据对象*/  
    		    var parentNode = zTree.getNodeByTId(treeNode.parentTId);  
    		    /*选中指定节点*/  
    		    zTree.selectNode(parentNode); 
    			
    			if(data.result != undefined){
    				
    				var myDialog = showDialogModal("关键信息请谨慎删除", home_url + "/admin/sys/area/viewdel", function(){
    					
    					if($("#del").val() != "delete"){
    						alertDiag("错误,请填写delete");
    						return false;
    					}
    					
    					post(home_url+"/admin/sys/area/del/"+treeNode.id, null, function(data){
    						_contentLoadTriggered=false;
    						if(data.state.value==0) {
    							zTree.reAsyncChildNodes(parentNode, type, silent); 
    							setTimeout(function(){
    								myDialog.close().remove();
    							},1)
    						} else {
    				            alertDiag(data.content);
    				        }
    					});
    					return false;
    				}, 250, "auto");
    			}else{
    				
    				alertDiag("确定删除该行政区划？",function(){
    					
    					post(home_url+"/admin/sys/area/del/"+treeNode.id, null, function(data){
    						_contentLoadTriggered=false;
    						if(data.state.value==0) {
    							zTree.reAsyncChildNodes(parentNode, type, silent); 
    						} else {
    				            alertDiag(data.content);
    				        }
    					});
    				});
    			}
    		}else {
    			alertDiag("删除失败，请稍后重试");
    	    }
    	});
    	return false;
	}else{
		
		alertDiag("该用户无此操作权限");
		return false;
	}
};

//刷新当前节点   
function refreshNode() {  
    /*根据 treeId 获取 zTree 对象*/  
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),  
    type = "refresh",  
    silent = false,  
    /*获取 zTree 当前被选中的节点数据集合*/  
    nodes = zTree.getSelectedNodes();  
    /*强行异步加载父节点的子节点。[setting.async.enable = true 时有效]*/  
    zTree.reAsyncChildNodes(nodes[0], type, silent);  
}  

//刷新当前选择节点的父节点  
function refreshParentNode() {  
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),  
    type = "refresh",  
    silent = false,  
    nodes = zTree.getSelectedNodes();  
    /*根据 zTree 的唯一标识 tId 快速获取节点 JSON 数据对象*/  
    var parentNode = zTree.getNodeByTId(nodes[0].parentTId);  
    /*选中指定节点*/  
    zTree.selectNode(parentNode);  
    zTree.reAsyncChildNodes(parentNode, type, silent);  
}