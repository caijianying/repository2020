//企业名称
function companynameformatter(cellvalue, options, rowObject){
	
	var info = '<a href="'+home_url+'/admin/account/companyaccount/viewcompany/'+rowObject.cid+'" target="_blank">'+cellvalue+'</a>';
	return info;
}

//查看活跃企业详情
function cidformatter(cellvalue, options, rowObject){
	
	var info = '<a href="'+home_url+'/admin/sys/activecompany/view/'+cellvalue+'" target="_blank">点击查看详情</a>';
	return info;
}

//查看模块信息
function viewCompanyModule(id){
	
    var myDialog = showDialogModal3("模块操作详情", home_url + "/admin/sys/activecompany/viewmodule/"+id, 540, "auto");
}

//活跃企业统计筛选
function activeCompanySearch() {
	
	if($("input[name='filter']").is(":checked")){
		$("#filter").val("1");
	}else{
		$("#filter").val("");
	}
	
	jqGridRedraw($("#searchForm").serializeObject());
}

var softType = null;
var year = null;
var month = null;

//月统计次数
function monthNumber(i) {
	
	if(i == 1){
		
		if(softType != $("[name='postDatas[0].searchValue']").val()){
			
			$.ajax({
				
			    type: "post",
				url: home_url+"/admin/sys/activecompany/number",
				data: {softType:$("[name='postDatas[0].searchValue']").val(),year:$("[name='postDatas[1].searchValue']").val(),month:$("[name='postDatas[2].searchValue']").val()},
			    dataType: "json",
			    success: function(data){
			    	
			    	softType = $("[name='postDatas[0].searchValue']").val();
			    	
			    	$("#number").empty();
			    	
			    	if(data.result != undefined){
			    		
			    		for(var i=0;i<data.result.length;i++){
							
							var item = data.result[i];
							var html = "<option value='"+item+"'>第"+item+"周</option>";
							$("#number").append(html);
				    	}
			    	}
			    },
				error: function(){
					alertDiag("获取本月统计次数失败，请稍后重试");
				},
			});
		}
	}else if(i == 2){
		
		if(year != $("[name='postDatas[1].searchValue']").val()){
			
			$.ajax({
				
			    type: "post",
				url: home_url+"/admin/sys/activecompany/number",
				data: {softType:$("[name='postDatas[0].searchValue']").val(),year:$("[name='postDatas[1].searchValue']").val(),month:$("[name='postDatas[2].searchValue']").val()},
			    dataType: "json",
			    success: function(data){
			    	
			    	year = $("[name='postDatas[1].searchValue']").val();
			    	
			    	$("#number").empty();
			    	
			    	if(data.result != undefined){
			    		
			    		for(var i=0;i<data.result.length;i++){
							
							var item = data.result[i];
							var html = "<option value='"+item+"'>第"+item+"周</option>";
							$("#number").append(html);
				    	}
			    	}
			    },
				error: function(){
					alertDiag("获取本月统计次数失败，请稍后重试");
				},
			});
		}
	}else if(i == 3){
		
		if(month != $("[name='postDatas[2].searchValue']").val()){
			
			$.ajax({
				
			    type: "post",
				url: home_url+"/admin/sys/activecompany/number",
				data: {softType:$("[name='postDatas[0].searchValue']").val(),year:$("[name='postDatas[1].searchValue']").val(),month:$("[name='postDatas[2].searchValue']").val()},
			    dataType: "json",
			    success: function(data){
			    	
			    	month = $("[name='postDatas[2].searchValue']").val();
			    	
			    	$("#number").empty();
			    	
			    	if(data.result != undefined){
			    		
			    		for(var i=0;i<data.result.length;i++){
							
							var item = data.result[i];
							var html = "<option value='"+item+"'>第"+item+"周</option>";
							$("#number").append(html);
				    	}
			    	}
			    },
				error: function(){
					alertDiag("获取本月统计次数失败，请稍后重试");
				},
			});
		}
	}
}

//导出
function excel() {

	if($("#number").val() == null || $("#number").val() == "" || $("#number").val() == undefined){
		
		alertDiag("本月没有统计数据,无法导出");
	}else{
		
		location.href = home_url+"/admin/sys/activecompany/export?softType="+$("#softType").val()+"&year="+$("#year").val()+"&month="+$("#month").val()+"&number="+$("#number").val();
	}
}