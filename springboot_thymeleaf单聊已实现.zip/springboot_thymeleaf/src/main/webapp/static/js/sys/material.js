

var Material = (function() {
	return {
		init : function(){//初始化
			
			//搜索
			$("#submit").click(function(){
				Main.dataTableExamples["material"].api().destroy();
				Material.initDataTable();//重新加载
			});
			
			Material.initDataTable();
			
		},
		initDataTable : function(){
			Main.dataTableExamples["material"] =  $('#material').dataTable( {
				ajax : {//ajax获取数据源
					url : 'Material/getMaterialList',
					dataSrc : "data",
					type : "POST",
					data:{search:$("#search").val()}
				}, 
				autoWidth: false,
				ordering : false,//是否开启本地排序
				rowId : "gnssDataId",
				pagingType: "bootstrap_full_number",
				searching : false,//是否开启本地搜索
				serverSide : true,//指定是否从服务器端获取  数据 
				pageLength : 10,//默认每页显示数据的条目
				bDeferRender : true,//控制表格的延迟渲染，可以提高初始化的速度。
				deferRender : true,//控制表格的延迟渲染，可以提高初始化的速度。
				processing : true,//加载数据时是否显示正在加载信息 
				fixedHeader : true,
				//stateSave: true,//后退保持在当前页
				/*"columnDefs": [
			                   {
			                       orderable: false,
			 
			                       targets: 5 }
			               ],//第5列禁止排序*/
				columns : [
					{
						data : null,
						className:"center",
						title : "序号",
						targets: 0
						
					},
					{
						data : "nameCh",
						className:"center",
						name : "nameCh",
						title : "名称",
						render : function(data, type, row,meta) {
							if(data != null){
								return data; 
							}
							return ""; 
						}
					},
					{
						data : "nicknameCh",
						className:"center",
						name : "nicknameCh",
						title : "别名",
						render : function(data, type, row,meta) {
							if(data != null){
								return data; 
							}
							return ""; 
						}
					},
					{
						data : "casno",
						className:"center",
						name : "casno",
						title : "CAS编号",
						render : function(data, type, row,meta) {
							if(data != null){
							    return data;
							}
							return ""; 
						}
					},
					{
						data : "ishazardous",
						className:"center",
						name : "ishazardous",
						title : "是否危化品",
						render : function(data, type, row,meta) {
							if(data != null){
								if(data == 0){
									return "否"; 
								}else if(data == 1){
									return "是"; 
								}else{
									return ""; 
								}
							}
							return ""; 
						}
					},
					{
						data : "isetoxic",
						className:"center",
						name : "isetoxic",
						title : "是否剧毒品",
						render : function(data, type, row,meta) {
							if(data != null){
								if(data == 0){
									return "否"; 
								}else if(data == 1){
									return "是"; 
								}else{
									return ""; 
								}
							}
							return ""; 
						}
					},
					{
						data : "icscLnk",
						className:"center",
						name : "icscLnk",
						title : "ICSC连接地址",
						render : function(data, type, row,meta) {
							if(data != null && data != ""){
								return "<a href='"+data+"' target='_blank'>点击</a>";  
							}
							return ""; 
						}
					},
					{
						data : null,
						className:"center",
						name : "",
						title : "操作",
						render : function(data, type, row, meta) {
							var info = 	"<a href='javascript:editDetailView("+data.id+");' class='ui-pg-div a-copyreader' title='编辑'>"+
                    		"<i class='ui-icon icon-pencil'></i></a>";
							
							info += "<a href='javascript:delDetailView("+data.id+");' class='ui-pg-div color-red dxy-remove a-delete' title='删除'>"+
                    			"<i class='ui-icon icon-trash'></i></a>";
							
							return info;
						}
					}
				],
				language: {//中文化
			        sProcessing: "处理中...",
			        sLengthMenu: "显示 _MENU_ 项结果",
			        sZeroRecords: "没有找到匹配的数据！",
			        sInfo: '<div class="btn-group fr"><div class="add-ym padding-tb6">总共 <font color="red">_TOTAL_</font> 条记录 '+    
		                    '&nbsp;&nbsp;共 <font color="red">_PAGES_</font> 页&nbsp;&nbsp;'+
		                     ' 当前所在第 <font color="red">_PAGE_</font> 页</div>',
			        sInfoEmpty: "显示第 0 至 0 项结果，共 0 项",
			        sInfoFiltered: "",
			        sInfoPostFix: "",
			        sSearch: "搜索:",
			        sEmptyTable: "暂无数据！",
			        sLoadingRecords: "载入中...",
			        sInfoThousands: ",",
			        oPaginate: {
			            sFirst: "首页",
			            sLast: "末页",
			            sNext : "下一页",
						sPrevious : "上一页"
			        },
			        oAria: {
			            "sSortAscending": ": 以升序排列此列",
			            "sSortDescending": ": 以降序排列此列"
			        }
		    	},
		    	drawCallback : function(){
		    		
		    		//生成序号
		    		var api = this.api();
					var startIndex= api.context[0]._iDisplayStart;
					// 获取到本页开始的条数
					api.column(0).nodes().each(function(cell, i) {
					    // 此处 startIndex + i + 1;会出现翻页序号不连续，主要是因为startIndex
					    // 的原因,去掉即可。
					    cell.innerHTML = startIndex + i + 1;
					});
				}
			});
		}
	}
})();

jQuery(document).ready(function() {
	Material.init();//初始化
});

//新增弹框
function addDetailView(){
	showDialogModal("新增物料", 
		home_url + "/admin/sys/Material/addDetail", 
		function(data){
			//异步提交
			submitForm("#addMaterial", home_url + "/admin/sys/Material/addMaterial", null, function(data){
				_contentLoadTriggered=false;
				if(data.code==0) {
					alertDiag("新增成功! " , refreshPage );
		        } else {
		        	alertDiag(data.content);
		        }
			},'json');
			
			return false;
		}, 600, "auto");
}

//编辑弹框
function editDetailView(id){
	showDialogModal("编辑物料", 
		home_url + "/admin/sys/Material/editDetail/"+id, 
		function(data){
			//异步提交
			submitForm("#editMaterial", home_url + "/admin/sys/Material/editMaterial", null, function(data){
				_contentLoadTriggered=false;
				if(data.code==0) {
					alertDiag("编辑成功! " , refreshPage );
		        } else {
		        	alertDiag(data.content);
		        }
			},'json');
			
			return false;
		}, 600, "auto");
}

//删除弹框
function delDetailView(id){
	delConfirmDiag(function(){
		$.ajax({
			type: "post",
			url: home_url + "/admin/sys/Material/delMaterial/"+id,
			data: {},
		    dataType: "json",
		    success: function(data){
			    alertDiag("删除成功! ",refreshPage);
			},
			error: function(){
			    alertDiag("删除失败，请稍后重试! ");
			},
		});
	},"删除物料","");
}