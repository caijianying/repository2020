﻿//专业家

$(function(){

})

//同意试用
function checkYes(id){
	delConfirmDiag(function(){
		var url= home_url + "/homePage/companytry/checkyes/"+id;
		post(url, {},function (data) {
			_contentLoadTriggered=false;
            if(data.code==0) {
            	alertDiag("开通成功!", refreshPage);
            } 
        });
		
		
	}, "同意试用?", "是否同意该企业试用软件?");
}

function checkNo(id){
	//初始化表单内容
	$('#companysoftCheckNoForm')[0].reset()
	//
	$("#checkid").val(id);
	
	var myDialog = dialog({
		title : '审核不通过原因',
		content : $('#shbtg'),
		lock : true,
		okValue : '提交',
		ok : function() {
			
			var checkresult = $("#checkresult").val();
			if(checkNull(checkresult)){
				alertDiag("请填写不通过原因!");
				return false;
			}
			
			submitForm("#companysoftCheckNoForm", home_url + "/homePage/companytry/checkno", null, function(data){
				_contentLoadTriggered=false;
				if(data.code==0) {
					alertDiag("已处理完成! " , refreshPage );
		        } else {
		        	alertDiag(data.content);
		        }
			},'json');
			
			return false;
		},
		cancelValue : '取消',
		cancel : function() {
		}
	});
	
	myDialog.showModal();
}



















