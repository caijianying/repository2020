//添加城市选择按钮交互
$(".btn-add-cityPicker-func").click(function(){
	$(this).before($(".cityPicker-group").eq(0).clone());//.find(".city-picker-selector").addClass("city-picker-selector"+len)
	var len=$(".city-picker-selector").length;
	$(".cityPicker-group").eq(len-1).find(".city-picker-selector").addClass("city-picker-selector"+(len-1));
	
	console.log(len);
	ClassAdd();

})
function ClassAdd(){
	var len=$(".city-picker-selector").length;
	for(var i=0;i<len;i++){
		
		$(".city-picker-selector"+i).cityPicker({	
			dataJson: cityData,
			renderMode: true,
			search: true,
			autoSelected: true,
			keyboard: true
		});
	}
}


//添加提成输入框
//$(".btn-add-ticheng-func").click(function(){
//	$(this).before($(".bili-jisuan-group").eq(0).clone());
//});
$(".change").change(function(){
	console.log($(this).val());
})
