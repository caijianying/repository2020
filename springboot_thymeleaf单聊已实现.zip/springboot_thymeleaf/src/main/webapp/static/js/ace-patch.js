// JavaScript Document

var _contentLoadTriggered = false;
/**
 * 显示对话框
 * @param title		标题
 * @param url		内容URL
 * @param okcallback	确定按钮回调
 * @param width		对话框宽度(默认320)
 * @param height	对话框高度(默认120)	
 */
function showDialogModal(title, url, okcallback,width,height, initcallback){
	if(width==undefined) width=320;
	if(height==undefined) height=120;
	
	var myDialog = dialog({
		title : title,
		width : width,
		height : height,
		lock : true,
		okValue : '确定',
		ok : okcallback,
		cancelValue : '取消',
		cancel : function() {
		}
	});
	
	//获取修改设备参数页面
	getSimplePage(url, function(data){
		_contentLoadTriggered=false;
		
		myDialog.content(data);
		
		if(initcallback!=null  && isFunction(initcallback)) {
			initcallback();
		}
	});
	
	myDialog.showModal();
	
	return myDialog;
}


/**
 * 利用Html元素层的内容，显示为对话框的
 * @param title
 * @param contentDiv
 * @param okcallback
 * @param width
 * @param height
 * @param initcallback
 */
 function showDialogModalC(title, contentDiv, okcallback,width,height, initcallback){ 
	if ($(contentDiv)) {
		//验证页面元素是否存在
		if(width==undefined) width=320;
		if(height==undefined) height=120;
		
		var myDialog = dialog({
			title : title,
			width : width,
			height : height,
			content : $(contentDiv),
			lock : true,
			okValue : '确定',
			ok : okcallback,
			cancelValue : '取消',
			cancel : function() {
			}
		});
		
		if(initcallback!=null  && isFunction(initcallback)) {
			initcallback();
		}
		myDialog.showModal();
	}
	//不存在页面元素，退出对话框
}

// get 请求
function get(url, param, success) {
 	ajax(url, param, "get", success, "html");
}

// post 请求
function post(url, param, success) {
 	ajax(url, param, "post", success, 'json');
}
 
// post 请求页面
function postPage(url, param, success) {
 	ajax(url, param, "post", success, 'html');
}
 
// 异步ajax提交
function ajax(url, param, mt, success, dt) {
 	_contentLoadTriggered = true;
 	// ajax
	$.ajax({
		type : mt,
		data : param,
		dataType : dt,
		url : url,
		cache : false,
		// contentType: false,
		error : function(data, status, e) {
			_contentLoadTriggered = false;
			if (data && data.statusText == "OK" && data.status == 200) {
				var data = json_parse(data.responseText);
				success(data);
				return;
			}
			//alert("Ajax错误! e="+e);
			$.jGrowl("异常！请重新尝试或者联系管理员!", {
				header : "error"
			});
			
		},
		success : success,
		processData : false
	}); // ajax end
}

// 异步提交form
function submitForm(formId, url, beforeSubmit, success, dataType) {
	 if(dataType==undefined) dataType="html/text" ;
 	if(_contentLoadTriggered==false){
 		_contentLoadTriggered=true;
 		$(formId).ajaxSubmit({
 			// dataType:'html/text',
 			dataType : dataType,
			type : 'post',
			// content-type: 'text/html',
			url : url,
			beforeSubmit : beforeSubmit,
			success : function(data){
				_contentLoadTriggered=false;
				var isjson = data!=null && typeof(data) == "object" && Object.prototype.toString.call(data).toLowerCase() == "[object object]";
				if(isjson==false){
					try{
						data = json_parse(data);
					}catch(e){}
					
				}
				success(data);
			},
			error : function(data, status, e) {
				_contentLoadTriggered = false;
				if (data && data.statusText == "OK" && data.status == 200) {
					success(data.responseText);
					return;
				}
				
				//alert("Ajax错误! e="+e);
				$.jGrowl("异常！请重新尝试或者联系管理员!", {
					header : "error"
				});
				
			},
			uploadProgress : function(event, position, total, percentComplete) { // 请求进度
 			},
 			resetForm : false,
 			clearForm : false
 		});
 	}
}

//读取单个页面
function getSimplePage(url, $callback) {
 	if (_contentLoadTriggered == false) {
 		get(url, null, function(data) {
 			_contentLoadTriggered = false;
 			if (isFunction($callback)) {
 				$callback(data);
 			}
 		});
 	}
 }

// Post读取单个页面
function postSimplePage(url, $callback) {
 	if (_contentLoadTriggered == false) {
 		post(url, null, function(data) {
 			_contentLoadTriggered = false;
 			if (isFunction($callback)) {
 				$callback(data);
 			}
 		});
 	}
 }


// 判断是否是Function
function isFunction(fn) {
 	return !!fn && !fn.nodeName && fn.constructor != String
 			&& fn.constructor != RegExp && fn.constructor != Array
 			&& /function/i.test(fn + "");
}

// start

$(function(){
	//关闭IE升级提示
	$(".ietss").click(function(){
		$("#ie6-warning").hide(0);
	});



	$.fn.extend({'gjsearchshow':function(){/**高级搜索显示**/
		$(".jd-searchbox").hide();
		$(".jd-searchbox").next(".gj-searchbox").show(0);
		
		}
	});
	$.fn.extend({'jdsearchshow':function(){/**简单搜索显示**/
		$(".gj-searchbox").hide();
		$(".gj-searchbox").prev(".jd-searchbox").show(0);
		
		}
	});



});	



// end

//点击切换
$(".caib-pail .tg").click(function(){
	$(".tgneir").show();
	$(".btgneir").hide();
});
$(".caib-pail .btg").click(function(){
	$(".btgneir").show();
	$(".tgneir").hide();
});


$(".remove-two").click(function(){
	$(this).parent("div").hide();
});























