//链接
function linkformatter(cellvalue, options, rowObject){
	
	var info = '<a href="'+cellvalue+'" target="_blank">点击打开</a>';
	return info;
}

//新增广告位
function addFocusAd(){
	var myDialog = showDialogModal("新增", home_url + "/admin/operate/focusad/viewadd/", function(){
		//异步提交
		submitForm("#addForm", home_url + "/admin/operate/focusad/add", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("新增成功!",function(){
					//刷新表格
					$("#focusad").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
		        alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//编辑广告位
function editFocusAd(id){
	var myDialog = showDialogModal("编辑", home_url + "/admin/operate/focusad/viewedit/"+id, function(){
		//异步提交
		submitForm("#editForm", home_url + "/admin/operate/focusad/edit", null, function(data){
			_contentLoadTriggered=false;
			if(data.state.value==0) {
				alertDiag("编辑成功!",function(){
					//刷新表格
					$("#focusad").jqGrid().trigger("reloadGrid");
					setTimeout(function(){
						myDialog.close().remove();
					},1)
				});
			}else {
		        alertDiag(data.content);
		    }
		},'json');
		return false;
	}, 540, "auto");
}

//删除广告位
function delFocusAd(id) {
	
	delConfirmDiag(function() {
		
		$.ajax({
			
		    type: "post",
			url: home_url+"/admin/operate/focusad/del/"+id,
			data: {},
		    dataType: "json",
		    success: function(data){
		    	if(data.state.value==0) {
		    		alertDiag("删除成功!",function(){
						//刷新表格
						$("#focusad").jqGrid().trigger("reloadGrid");
					});
				} else {
		            alertDiag(data.content);
		        }
			},
			error: function(){
				alertDiag("删除失败，请稍后重试");
			},
		});
	});
}