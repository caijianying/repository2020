﻿//公告搜索
function noticeSearch(){
	
	jqGridRedraw($("#searchForm").serializeObject());
}

//新增公告
function addNotice(){
	
	var platformNoticeEdit = $("#platformNoticeEdit").val() != undefined ? true : false;
	
	if(platformNoticeEdit){

		window.location.href = home_url + "/admin/platformnotice/notice/viewadd/";
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//编辑公告
function editNotice(id){
	
	var platformNoticeEdit = $("#platformNoticeEdit").val() != undefined ? true : false;
	
    if(platformNoticeEdit){
    	
    	window.location.href = home_url + "/admin/platformnotice/notice/viewedit/"+id;
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}

//删除公告
function delNotice(id) {
	
	var platformNoticeEdit = $("#platformNoticeEdit").val() != undefined ? true : false;
	
    if(platformNoticeEdit){
		
    	delConfirmDiag(function() {
    		
    		$.ajax({
    			
    		    type: "post",
    			url: home_url+"/admin/platformnotice/notice/del/"+id,
    			data: {},
    		    dataType: "json",
    		    success: function(data){
    		    	if(data.state.value==0) {
    		    		alertDiag("删除成功!",function(){
    						//刷新表格
    						$("#notice").jqGrid().trigger("reloadGrid");
    					});
    				} else {
    		            alertDiag(data.content);
    		        }
    			},
    			error: function(){
    				alertDiag("删除失败，请稍后重试");
    			},
    		});
    	});
	}else{
		
		alertDiag("该用户无此操作权限");
	}
}