﻿//jqgrid加载错误之后处理
jQuery(function($){
	$.extend($.jgrid.defaults, {  
		loadError: function(xhr,status,error){  
			alertDiag(status + " loading data of " + $(this).attr("id") + " : " + error );    
	   	},
	   	width:780,
	   	responsive:true,
	   	styleUI:'Bootstrap'
	}); 

	$(document).ajaxError(function(e,xhr,opt){  
	    if(xhr.responseText.indexOf(_loginTimeout) != -1) {  
	       alertDiag("登录超时，请重新登录！", refreshPage);
	    }
	}); 
});
  


/**
 * 日期格式化
 * 
 * @param cellvalue
 * @param options
 * @param rowObject
 * @returns
 */
function dateformatter(cellvalue, options, rowObject) {
	if (cellvalue != null
			&& cellvalue != undefined){
		return new Date(cellvalue).Format("yyyy-MM-dd");
		//formatDate(new Date(cellvalue));
	}
	return "";
}
/**
 * 日期时间格式化()
 * 
 * @param cellvalue
 * @param options
 * @param rowObject
 * @returns
 */
function datetimeformatter(cellvalue, options, rowObject) {
	if (cellvalue != null
			&& cellvalue != undefined){
		return new Date(cellvalue).Format("yyyy-MM-dd h:m");
		//formatDate(new Date(cellvalue));
	}
	return "";
}

/**
 * URL链接
 * 
 * @param cellvalue
 * @param options
 * @param rowObject
 * @returns
 */
function urlformatter(cellvalue, options, rowObject) {
	if (cellvalue != null
			&& cellvalue != undefined){
		return "<a href='"+cellvalue+"' target='_Blank'>"+cellvalue+"</a>";
	}
	return "";
}

 /**
	 * 布尔型转换
	 * 
	 * @param cellvalue
	 * @param options
	 * @param rowObject
	 * @returns
	 */
function booleanformatter(cellvalue, options, rowObject) {
	if (cellvalue != null
			&& cellvalue == true){
		return '<font color="red">是</font>';
	}
	return "否";
}


var state_draft = 0, 		//草稿
	state_pending = 1,		//待处理
	state_processed = 2,	//已同意
	state_denied = 3		//已拒绝
	;	
/**
 * 邀请状态转换说明
 * @param cellvalue
 * @param options
 * @param rowObject
 * @returns {String}
 */
function stateformatter(cellvalue, options, rowObject) {
	if (cellvalue == state_draft){
		return "草稿";
	}else if(cellvalue == state_pending){
		return "待处理";
	}else if(cellvalue == state_processed){
		return "已同意";
	}else if(cellvalue == state_denied){
		return "已拒绝";
	}
	return "——";
}

//气泡
function enableTooltips(table) {
	//$('.navtable .ui-pg-button').tooltip({container:'body'});
	//$(table).find('.ui-pg-div').tooltip({container:'body'});
}

//对Date的扩展，将 Date 转化为指定格式的String
//月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
//年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
//例子：
//(new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
//(new Date()).Format("yyyy-M-d h:m:s.S")   ==> 2006-7-2 8:9:4.18
Date.prototype.Format = function (fmt) { 
var o = {
 "M+": this.getMonth() + 1, //月份
 "d+": this.getDate(), //日
 "h+": this.getHours(), //小时
 "m+": this.getMinutes(), //分
 "s+": this.getSeconds(), //秒
 "q+": Math.floor((this.getMonth() + 3) / 3), //季度
 "S": this.getMilliseconds() //毫秒
};
if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
for (var k in o)
if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
return fmt;
}
