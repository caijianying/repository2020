﻿/**
 * 使用方法
 * 1.在业务JSP页面上定义
 * 	<div class="btn-filebox fl">
		<div id="otherFile_filelist" fieldname="otherFileId" class="smarthse_uploader_filelist" max_file_count="99"></div>
		<a id="otherFile_upload" href="javascript:void(0);" class='btn btn-success smarthse_uploader_browse_button'><i class="icon-upload-alt"></i>选择文件</a>
	</div>	
	注意：
	<li>fieldname 页面表单的input名称，若是多个可取为:key[].fileid,Java中取值应该为List<Long>
 */
//通用上传JS
var uploaders = [];
//通用附件类型
//var img_mime_type = {title : "图片文件", extensions : "jpg,jpeg,gif,png,bmp"};
//var office_mime_type = {title : "Office文件", extensions : "doc,docx,xls,xlsx,ppt,pptx,pdf,txt,rtf"};
//var compress_mime_type = { title : "压缩文件", extensions : "rar,zip,7z,tar.gz" };
//var video_mime_type = {title: "视频文件", extensions: "mpg,m4v,mp4,flv,3gp,mov,avi,rmvb,mkv,wmv"};
var image_url = location.href.substring(0,location.href.lastIndexOf('/')) + '/uploads/',
	upload_url = home_url + '/ajax/file/upload',
	check_url = home_url + "/ajax/file/check/",
	flash_swf_url = '/static/plugins/plupload-2.1.2/Moxie.swf',
	silverlight_xap_url = '/static/plugins/plupload-2.1.2/Moxie.xap',
	max_file_size = "200m";	//上传附件大小

//你的浏览器不支持flash,Silverlight或者HTML5！
var initUploaders = function(uploaders) {
	//处理上传按钮
    $(".smarthse_uploader_browse_button").each(function() {
        self = $(this);
        var browse_buttons_container = $(this).parent();
        var browse_button_id = self.attr('id'),
        	//文件列表
        	oss_filelist = browse_buttons_container.siblings('.smarthse_uploader_filelist'),
        	//表单字段
        	fieldname = oss_filelist.attr("fieldname"),
        	//附件类型（根据后端类型进行匹配），默认是0
        	filedtype = oss_filelist.attr("filedtype")==undefined?0:oss_filelist.attr("filedtype"),
        	//最大文件大小
        	max_file_size = oss_filelist.attr("max_file_size")==undefined?"20m":oss_filelist.attr("max_file_size"),
        	//限制上传文件个数
        	max_file_count = oss_filelist.attr("max_file_count")==undefined?1:oss_filelist.attr("max_file_count"),
        	//附件类型
        	extensions = oss_filelist.attr("extensions")==undefined?"*":oss_filelist.attr("extensions")
        	;
            //TODO 1.1其他属性扩展 
       

        var smarthse_uploader = new plupload.Uploader({
        	url : upload_url,
        	runtimes : 'html5,flash,html4,silverlight',
        	browse_button : browse_button_id, 
        	flash_swf_url : flash_swf_url,
        	silverlight_xap_url : silverlight_xap_url,
            multi_selection: false,								//单选
            multipart_params: { 'type': '0','filehash': '' }, 	//默认参数
            filters : { 
                max_file_size : max_file_size, 
                //允许的文件类型
                mime_types: [
                    {title : "文件", extensions : extensions},
                ]
            },

            init: {
            	BeforeUpload:function(){
            		var count = $("input[name='"+fieldname+"']").length;
            		if(max_file_count != 1) {
        				if(count>=max_file_count){
            				alertDiag("超出最大文件上传个数("+max_file_count+")");
            				return false;
            			}
    				}
            	},
            	
            	PostInit: function() {
        			//清除列表
            		//$(oss_filelist).empty();
        			smarthse_uploader.start();
        			//TODO 1.1获取阿里云OSS签名
        		},
        		//添加到上传列表
        		FilesAdded: function(up, files) {
        			//console.info("1>>>>>>>FilesAdded>>>>>>>>>>>>>>>>>> ");
        			//+ ' (' + plupload.formatSize(file.size) + ')
        			//判断文件个数是否超出
        			var count = $("input[name='"+fieldname+"']").length;
        			if(max_file_count == 1){//只能上传一个文件，则覆盖原有文件
        				//加入到上传列表中
            			plupload.each(files, function(file) {
            				var html = '<div class="upload-divbox" id="' + file.id + '">' + file.name +'<b></b>'
            				+'<a href="javascript:;" class="remove-circle " rel="'+file.id+'" style="display:none;"><i class="icon-remove-circle"></i></a>'
            				+'<div class="progress"><div class="progress-bar" style="width: 0%"></div></div>'
            				+'<input name="'+fieldname+'" type="hidden" value="" class="smarthse_uploader_input_fieldname"/>'
            				+'</div>';
            				
            				$(oss_filelist).html(html);
            				//删除按钮事件
            				$(document).on('click', '.remove-circle', function () {
            	                var id = $(this).attr("rel");
            	              //移除上传队列
            	            	smarthse_uploader.removeFile(id);
            	            	//移除元素
            	                $("#"+id).remove();
            	            });
            				
            				//获取文件Hash，并将Hash放到file扩展属性中
            				try{
            					smarthse_uploader_getFileHash(file, function (hash) {
                					//console.info("1>>>>>>>FilesAdded>>>>>>>>>>>>>>>>>> file hash>", hash);
                					file.filehash = hash;
                					up.start();
                				});
            				}catch(e){
            					console.error("读取hash异常 ", e);
            					file.filehash = "";
            					up.start();
            				}
            				
            			});
        			}else {
        				if(count>=max_file_count){
//	            			console.error("超出最大文件上传个数， max_file_count=",max_file_count);
            				alertDiag("超出最大文件上传个数("+max_file_count+")");
            				return false;
            			}
            			
            			//加入到上传列表中
            			plupload.each(files, function(file) {
            				var html = '<div class="upload-divbox" id="' + file.id + '">' + file.name +'<b></b>'
            				+'<a href="javascript:;" class="remove-circle " rel="'+file.id+'" style="display:none;"><i class="icon-remove-circle"></i></a>'
            				+'<div class="progress"><div class="progress-bar" style="width: 0%"></div></div>'
            				+'<input name="'+fieldname+'" type="hidden" value="" class="smarthse_uploader_input_fieldname"/>'
            				+'</div>';
            				
            				$(oss_filelist).append(html);
            				//删除按钮事件
            				$(document).on('click', '.remove-circle', function () {
            	                var id = $(this).attr("rel");
            	              //移除上传队列
            	            	smarthse_uploader.removeFile(id);
            	            	//移除元素
            	                $("#"+id).remove();
            	            });
            				
            				//获取文件Hash，并将Hash放到file扩展属性中
            				try{
            					smarthse_uploader_getFileHash(file, function (hash) {
                					//console.info("1>>>>>>>FilesAdded>>>>>>>>>>>>>>>>>> file hash>", hash);
                					file.filehash = hash;
                					up.start();
                				});
            				}catch(e){
            					console.error("读取hash异常 ", e);
            					file.filehash = "";
            					up.start();
            				}
            				
            			});
        			}
        		},
        		//FilesRemoved
        		//BeforeUpload
        		BeforeUpload : function(up,file){
        			//点击按钮后上传前触发，此处可以做查询同名文件，检查剩余空间等操作
        			//console.info("2========BeforeUpload============");
        			//console.info(file);
        			//同步验证
        			var filehashUrl = check_url+file.filehash;
        			//是否执行上传
        			var doupload = false;
        			//console.info("同步开始验证file hash=", filehash);
        			//同步验证
        			async_post(filehashUrl, null, function(data){
        				_contentLoadTriggered = false;
        				//console.info(data);
        				if(data.state.value==0){
        					//服务端已存在,显示秒传成功
        					doupload = false;
        					$("#"+file.id+" a.remove-circle").show(20);
        					$("#"+file.id+" div.progress").hide(20);
        					$("#"+file.id+" input[name='"+fieldname+"']").val(data.result.id);
        					//TODO 1.1可扩展显示图片或者附件
        					//移除
        					up.removeFile(file);
        					//TODO 继续队列
        					
        				}else{
        					//服务端不存在，需要上传
        					doupload = true;
        					
        					up.settings.multipart_params.type = filedtype;
        					up.settings.multipart_params.filehash = file.filehash;
        				}
        			});
        			return doupload;
        		},
        		//上传进度条
        		UploadProgress: function(up, file) {
        			var d = document.getElementById(file.id);
        			d.getElementsByTagName('b')[0].innerHTML = '<span>' + file.percent + "%</span>";
                    
                    var prog = d.getElementsByTagName('div')[0];
        			var progBar = prog.getElementsByTagName('div')[0]
        			progBar.style.width= 2*file.percent+'px';
        			progBar.setAttribute('aria-valuenow', file.percent);
        		},
        		//上传成功后返回
        		FileUploaded: function(up, file, info) {
        			console.info("3---------FileUploaded-------------");
                    var rs = $.parseJSON(info.response);
                    if (info.status == 200 && rs.state.value == 0)
                    {
                    	$("#"+file.id+" a.remove-circle").show(20);
    					$("#"+file.id+" div.progress").hide(20);
    					$("#"+file.id+" b").remove();
    					
    					$("#"+file.id+" input[name='"+fieldname+"']").val(rs.result.id);
                    }
                    else
                    {
                    	//上传失败后，提示
                    	$("#"+file.id+" a.remove-circle").show(20);
    					$("#"+file.id+" div.progress").hide(20);
    					$("#"+file.id+" b").html(rs.content);
                    } 
        		},
        		//错误
        		Error: function(up, err) {
        			//{code: -600, message: "File size error.", file: n}
                    //set_upload_param(up);
//        			console.info(err);
//        			console.info(plupload.GENERIC_ERROR);
//        			console.info(plupload.HTTP_ERROR);
//        			console.info(plupload.IO_ERROR);
//        			console.info(plupload.SECURITY_ERROR);
//        			console.info(plupload.FILE_SIZE_ERROR);
//        			console.info(plupload.FILE_EXTENSION_ERROR);
//        			console.info(plupload.FILE_DUPLICATE_ERROR);
//        			console.info(plupload.IMAGE_FORMAT_ERROR);
//        			console.info(plupload.MEMORY_ERROR);
//        			console.info(plupload.IMAGE_DIMENSIONS_ERROR);
        			alertDiag(err.message);
        			
        		}
            }
        });

        smarthse_uploader.init();
        uploaders.push(smarthse_uploader);
        
        //给已有的文件增加删除事件
//		$(document).on('click', '.remove-circle', function () {
//            var id = $(this).attr("rel");
//          //移除上传队列
//        	smarthse_uploader.removeFile(id);
//        	//移除元素
//            $("#"+id).remove();
//        });
    });
};

//初始化上传组件
initUploaders(uploaders);

/**
 * 单例上传方法类
 * @param browse_button_id	上传按钮ID
 * @param okcallback		上传成功回调函数
 * @param uploadtype		上传类型,与服务端UploadFilePathEnum对应关系,默认0
 * @param extensions		附件文件扩展名,默认所有,示例:"jpg,jpeg,gif,png,bmp"
 * @returns {plupload.Uploader}
 */
function simple_upload(browse_button_id, okcallback, uploadtype, extensions){
	//附件类型(默认所有)
	extensions = (extensions==undefined)?"*":extensions;
	uploadtype = (uploadtype==undefined)?"0":uploadtype;
	
	var simple_smarthse_uploader = new plupload.Uploader({
    	url : upload_url,
    	runtimes : 'html5,flash,html4,silverlight',
    	browse_button : browse_button_id, 
    	flash_swf_url : flash_swf_url,
    	silverlight_xap_url : silverlight_xap_url,
        multi_selection: false,								//单选
        multipart_params: { 'type': uploadtype,'filehash': '' }, 	//默认参数
        filters : { 
            max_file_size : max_file_size, 
            //允许的文件类型
            mime_types: [
                {title : "文件", extensions : extensions},
            ]
        },

        init: {
        	PostInit: function() {
        		simple_smarthse_uploader.start();
    			//TODO 1.1获取阿里云OSS签名
    		},
    		//添加到上传列表
    		FilesAdded: function(up, files) {
    			//加入到上传列表中
    			plupload.each(files, function(file) {
    				//获取文件Hash，并将Hash放到file扩展属性中
    				try{
    					smarthse_uploader_getFileHash(file, function (hash) {
        					//console.info("1>>>>>>>FilesAdded>>>>>>>>>>>>>>>>>> file hash>", hash);
        					file.filehash = hash;
        					up.start();
        				});
    				}catch(e){
    					console.error("读取hash异常 ", e);
    					file.filehash = "";
    					up.start();
    				}
    				
    			});
    		},
    		//FilesRemoved
    		//BeforeUpload
    		BeforeUpload : function(up,file){
    			//点击按钮后上传前触发，此处可以做查询同名文件，检查剩余空间等操作
    			//console.info("2========BeforeUpload============");
    			//console.info(file);
    			//同步验证
    			var filehashUrl = check_url+file.filehash;
    			//是否执行上传
    			var doupload = false;
    			//console.info("同步开始验证file hash=", filehash);
    			//同步验证
    			async_post(filehashUrl, null, function(data){
    				_contentLoadTriggered = false;
    				//console.info(data);
    				if(data.state.value==0){
    					//服务端已存在,显示秒传成功
    					doupload = false;
    					okcallback(data.result);
    					//移除
    					up.removeFile(file);
    					//TODO 继续队列
    				}else{
    					//服务端不存在，需要上传
    					doupload = true;
    					
    					up.settings.multipart_params.type = uploadtype;
    					up.settings.multipart_params.filehash = file.filehash;
    				}
    			});
    			return doupload;
    		},
    		//上传成功后返回
    		FileUploaded: function(up, file, info) {
                var rs = $.parseJSON(info.response);
                if (info.status == 200 && rs.state.value == 0)
                {
                	okcallback(rs.result);
                }
    		},
    		//错误
    		Error: function(up, err) {
    			alertDiag(err.message);
    		}
        }
	});
	
	simple_smarthse_uploader.init();
	
	return simple_smarthse_uploader;
}




/**
 * 获取文件Hash编码
 * @param file		PluploadFile文件属性
 * @param done		回调函数
 */
function smarthse_uploader_getFileHash(pluploadFile, done) {
	var blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice,
	    file = pluploadFile.getNative(),		//选中的文件
	    chunkSize = 2097152,                           // read in chunks of 2MB
	    chunks = Math.ceil(file.size / chunkSize),
	    currentChunk = 0,
	    spark = new SparkMD5.ArrayBuffer(),
	    fileReader = new FileReader();
	
	fileReader.onload = function (e) {
	    spark.append(e.target.result);                 // append array buffer
	    currentChunk += 1;
	
	    if (currentChunk < chunks) {
	        loadNext();
	    } else {
	        running = false;
	        //返回Hash
	        done(spark.end());
	    }
	};
	
	fileReader.onerror = function (e) {
	    running = false;
	    console.error("fileReader.onerror ", e );
	};
	
	function loadNext() {
	    var start = currentChunk * chunkSize,
	        end = start + chunkSize >= file.size ? file.size : start + chunkSize;
	
	    fileReader.readAsArrayBuffer(blobSlice.call(file, start, end));
	}
	
	running = true;
	loadNext();
};

//解决IE不支持html5 file api中readAsBinaryString
if (!FileReader.prototype.readAsBinaryString) {
	FileReader.prototype.readAsBinaryString = function (fileData) {
	    var binary = "";
	    var pt = this;
	    var reader = new FileReader();      
	    reader.onload = function (e) {
	        var bytes = new Uint8Array(reader.result);
	        var length = bytes.byteLength;
	        for (var i = 0; i < length; i++) {
	            binary += String.fromCharCode(bytes[i]);
	        }
		     //pt.result  - readonly so assign binary
		     pt.content = binary;
		     $(pt).trigger('onload');
	    }
	}
}

//节省加载资源
plupload.addI18n({"Stop Upload":"停止上传","Upload URL might be wrong or doesn't exist.":"上传的URL可能是错误的或不存在。","tb":"tb","Size":"大小","Close":"关闭","Init error.":"初始化错误。","Add files to the upload queue and click the start button.":"将文件添加到上传队列，然后点击”开始上传“按钮。","Filename":"文件名","Image format either wrong or not supported.":"图片格式错误或者不支持。","Status":"状态","HTTP Error.":"HTTP 错误。","Start Upload":"开始上传","mb":"mb","kb":"kb","Duplicate file error.":"重复文件错误。","File size error.":"超出限定的文件大小。","N/A":"N/A","gb":"gb","Error: Invalid file extension:":"错误：无效的文件扩展名:","Select files":"选择文件","%s already present in the queue.":"%s 已经在当前队列里。","File: %s":"文件: %s","b":"b","Uploaded %d/%d files":"已上传 %d/%d 个文件","Upload element accepts only %d file(s) at a time. Extra files were stripped.":"每次只接受同时上传 %d 个文件，多余的文件将会被删除。","%d files queued":"%d 个文件加入到队列","File: %s, size: %d, max file size: %d":"文件: %s, 大小: %d, 最大文件大小: %d","Drag files here.":"把文件拖到这里。","Runtime ran out of available memory.":"运行时已消耗所有可用内存。","File count error.":"文件数量错误。","File extension error.":"文件扩展名错误。","Error: File too large:":"错误: 文件太大:","Add Files":"增加文件"});
