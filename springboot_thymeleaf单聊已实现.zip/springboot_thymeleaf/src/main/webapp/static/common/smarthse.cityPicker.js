﻿/**
 * 使用方法
 */
//行政区域数据包定义
var smarthse_cityData = [];
(function ($, window) {
	var $selector;		//行政区域父元素
    var grade = ['province', 'city', 'district', 'street'];		//行政区域级别
    var defaults = {
       // dataJson: null,
        selectpattern: [{
                field: 'userProvinceId',
                placeholder: '请选择省份',
                value : ''
            },
            {
                field: 'userCityId',
                placeholder: '请选择城市',
                value : ''
            },
            {
                field: 'userDistrictId',
                placeholder: '请选择区县',
                value : ''
            },
            {
                field: 'userStreetId',
                placeholder: '请选择乡村街道',
                value : ''
            }
        ],
        remoteUrl : null,
        shorthand: false,
        storage: true,
        autoSelected: true,
        renderMode: true,
        keyboard: false,
        code: false,
        search: true,
        level: 4,
        onInitialized: function () {},
        onClickBefore: function () {},
        onForbid: function () {},
        onSelected: function () {}
    };
    
  //功能模块函数
    var effect = {
        montage: function (data, pid, reg) {
            var self = this,
                config = self.options,
                leng = data.length,
                html = '',
                code, name, storage;
            
            if (config.renderMode) {
                //模拟
                html = '<li class="caller" data-id="-1" data-title="请选择" >请选择</li>';
            } else {
                //原生
                html += '<option class="caller" value="-1" data-id="-1" data-title="请选择" >请选择</option>';
            }
            
            for (var i = 0; i < leng; i++) {
                if (data[i].parentId == pid) {
                    //判断是否要输出区号
                    code = config.code && data[i].cityCode !== '' ? 'data-code=' + data[i].cityCode : '';
                    //判断是否开启了简写，是就用输出简写，否则就输出全称
                    name = config.shorthand ? data[i].shortName : data[i].name;
                    //存储的是数字还是中文
                    storage = config.storage ? data[i].id : name;
                    if (config.renderMode) {
                        //模拟
                        html += '<li class="caller" data-id="' + data[i].id + '" data-title="' + name + '" ' + code + '>' + name + '</li>';
                    } else {
                        //原生
                        html += '<option class="caller" value="' + storage + '" data-id="' + data[i].id + '" data-title="' + name + '" ' + code + '>' + name + '</option>';
                    }
                }
            }

            html = data.length > 0 && html ? html : '<li class="forbid">无下级行政区域</li>';
            return html;
        },
        seTemplet: function () {
            var config = this.options,
                selectemplet = '',
                placeholder, field, forbid, citygrade, active, hide,
                searchStr = config.search ? '<div class="selector-search">'
                    +'<input type="text" class="input-search" value="" placeholder="拼音、中文搜索" />'
                +'</div>' : '';

            for (var i = 0; i < config.level; i++) { //循环定义的级别
                placeholder = config.selectpattern[i].placeholder; //默认提示语
                field = config.selectpattern[i].field; //字段名称
                citygrade = grade[i]; //城市级别名称
                forbid = i > 0 ? 'forbid' : ''; //添加鼠标不可点击状态
                active = i < 1 ? 'active' : ''; //添加选中状态
                hide = i > 0 ? ' hide' : ''; //添加隐藏状态

                if (config.renderMode) {
                    //模拟
                    selectemplet += '<div class="selector-item storey ' + citygrade + '" data-index="' + i + '">'
                        +'<a href="javascript:;" class="selector-name reveal df-color ' + forbid + '">' + placeholder + '</a>'
                        +'<input type=hidden name="' + field + '" class="input-price val-error" value="" data-required="' + field + '">'
                        +'<div class="selector-list listing hide">'+ searchStr +'<ul></ul></div>'
                    +'</div>';
                } else {
                    //原生
                    selectemplet += '<select name="' + field + '" data-index="' + i + '" class="' + citygrade + '">'
                        +'<option>' + placeholder + '</option>'
                    +'</select>';
                }
            }

            return selectemplet;
        },
        obtain: function (event) {
            var self = this,
                config = self.options,
                $selector = self.$selector,
                $target = config.renderMode ? event[0].target ? $(event[0].target) : $(event) : $(event.target),
                $parent = $target.parents('.listing'),
                $selected = $target.find('.caller:selected'),
                index = config.renderMode ? $target.parents('.storey').data('index') : $target.data('index'),
                id = config.renderMode ? $target.attr('data-id') : $selected.attr('data-id'),
                name = config.renderMode ? $target.text() : $selected.text(),
                storage = config.storage ? id : name, //存储的是数字还是中文
                code = config.renderMode ? $target.data('code') : $selected.data('code'),
                parentValueId = config.selectpattern[index].value;		//父级默认Id
                defualtvalueId = index+1 < config.level ? config.selectpattern[index+1].value : '0',
                placeholder = index+1 < config.level ? config.selectpattern[index+1].placeholder : '',
               //赋予下拉框数据 
                placeStr = !config.renderMode ? 
                		'<option class="caller">'+placeholder+'</option>'+ effect.montage.apply(self, [smarthse_cityData, id]) 
                		: '<li class="caller hide">'+placeholder+'</li>'+ effect.montage.apply(self, [smarthse_cityData, id]),
                autoSelectedStr = !config.autoSelected ? placeStr : effect.montage.apply(self, [smarthse_cityData, id]),
                
               	$storey = $selector.find('.storey').eq(index + 1),
                $listing = $selector.find('.listing').eq(index + 1),
                values = { 'id': id || '0', 'name': name };
            
//            console.info("id="+id+",name="+name+",index="+index);
            // 存储选择的值
            if (index === 0) {
                self.province = '';
                self.province = values;
                effect.clear(self, index , id);			//当前级别+1,清除市信息
                effect.clear(self, index+1 , id);		//当前级别+2,清除区县信息
                effect.clear(self, index+2 , id);		//当前级别+3,清除街道信息
            } else if (index === 1) {
                self.city = '';
                self.city = values;
                effect.clear(self, index , id);			//当前级别+1,清除区县信息
                effect.clear(self, index+1 , id);		//当前级别+2,清除街道信息
            } else if (index === 2) {
                self.district = '';
                self.district = values;
                effect.clear(self, index , id);			//当前级别+1,清除街道信息
            } else if (index === 3) {
            	self.street = '';
                self.street = values;
            }
            
          //移除行政区域隐藏样式
            $storey.removeClass('hide');
            
          //选择选项后触发自定义事件choose(选择)事件
            $selector.trigger('choose-' + grade[index] +'.citypicker', [$target, values]);

            //赋值给隐藏域-区号
            $selector.find('[role="code"]').val(code);
            
          //给选中的级-添加值和文字
            $parent.siblings('.reveal').removeClass('df-color forbid').text(name).siblings('.input-price').val(storage);
            
          //模拟: 添加选中的样式
            $parent.find('.caller').removeClass('active');
            $target.addClass('active');
          
          //回调通知外部
//            config.onSelected.call(grade[index], values);
            
            //同步完成
            //html模板
            setTimeout(function(){effect.getdata(config, id, function(dataLeng){
            	//
//            	console.info("valueId="+valueId+",id="+id+",name="+name+",index="+index+",dataLeng="+dataLeng);
            	//
            	var placeStr = !config.renderMode ? 
                		'<option class="caller">'+placeholder+'</option>'+ effect.montage.apply(self, [smarthse_cityData, id]) 
                		: '<li class="caller hide">'+placeholder+'</li>'+ effect.montage.apply(self, [smarthse_cityData, id]),
                autoSelectedStr = !config.autoSelected ? placeStr : effect.montage.apply(self, [smarthse_cityData, id]);
                
                //TODO 若无子级节点,将选择框改换为input输入框
                if(dataLeng==0){
                	effect.clear(self, index , id);
                }	else {
                	if (config.renderMode) {
                        config.search ? $parent.find('.input-search').blur() : '';

                        //给选中的级-添加值和文字
                        $parent.siblings('.reveal').removeClass('df-color forbid').text(name).siblings('.input-price').val(storage);
                        //
                        console.info("parentValueId="+parentValueId+",defualtvalueId="+defualtvalueId+",id="+id);
                        //TODO 默认加载哪一项数据,并与之对应,,,data-id="130000000000"
                        //defualtvalueId>0
                        if(parentValueId==id && defualtvalueId>0){
                        	//带值则默认选择第1项(0表示请选择项)
                        	$listing.data('id', id).find('ul').html(autoSelectedStr).find('.caller[data-id="'+defualtvalueId+'"]').eq(0).trigger('click');
                        }else{
                        	$listing.data('id', id).find('ul').html(autoSelectedStr).find('.caller').eq(0).trigger('click');
                        }
                        
                        $storey.removeClass('hide');
                        
                        if (!config.autoSelected) {
                            $storey.find('.reveal').text(placeholder).addClass('df-color').siblings('.input-price').val('');
                            $listing.find('.caller').eq(0).remove();
                        }

                    } else {
                        //原生: 下一级附上对应的城市选项，执行点击事件
        				$target.next().html(autoSelectedStr).trigger('change').find('.caller').eq(0).prop('selected', true);
                    }
                }	
                	
        		
                
            });}, 10);
        },
        show: function (event) {
            var config = this.options,
                $target = $(event);
            $selector = this.$selector;

            $selector.find('.listing').addClass('hide');
            $target.siblings('.listing').removeClass('hide').find('.input-search').focus();

            //点击的回调函数
            config.onClickBefore.call($target);
        },
        hide: function (event) {
            var config = this.options,
                $target = $(event);

            effect.obtain.call(this, $target);

            $selector.find('.listing').addClass('hide');

            return false;
        },
        clear : function(self, index, id){
        	//console.info("clear>>>>index="+index);
        	//初始化某层级项
        	var config = self.options,
        		$selector = self.$selector,
                $storey = $selector.find('.storey').eq(index + 1),
                $listing = $selector.find('.listing').eq(index + 1);
        	
            if(index+1 < config.level){
            	if(index==2)$storey.addClass('hide');
            	$storey.find('.reveal').addClass('df-color forbid').text("").siblings('.input-price').val("");
            	
            	//$listing.addClass('hide');
            	$listing.find('.caller').removeClass('active');
            	$listing.data('id', id).find('ul').html("")
            	//清除文字与ID
            	$storey.find('.reveal').addClass('df-color forbid').text("请选择").siblings('.input-price').val("");
            }
            
        },
        search: function (event) {
            event.preventDefault();
            var self = this,
                $target = $(event.target),
                $parent = $target.parents('.listing'),
                inputVal = $target.val(),
                id = $parent.data('id'),
                keycode = event.keyCode,
                result = [];

            //如果是按下shift/ctr/左右/command键不做事情
            if (keycode === 16 || keycode === 17 || keycode === 18 || keycode === 37 || keycode === 39 || keycode === 91 || keycode === 93) {
                return false;
            }

            //如果不是按下enter/上下键的就做搜索事情
//            console.info("id="+id);
            if (keycode !== 13 && keycode !== 38 && keycode !== 40) {
                $.each(smarthse_cityData, function(key, value) {
                	//TODO 可优先查询项进行排序
                	var seachResult1 = value.pinyin.toLocaleLowerCase().search(inputVal) > -1 ;
                	var seachResult2 = value.shortpinyin.toLocaleLowerCase().search(inputVal) > -1  ;
                	var seachResult3 = value.name.search(inputVal) > -1  ;
                	var seachResult4 = value.id.search(inputVal) > -1 ;
                	
//                	console.info("ciyt.value="+value+", seachResult1="+seachResult1+",seachResult2="+seachResult2+",seachResult4="+seachResult3+",seachResult2="+seachResult4)
                    //简拼，全拼，名称，ID搜索
                    if(seachResult1 ||  seachResult2|| seachResult3 || seachResult4){
//                    	console.info("ciyt.value.name="+value.name+"");
                        result.push(value);
                    }
                });

                $parent.find('ul').html(effect.montage.apply(self, [result, id]));
            }
        },
        operation: function (event) {
            event.preventDefault();
            var $target = $(event.target),
                $sibl = $target.hasClass('input-search') ? $target.parents('.listing') : $target.siblings('.listing'),
                $items = $sibl.find('.caller'),
                keyCode = event.keyCode,
                index = 0,
                direction,
                itemIndex;
            
            //按下enter键
            if (keyCode === 13) {
                effect.hide.call(this, $sibl.find('.caller.active'));
                return false;
            }
            
            //按下上下键
            if (keyCode === 38 || keyCode === 40) {

                //方向
                direction = keyCode === 38 ? -1 : 1;
                //选中的索引
                itemIndex = $items.index($sibl.find('.caller.active'));

                if (itemIndex < 0) {
                    index = direction > 0 ? -1 : 0;
                } else {
                    index = itemIndex;
                }

                //键盘去选择的索引
                index = index + direction;

                //循环选择
                index = index === $items.length ? 0 : index;

                $items.removeClass('active').eq(index).addClass('active');

                //滚动条跟随定位
                effect.position.call(this, $sibl);
            }

            return false;
        },
        position: function (event) {
            var $target = event,
                $caller = $target.find('.caller.active'),
                oh = $target.outerHeight(),
                ch = $caller.outerHeight(),
                dy = $caller.position().top,
                sy = $target.find('ul').scrollTop();

            $target.find('ul').animate({
                scrollTop: dy + ch - oh + sy
            }, 200);
        },
        getdata : function(config, pid, callback){
        	//console.info('从服务端获取数据,并保存到smarthse_cityData中, pid='+pid);
        	var leng = smarthse_cityData.length;
        	var localCount = effect.getlocaldatacount(pid);
        	if(localCount>0 || pid==-1){
        		//从本地加载数据
        		//console.info('从本地加载数据, pid='+pid);
        		callback(localCount);
        	}else{
        		//从服务端加载数据
        		console.info('从服务端加载数据, pid='+pid);
        		effect.getRemotedata(config, pid, callback);
        	}
        },
        getlocaldatacount : function(pid){
        	//判断本地数据是否已下载,无数据跳过
        	var leng = smarthse_cityData.length,
	            count = 0;
        	for (var i = 0; i < leng; i++) {
                if (smarthse_cityData[i].parentId == pid) {
                	count++;
                }
            }
        	return count;
        },
        getRemotedata: function(config, pid, callback){
        	//从远端获取数据
        	post(config.remoteUrl+pid, null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0 && data.result != undefined) {
    				//有数据返回
			    	for(var i=0;i<data.result.length;i++){
						var item = data.result[i];
						var citydata_obj = {};
						citydata_obj.id=item.id;
						citydata_obj.name=item.name;
						citydata_obj.parentId=item.parentId;
						citydata_obj.shortName=item.shortName;
						citydata_obj.letter=item.py;
						citydata_obj.cityCode=item.id;
						citydata_obj.shortpinyin=item.py;
						citydata_obj.pinyin=item.pyFull;
						citydata_obj.level=item.level;
//						console.info(citydata_obj);
						smarthse_cityData.push(citydata_obj);
					}
    			}
    			//返回数据结果
    			callback(data.result == undefined ? 0 : data.result.length);
        	});
        }
    };
    
    function smarthse_CityPicker(options, selector) {
        this.options = $.extend({}, defaults, options);
        this.$selector = $selector = $(selector);
        this.values = [];
        this.province = this.city = this.district = '';

        this.init();
        this.bindEvent();
    }
    
    smarthse_CityPicker.prototype = {
            init: function () {
                var self = this,
                    config = self.options,
                    valueId = config.selectpattern[0].value,
                    code = config.code ? '<input type="hidden" role="code" name="' + config.code + '" value="">' : '';
                    //是否开启存储区号，是就加入一个隐藏域
//                console.info("初始化省列表");
                //添加拼接好的模板
                $selector.html(effect.seTemplet.call(self) + code);

                //html模板
                setTimeout(function(){effect.getdata(config, 0, function(){
                	//省初始化完成
                	 //html模板
                    if (config.renderMode) {
                        //模拟>添加数据
                    	$selector.find('.listing').data('id', '0').eq(0).find('ul').html(effect.montage.apply(self, [smarthse_cityData, '0']));
                    	//TODO 默认加载哪一项数据,并与之对应,,,data-id="130000000000"
                        if(valueId>0){
                        	$selector.find('.listing').data('id', '0').eq(0).find('ul').find('.caller[data-id="'+valueId+'"]').eq(0).trigger('click');
                        }else{
                        	$selector.find('.listing').data('id', '0').eq(0).find('ul').find('.caller').eq(0).trigger('click');
                        }
                        
                    } else {
                        //原生>添加数据
                        $selector.find('.province').append(effect.montage.apply(self, [smarthse_cityData, '0']));
                    }

                    //初始化后的回调函数
                    config.onInitialized.call(self);
                });}, 10);
            },
            bindEvent: function () {
                var self = this,
                    config = self.options;

                //点击显示对应的列表
                $selector.on('click.citypicker', '.reveal', function (event) {
                    event.preventDefault();
                    var $this = $(this);

                    if ($this.is('.forbid')) {
                        config.onForbid.call($this);
                        return false;
                    }

                    effect.show.call(self, $this);
                    return false;
                });

                //点击选项事件
                $selector.on('click.citypicker', '.caller', $.proxy(effect.hide, self));

                //原生选择事件
                $selector.on('change.citypicker', 'select', $.proxy(effect.obtain, self));

                //文本框搜索事件
                $selector.on('keyup.citypicker', '.input-search', $.proxy(effect.search, self));

                //开启键盘操作
                if (config.keyboard) {
                    //键盘选择事件
                    $selector.on('keyup.citypicker', '.storey', $.proxy(effect.operation, self));
                }
            },
            unBindEvent: function (event) {
                var self = this,
                    config = self.options;

                if (!config.renderMode) {
                    $selector.off('change.citypicker', 'select');
                    return false;
                }

                $selector.off('click.citypicker', '.reveal');

                $selector.off('click.citypicker', '.caller');

                $selector.off('keyup.citypicker', '.input-search');

                $selector.off('keyup.citypicker', '.storey');

            },
            setCityVal: function (val) {
                var self = this,
                    config = self.options,
                    arrayVal = val;

                self.values = [];

                $.each(arrayVal, function (key, value) {
                    var $original = $selector.find('.'+grade[key]);
                    var $forward = $selector.find('.'+grade[key+1]);

                    if (config.renderMode) {
                        $original.find('.reveal').text(value.name).removeClass('df-color forbid').siblings('.input-price').val(value.id);

                        $forward.find('ul').html(effect.montage.apply(self, [smarthse_cityData, value.id]));
                        $original.find('.caller[data-id="'+value.id+'"]').addClass('active');
                    } else {
                        $forward.html(effect.montage.apply(self, [smarthse_cityData, value.id]));
                        $original.find('.caller[data-id="'+value.id+'"]').prop('selected', true);
                    }

                    // 存储选择的值
                    self.values.push({ 'id': value.id, 'name': value.name });
                    
                });
            },
            getCityVal: function () {
                var self = this,
                    $selector = self.$selector,
                    id = $selector;

                if (self.province) {
                    self.values = [];
                    self.values.push(self.province, self.city, self.district, self.street);
                }
                
                return self.values;
            },
            changeStatus: function (status) {
                var self = this,
                    config = self.options;

                if (status === 'readonly') {
                    self.$selector.find('.reveal').addClass('forbid').siblings('.input-price').prop('readonly', true);
                } else if (status === 'disabled') {
                    self.$selector.find('.reveal').addClass('disabled').siblings('.input-price').prop('disabled', true);

                    !config.renderMode ? self.$selector.find('select').prop('disabled', true) : '';
                }

                config.renderMode && status !== 'readonly' ? self.unBindEvent() : '';
            }
        };

        //模拟：执行点击区域外的就隐藏列表;
    	$(document).on('click.citypicker', function (event){
    		if($selector && $selector.find(event.target).length < 1) {
    			$selector.find('.listing').addClass('hide');
    		}
        });

        $.fn.smarthse_CityPicker = function (options) {
            return new smarthse_CityPicker(options, this);
        };
    
    
	
})(jQuery, window);

/**
 * 弹框单选行政区域
 * @param callback			成功后回调
 * @param dfprovinceId		默认省ID
 * @param dfcityId			默认市ID
 * @param dfareaId			默认区县ID
 * @param dfstreetId		默认街道ID
 */
function single_district(callback, dfprovinceId, dfcityId, dfareaId, dfstreetId){
	dfprovinceId = dfprovinceId==undefined ? "": dfprovinceId; 
	dfcityId = dfcityId==undefined ? "": dfcityId; 
	dfareaId = dfareaId==undefined ? "": dfareaId; 
	dfstreetId = dfstreetId==undefined ? "": dfstreetId; 
	var url = home_url + "/ajax/district/single?pid="+dfprovinceId+"&cid="+dfcityId+"&aid="+dfareaId+"&sid="+dfstreetId;
	showDialogModal("选择行政区域",url, function(data){
		var itemdata = {};
		//home_url + 
//		data-required="single_ProvinceId";
//		data-required="single_CityId";
//		data-required="single_DistrictId";
//		data-required="single_StreetId";
		var $selector = $("#single_city-picker-search");
		
		itemdata.provinceId = $selector.find('.storey.province').find('.input-price').val();//省ID
		itemdata.provinceName = $selector.find('.storey.province').find('.reveal').text();//省名称
		itemdata.cityId = $selector.find('.storey.city').find('.input-price').val();//市ID
		itemdata.cityName = $selector.find('.storey.city').find('.reveal').text();//市名称
		itemdata.areaId = $selector.find('.storey.district').find('.input-price').val();//区ID
		itemdata.areaName = $selector.find('.storey.district').find('.reveal').text();//区名称
		itemdata.streetId = $selector.find('.storey.street').find('.input-price').val();//街道ID
		itemdata.streetName = $selector.find('.storey.street').find('.reveal').text();//街道名称
		
		if(itemdata.provinceId>0){
			callback(itemdata);
		}else{
			alertDiag("请选择行政区域!");
			return false;
		}
		
		
	},"960");
}

