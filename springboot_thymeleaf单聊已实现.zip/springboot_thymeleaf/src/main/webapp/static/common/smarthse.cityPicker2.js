﻿/**
 * 使用方法
 */
//行政区域数据包定义
(function ($, window) {
	var $selector;		//行政区域父元素
    var grade = ['province', 'city', 'district', 'street'];		//行政区域级别
    var defaults = {
       // dataJson: null,
        selectpattern: [{
                field: 'userProvinceId',
                placeholder: '请选择省份',
                value : ''
            },
            {
                field: 'userCityId',
                placeholder: '请选择城市',
                value : ''
            },
            {
                field: 'userDistrictId',
                placeholder: '请选择区县',
                value : ''
            },
            {
                field: 'userStreetId',
                placeholder: '请选择乡村街道',
                value : ''
            }
        ],
        remoteUrl : null,
        shorthand: false,
        storage: true,
        keyboard: false,
        code: false,
        level: 4,
        onInitialized: function () {},
        onClickBefore: function () {},
        onForbid: function () {},
        onSelected: function () {}
    };
    
  //功能模块函数
    var effect = {
        montage: function (pid, reg) {
            var self = this,
                config = self.options,
                html = '',
                code, name, storage;
            
            //遍历数据
        	store.each(function(value, key) {
        		if (value.parentId == pid) {
        			//判断是否要输出区号
                    code = config.code && value.cityCode !== '' ? 'data-code=' + value.cityCode : '';
                    //判断是否开启了简写，是就用输出简写，否则就输出全称
                    name = config.shorthand ? value.shortName : value.name;
                    //存储的是数字还是中文
                    storage = config.storage ? value.id : name;
//                    console.info("id="+value.id+",name="+name);
                        //模拟
//                        html += '<li class="caller" data-id="' + data[i].id + '" data-title="' + name + '" ' + code + '>' + name + '</li>';
                    html = '<a href="javascript:;" class="caller" data-id="' + value.id + '" data-title="' + name + '" ' + code + '>'+name+'</a>'
                    	+ html;
                }
        	})

            html = html ? html : '<li class="forbid">无下级行政区域</li>';
//            console.info("montage>>>>>>>>>>>>>>>");
//            console.info(html);
            return html;
        },
        seTemplet: function () {
            var config = this.options,
                selectemplet = '',
                placeholder, field, forbid, citygrade, active, hide
                ;
            
            var selectemplet = '<span class="addressSum">--请选择--</span>'
            	+ '<i class="addressSum-i icon-angle-down ml5"></i>'
            	+ '<div class="address-box hide">'
            	+'<i class="fr icon-remove dan_grey mt5 mr5 close_1 ft20"> </i>'
            	+'<ul  id="addressTab" class="addressTab nav nav-tabs">';
          //循环定义的级别
            for (var i = 0; i < config.level; i++) { 
            	placeholder = config.selectpattern[i].placeholder; //默认提示语
                field = config.selectpattern[i].field; //字段名称
                citygrade = grade[i]; //城市级别名称
                forbid = i > 0 ? 'forbid' : ''; //添加鼠标不可点击状态
                active = i < 1 ? 'active' : ''; //添加选中状态
                hide = i > 0 ? ' hide' : ''; //添加隐藏状态
                
                selectemplet += '<li class="smarthse_CityPickerV2_TabTitle smarthse_CityPickerV2_TabTitle_'+field+' '+active+' " data-index="' + i + '">'
                +'<a href="#smarthse_CityPickerV2_'+field+'" class="reveal" data-toggle="tab" >'+placeholder+'</a>'
                +'<input type=hidden name="' + field + '" class="input-price val-error" value="" />'
                +'</li>';
            }
            selectemplet += '</ul>'
            	+'<div class="tab-content addressTabContent">';
          //循环定义的级别
            for (var i = 0; i < config.level; i++) { 
            	placeholder = config.selectpattern[i].placeholder; //默认提示语
                field = config.selectpattern[i].field; //字段名称
                citygrade = grade[i]; //城市级别名称
                forbid = i > 0 ? 'forbid' : ''; //添加鼠标不可点击状态
                active = i < 1 ? 'active' : ''; //添加选中状态
                hide = i > 0 ? ' hide' : ''; //添加隐藏状态
                
                selectemplet += '<div class="smarthse_CityPickerV2_'+field+' addressPane tab-pane fade in '+active+'" >'
                	+'<ul class="areaList listing storey"  data-index="' + i + '"><li></li></ul></div>';
            }	
            selectemplet += '</div></div>';
//            console.info(selectemplet);
            return selectemplet;
        },
        obtain: function (event) {
            var self = this,
                config = self.options,
                $selector = self.$selector,
                $target =  event[0].target ? $(event[0].target) : $(event) ,
                $parent = $target.parents('.listing'),
                $selected = $target.find('.caller:selected'),
                index =  $target.parents('.storey').data('index'),
                id =  $target.attr('data-id') ,
                name = $target.text() ,
                storage = config.storage ? id : name, //存储的是数字还是中文
                code = $target.data('code'),
                //当前级别
                selectpattern = config.selectpattern[index],
            	$current_tab = $("li.smarthse_CityPickerV2_TabTitle_"+selectpattern.field),
                $current_listing = $("div.smarthse_CityPickerV2_"+selectpattern.field),
                
                parentValueId = config.selectpattern[index].value;		//父级默认Id
                defualtvalueId = index+1 < config.level ? config.selectpattern[index+1].value : '0',
                placeholder = index+1 < config.level ? config.selectpattern[index+1].placeholder : '',
                //下级元素
                next_selectpattern = index+1 < config.level ? config.selectpattern[index+1] : null,
                $next_tab = index+1 < config.level ? $("li.smarthse_CityPickerV2_TabTitle_"+next_selectpattern.field) : null,
                $next_listing = index+1 < config.level ? $("div.smarthse_CityPickerV2_"+next_selectpattern.field) : null,
                values = { 'id': id || '0', 'name': name };
//            console.info("obtain id="+id+",name="+name+",index="+index);
            // 存储选择的值
            if (index === 0) {
                self.cityPickerData.province = values;
                self.cityPickerData.city= null;
                self.cityPickerData.district=null;
                self.cityPickerData.street=null;
                effect.clear(self, index , id);			//当前级别+1,清除市信息
                effect.clear(self, index+1 , id);		//当前级别+2,清除区县信息
                effect.clear(self, index+2 , id);		//当前级别+3,清除街道信息
                //
                var html = self.cityPickerData.province.name;
                $selector.find('.addressSum').text(html);
                $selector.width($selector.find('.addressSum').outerWidth(true));
            } else if (index === 1) {
                self.cityPickerData.city = values;
                self.cityPickerData.district=null;
                self.cityPickerData.street=null;
                effect.clear(self, index , id);			//当前级别+1,清除区县信息
                effect.clear(self, index+1 , id);		//当前级别+2,清除街道信息
                
                //
                var html = self.cityPickerData.province.name+'/'+self.cityPickerData.city.name;
                $selector.find('.addressSum').text(html);
                $selector.width($selector.find('.addressSum').outerWidth(true));
                
            } else if (index === 2) {
                self.cityPickerData.district= values;
                self.cityPickerData.street=null;
                effect.clear(self, index , id);			//当前级别+1,清除街道信息
                
                //
                var html = self.cityPickerData.province.name+'/'+self.cityPickerData.city.name+'/'+self.cityPickerData.district.name;
                $selector.find('.addressSum').text(html);
                $selector.width($selector.find('.addressSum').outerWidth(true));
            } else if (index === 3) {
            	self.cityPickerData.street = values;
            	//
                var html = self.cityPickerData.province.name+'/'
                	+self.cityPickerData.city.name+'/'
                	+self.cityPickerData.district.name+'/'
                	+self.cityPickerData.street.name;
                $selector.find('.addressSum').text(html);
                $selector.width($selector.find('.addressSum').outerWidth(true));
            }
            
            //赋值
            $current_tab.find('.reveal').text(name).siblings('.input-price').val(storage);
            
            //若还有下个层级,则继续调用
            $next_tab!=null && setTimeout(function(){effect.getdata(config, id, function(dataLeng){
//            	console.info("id="+id+",name="+name+",index="+index+",dataLeng="+dataLeng);
            	var autoSelectedStr = effect.montage.apply(self, [id]);
//            	console.info(autoSelectedStr);
            	
                if(dataLeng==0){
                	//无子集,则隐藏下级
                	$next_tab!=null && $next_tab.addClass('hide');
                	$next_listing!=null && $next_listing.addClass('hide');
                	//保留当前级别显示状态
                	$current_tab.addClass('active');
                	$current_listing.addClass('active');
                	$current_listing.find('.listing').removeClass('hide');
                	
                	effect.clear(self, index , id);
                }	else {
                    //当前TAB标题改为行政区域名称
                    $next_tab!=null && $current_tab.removeClass('active');
                    $next_listing!=null && $current_listing.removeClass('active');
                    $next_listing!=null && $current_listing.find('.listing').addClass('hide');
                  
                  //激活下个TAB
                    $next_tab!=null && $next_tab.addClass('active');
                    $next_tab!=null && $next_tab.removeClass('hide');
                    $next_listing!=null && $next_listing.addClass('active');
                    $next_listing!=null && $next_listing.removeClass('hide');
                    
                        console.info("parentValueId="+parentValueId+",defualtvalueId="+defualtvalueId+",id="+id);
                        //TODO 默认加载哪一项数据,并与之对应,,,data-id="130000000000"
                        //defualtvalueId>0
                        if(parentValueId==id && defualtvalueId>0){
                        	//TODO 带值则默认选择第1项(0表示请选择项)
                        	$next_listing.data('id', id).find('li').html(autoSelectedStr).find('.caller[data-id="'+defualtvalueId+'"]').eq(0).trigger('click');
                        }else{
                        	$next_listing.find('.listing').eq(0).find('li').html(autoSelectedStr);
                        }
                        
                        $next_listing!=null && $next_listing.find('.listing').removeClass('hide');
                        
//                        $storey.find('.reveal').text(placeholder).addClass('df-color').siblings('.input-price').val('');
                        $next_listing!=null && $next_listing.find('.reveal').text(placeholder).siblings('.input-price').val('');
//                        $listing.find('.caller').eq(0).remove();
                }	
                
            });}, 10);
            
            //通知外部事件
            config.onSelected.call(grade[index], self.cityPickerData);
        },
        show: function (event) {
            var config = this.options,
                $target = $(event)
                index = $target.parents('.storey').data('index')
                ;
            $selector = this.$selector;

//            $selector.find('.smarthse_CityPickerV2_TabTitle').removeClass('active');
//            $selector.find('.addressPane').removeClass('active');
//            $selector.find('.listing').addClass('hide');
            
//            $target.addClass('active');
            $target.find('.input-search').focus();
            
            $selector.find('.addressPane').eq(index).addClass('active');
            $selector.find('.addressPane').eq(index).find('.listing').removeClass('hide');
//            $target.siblings('.listing').removeClass('hide').find('.input-search').focus();
//            console.info('show>>>>>index:'+index);
        },
        showTab: function (event) {
            var config = this.options,
                $target = $(event);
            $selector = this.$selector;

            $selector.find('.smarthse_CityPickerV2_TabTitle').removeClass('active');
            $selector.find('.addressPane').removeClass('active');
            $selector.find('.listing').addClass('hide');
            
            $target.addClass('active');
            $target.find('.input-search').focus();
            $selector.find('.addressPane').eq($target.index()).addClass('active');
            $selector.find('.addressPane').eq($target.index()).find('.listing').removeClass('hide');
//            $target.siblings('.listing').removeClass('hide').find('.input-search').focus();
//            console.info('show>>>>>index:'+$target.index());
        },
        hide: function (event) {
            var config = this.options,
//                $target = $(event),
                $target =  event.target ? $(event.target) : $(event) ,
                index = $target.parents('.storey').data('index')
                ;

            effect.obtain.call(this, $target);

            index+1 < config.level && $selector.find('.listing').addClass('hide');
            
//            console.info('hide>>>>>index:'+index);
            return false;
        },
        clear : function(self, index, id){
//        	console.info("clear>>>>index="+index);
        	//初始化某层级项
        	var config = self.options,
        		$selector = self.$selector,
        		//下级元素
                next_selectpattern = index+1 < config.level ? config.selectpattern[index+1] : null,
                $next_tab = next_selectpattern!=null ? $("li.smarthse_CityPickerV2_TabTitle_"+next_selectpattern.field) : null,
                $next_listing = next_selectpattern!=null ? $("div.smarthse_CityPickerV2_"+next_selectpattern.field) : null,
	        	placeholder = next_selectpattern!=null ? next_selectpattern.placeholder : ''
	        	;
        	
        	
            if(next_selectpattern!=null){
            	$next_tab.find('.reveal').text(placeholder).siblings('.input-price').val('');
            	$next_listing.find('.listing').eq(0).find('li').html('');
            }
            
        },
        search: function (event) {
            event.preventDefault();
            console.info('search>>>>>');
            return false;
        },
        operation: function (event) {
            event.preventDefault();
            console.info('operation>>>>>');
            return false;
        },
        position: function (event) {
            var $target = event,
                $caller = $target.find('.caller.active'),
                oh = $target.outerHeight(),
                ch = $caller.outerHeight(),
                dy = $caller.position().top,
                sy = $target.find('ul').scrollTop();

            $target.find('ul').animate({
                scrollTop: dy + ch - oh + sy
            }, 200);
        },
        getdata : function(config, pid, callback){
        	//console.info('从服务端获取数据,并保存到store中, pid='+pid);
        	var localCount = effect.getlocaldatacount(pid);
        	if(localCount>0 || pid==-1){
        		//从本地加载数据
        		//console.info('从本地加载数据, pid='+pid);
        		callback(localCount);
        	}else{
        		//从服务端加载数据
        		//console.info('从服务端加载数据, pid='+pid);
        		effect.getRemotedata(config, pid, callback);
        	}
        },
        getlocaldatacount : function(pid){
        	//判断本地数据是否已下载,无数据跳过
        	var count = 0;
        	//遍历数据
        	store.each(function(value, key) {
        		if (value.parentId == pid) {
//        			console.info(key, '==', value);
                	count++;
                }
        	})
        	
        	return count;
        },
        getRemotedata: function(config, pid, callback){
        	//从远端获取数据
        	post(config.remoteUrl+pid, null, function(data){
    			if(data.state.value==0 && data.result != undefined) {
    				//有数据返回
			    	for(var i=0;i<data.result.length;i++){
						var item = data.result[i];
						var citydata_obj = {};
						citydata_obj.id=item.id;
						citydata_obj.name=item.name;
						citydata_obj.parentId=item.parentId;
						citydata_obj.shortName=item.shortName;
						citydata_obj.letter=item.py;
						citydata_obj.cityCode=item.id;
						citydata_obj.shortpinyin=item.py;
						citydata_obj.pinyin=item.pyFull;
						citydata_obj.level=item.level;
//						console.info(citydata_obj);
						//保存到store中
						store.set(citydata_obj.id, citydata_obj);
					}
    			}
    			//返回数据结果
    			callback(data.result == undefined ? 0 : data.result.length);
        	});
        }
    };
    
    function smarthse_CityPickerV2(options, selector) {
        this.options = $.extend({}, defaults, options);
        this.$selector = $selector = $(selector);
        this.values = [];
        this.cityPickerData = {};
        this.province = this.city = this.district = '';

        this.init();
        this.bindEvent();
    }
    
    smarthse_CityPickerV2.prototype = {
            init: function () {
                var self = this,
                    config = self.options,
                    valueId = config.selectpattern[0].value,
                    code = config.code ? '<input type="hidden" role="code" name="' + config.code + '" value="">' : '';
                    //是否开启存储区号，是就加入一个隐藏域
                console.info("初始化省列表");
                //添加拼接好的模板
                $selector.html(effect.seTemplet.call(self) + code);
                
                $selector.width($selector.find('.addressSum').outerWidth(true));
                
                //html模板
                setTimeout(function(){effect.getdata(config, 0, function(){
                    //模拟>添加数据
                	$selector.find('.listing').eq(0).find('li').html(effect.montage.apply(self, ['0']));
                	//TODO 默认加载哪一项数据,并与之对应,,,data-id="130000000000"
                    if(valueId>0){
                    	$selector.find('.listing').eq(0).find('li').find('.caller[data-id="'+valueId+'"]').eq(0).trigger('click');
                    }

                    //初始化后的回调函数
                    config.onInitialized.call(self);
                });}, 10);
            },
            bindEvent: function () {
                var self = this,
                    config = self.options;
                var h1;//鼠标移入时列表容器的高度
                var h2;//鼠标移出时列表容器的高度
                $selector.mouseover(function(){
                	$selector.find('.address-box').removeClass("hide");
                	$selector.find('.addressSum').css("border-bottom","0px");
                	h1=$selector.find('.address-box').height();
	            }).mouseleave(function(event){ 
	            	h2=$selector.find('.address-box').height();
 					if(h2==h1){//鼠标移出列表容器高度没有变化时 列表容器隐藏
 						$selector.find('.address-box').addClass("hide");
 		            	$selector.width($(".addressSum").outerWidth(true));
 		            	$selector.find('.addressSum').css("border-bottom","1px solid #d5d5d5");
 					}
	            });
                
                //点击显示对应的列表
                $selector.on('click.citypicker', '.listing a', function (event) {
                	
                    event.preventDefault();
                    var $this = $(this);
//                    console.info("$selector.on('click.citypicker'");
//                    console.info($this);
                    if ($this.is('.forbid')) {
                        config.onForbid.call($this);
                        return false;
                    }
                    effect.show.call(self, $this);
                    return false;
                });
                //点击选项事件
                $selector.on('click.citypicker', '.caller', $.proxy(effect.hide, self));
               
              //Tab切换
                $selector.on('click.citypicker', 'li.smarthse_CityPickerV2_TabTitle', function (event) {
                    event.preventDefault();
                    var $this = $(this);
//                    console.info("$selector.on(click.citypicker, li.smarthse_CityPickerV2_TabTitle");
//                    console.info($this);
                    if ($this.is('.forbid')) {
                        config.onForbid.call($this);
                        return false;
                    }
                    effect.showTab.call(self, $this);
                    return false;
                });
                
              //点击关闭按钮效果
                $selector.on('click.citypicker', '.close_1', function (event) {
                	$selector.find('.address-box').addClass("hide");
	            	$selector.width($(".addressSum").outerWidth(true));
	            	$selector.find('.addressSum').css("border-bottom","1px solid #d5d5d5");
                });
            },
            unBindEvent: function (event) {
                var self = this,
                    config = self.options;
            }
        };


        $.fn.smarthse_CityPickerV2 = function (options) {
            return new smarthse_CityPickerV2(options, this);
        };
    
    
	
})(jQuery, window);

