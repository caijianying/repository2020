﻿/**
 * chosen使用方法
 */
//行政区域数据包定义
(function ($, window) {
	var $selector;		//下拉框指定元素
    var defaults = {
    	dataJson: [],		//本地数据包
    	search: true,		//是否带搜索
    	autoSelected: true,
    	optgroup : false,	//是否带分组
    	showtypeCode : false,	//是否显示typeCode
    	valueId : '',			//默认ID
        remoteUrl : null	//后端地址
        
    };
    
  //功能模块函数
    var effect = {
    		montage: function (data, dataCode) {
                var self = this,
                    config = self.options,
                    leng = data.length,
                    html = '',
                   name;
//                console.info("montage dataCode="+dataCode);
                //TODO 是否带分组显示
                for (var i = 0; i < leng; i++) {
                	var item = data[i];
                	if(item.parentId==undefined){
                		continue;
                	}
                	if(item.dataCode!=dataCode){
                		continue;
                	}
                	
                    //判断是否开启编码前缀
                    name = config.showtypeCode ? item.typeCode + item.name : item.name;
                   //TODO 是否显示类型父名
                    //模拟
                    html += '<li class="caller" data-id="' + item.id + '" data-title="' + name + '" >' + name + '</li>';
                }

                html = data.length > 0 && html ? html : '<li class="forbid">找不到相关参数项</li>';
                return html;
            },	
		seTemplet: function () {
            var config = this.options,
            	selectemplet = '',
                placeholder = $selector.attr("data-placeholder"),
                field = $selector.attr("data-field"),
                searchStr = config.search ? '<div class="selector-search">'
                    +'<input type="text" class="input-search" value="" placeholder="拼音、中文搜索" />'
                +'</div>' : '';
            
          //模拟
            selectemplet += '<div class="selector-item " >'
                +'<a href="javascript:;" class="selector-name reveal df-color ">' + placeholder + '</a>'
                +'<input type=hidden name="' + field + '" class="input-price val-error" value="" data-required="' + field + '">'
                +'<div class="selector-list listing hide">'+ searchStr +'<ul></ul></div>'
            +'</div>';


            return selectemplet;
        },
        obtain: function (event) {
            var self = this,
                config = self.options,
                $selector = self.$selector,
                $target = event[0].target ? $(event[0].target) : $(event),
                $parent = $target.parents('.listing'),
                $selected = $target.find('.caller:selected'),
                index = $target.parents('.storey').data('index'),
                id = $target.attr('data-id'),
                name = $target.text(),
                code = $target.data('code'),
                placeholder = '',
                placeStr = '<li class="caller hide">'+placeholder+'</li>'+ effect.montage.apply(self, [config.dataJson, id]),
                autoSelectedStr = effect.montage.apply(self, [config.dataJson, id]),
                $storey = $selector.find('.storey').eq(index + 1),
                $listing = $selector.find('.listing').eq(index + 1),
                values = { 'id': id || '0', 'name': name, 'code' : code };
//             console.info(values);
            //选择选项后触发自定义事件choose(选择)事件
            $selector.trigger('choose.chosenpicker', [$target, values]);

            config.search ? $parent.find('.input-search').blur() : '';

            //给选中的级-添加值和文字
            $parent.siblings('.reveal').removeClass('df-color forbid').text(name).siblings('.input-price').val(id);

            if (!config.autoSelected) {
                $storey.find('.reveal').text(placeholder).addClass('df-color').siblings('.input-price').val('');
                $listing.find('.caller').eq(0).remove();
            }

            //模拟: 添加选中的样式
            $parent.find('.caller').removeClass('active');
            $target.addClass('active');
        },
        show: function (event) {
            var config = this.options,
                $target = $(event);
            $selector = this.$selector;

            $selector.find('.listing').addClass('hide');
            $target.siblings('.listing').removeClass('hide').find('.input-search').focus();

        },
        hide: function (event) {
            var config = this.options,
                $target = $(event);

            effect.obtain.call(this, $target);

            $selector.find('.listing').addClass('hide');

            return false;
        },
        search: function (event) {
            event.preventDefault();
            var self = this,
                $target = $(event.target),
                $parent = $target.parents('.listing'),
                inputVal = $target.val(),
                id = $parent.data('id'),
                keycode = event.keyCode,
                result = [];

            //如果是按下shift/ctr/左右/command键不做事情
            if (keycode === 16 || keycode === 17 || keycode === 18 || keycode === 37 || keycode === 39 || keycode === 91 || keycode === 93) {
                return false;
            }

            //如果不是按下enter/上下键的就做搜索事情
            if (keycode !== 13 && keycode !== 38 && keycode !== 40) {
                $.each(this.options.dataJson, function(key, value) {
                	//TODO 可优先查询项进行排序
                	var seachResult1 = value.py != undefined ? value.py.toLocaleLowerCase().search(inputVal) > -1 : false;
                	var seachResult2 = value.pyFull != undefined ? value.pyFull.toLocaleLowerCase().search(inputVal) > -1  : false;
                	var seachResult3 = value.name != undefined ? value.name.toLocaleLowerCase().search(inputVal) > -1  : false;
//                	console.info("ciyt.value="+value+", seachResult1="+seachResult1+",seachResult2="+seachResult2+",seachResult4="+seachResult3+",seachResult2="+seachResult4)
                    //简拼，全拼，名称，ID搜索
                    if(seachResult1 ||  seachResult2|| seachResult3 ){
//                    	console.info("ciyt.value.name="+value.name+"");
                        result.push(value);
                    }
                });

                $parent.find('ul').html(effect.montage.apply(self, [result, id]));
            }
        },
        operation: function (event) {
            event.preventDefault();
            var $target = $(event.target),
                $sibl = $target.hasClass('input-search') ? $target.parents('.listing') : $target.siblings('.listing'),
                $items = $sibl.find('.caller'),
                keyCode = event.keyCode,
                index = 0,
                direction,
                itemIndex;
            
            //按下enter键
            if (keyCode === 13) {
                effect.hide.call(this, $sibl.find('.caller.active'));
                return false;
            }
            
            //按下上下键
            if (keyCode === 38 || keyCode === 40) {

                //方向
                direction = keyCode === 38 ? -1 : 1;
                //选中的索引
                itemIndex = $items.index($sibl.find('.caller.active'));

                if (itemIndex < 0) {
                    index = direction > 0 ? -1 : 0;
                } else {
                    index = itemIndex;
                }

                //键盘去选择的索引
                index = index + direction;

                //循环选择
                index = index === $items.length ? 0 : index;

                $items.removeClass('active').eq(index).addClass('active');

                //滚动条跟随定位
                effect.position.call(this, $sibl);
            }

            return false;
        },
        position: function (event) {
            var $target = event,
                $caller = $target.find('.caller.active'),
                oh = $target.outerHeight(),
                ch = $caller.outerHeight(),
                dy = $caller.position().top,
                sy = $target.find('ul').scrollTop();

            $target.find('ul').animate({
                scrollTop: dy + ch - oh + sy
            }, 200);
        },
        getdata : function(config, dataCode, callback){
        	//console.info('从服务端获取数据,并保存到smarthse_cityData中, pid='+pid);
        	var leng = config.dataJson.length;
        	var localCount = effect.getlocaldatacount(config.dataJson, dataCode);
        	if(localCount>0 || dataCode==-1){
        		//从本地加载数据
        		//console.info('从本地加载数据, dataCode='+dataCode);
        		callback(localCount);
        	}else{
        		//从服务端加载数据
        		//console.info('从服务端加载数据, dataCode='+dataCode);
        		effect.getRemotedata(config, dataCode, callback);
        	}
        },
        getlocaldatacount : function(dataJson, dataCode){
        	//判断本地数据是否已下载,无数据跳过
        	var leng = dataJson.length,
	            count = 0;
        	for (var i = 0; i < leng; i++) {
                if (dataJson[i].dataCode == dataCode) {
                	count++;
                }
            }
        	return count;
        },
        getRemotedata: function(config, dataCode, callback){
        	//从远端获取数据
        	post(config.remoteUrl+dataCode, null, function(data){
    			_contentLoadTriggered=false;
    			if(data.state.value==0 && data.result != undefined) {
    				//有数据返回
			    	for(var i=0;i<data.result.length;i++){
						var item = data.result[i];
						var item_obj = {};
						item_obj.id=item.id;
						item_obj.name=item.name;
						item_obj.parentId=item.parentId;
						item_obj.py=item.py;
						item_obj.pyFull=item.pyFull;
						item_obj.typeCode=item.typeCode;
						item_obj.dataCode=dataCode;
//						console.info(citydata_obj);
						config.dataJson.push(item_obj);
					}
    			}
    			//返回数据结果
    			callback(data.result == undefined ? 0 : data.result.length);
        	});
        }
    };
    
    function smarthse_chosen(options, selector) {
        this.options = $.extend({}, defaults, options);
        this.$selector = $selector = $(selector);

        this.init();
        this.bindEvent();
    }
    
    smarthse_chosen.prototype = {
            init: function () {
                var self = this,
                    config = self.options,
                    valueId = config.valueId,
                    dataCode = $selector.attr("data-code");
                    ;
                    //是否开启存储区号，是就加入一个隐藏域
                console.info("dataCode="+dataCode);
              //有相关数据,初始化UL
        		$selector.html(effect.seTemplet.call(self));
        		
        		var $select = $selector;//使用私有变量，避免初始化到一个里面
                //html模板
                setTimeout(function(){effect.getdata(config, dataCode, function(lenCount){
                	//模拟>添加数据
                	$select.find('.listing').data('id', dataCode).eq(0).find('ul').html(effect.montage.apply(self, [config.dataJson, dataCode]));
                	//TODO 增加选项
                	if(valueId>0){
                		$select.find('.listing').data('id', '0').eq(0).find('ul').find('.caller[data-id="'+valueId+'"]').eq(0).trigger('click');
                    }
                	
                	
                });}, 10);
            },
            bindEvent: function () {
                var self = this,
                    config = self.options;

                //点击显示对应的列表
                $selector.on('click.chosenpicker', '.reveal', function (event) {
                    event.preventDefault();
                    var $this = $(this);

                    if ($this.is('.forbid')) {
                        return false;
                    }

                    effect.show.call(self, $this);
                    return false;
                });

                //点击选项事件
                $selector.on('click.chosenpicker', '.caller', $.proxy(effect.hide, self));

                //原生选择事件
                $selector.on('change.chosenpicker', 'select', $.proxy(effect.obtain, self));

                //文本框搜索事件
                $selector.on('keyup.chosenpicker', '.input-search', $.proxy(effect.search, self));

                //开启键盘操作
                if (config.keyboard) {
                    //键盘选择事件
                    $selector.on('keyup.chosenpicker', '.storey', $.proxy(effect.operation, self));
                }
            },
            unBindEvent: function (event) {
                var self = this,
                    config = self.options;

                if (!config.renderMode) {
                    $selector.off('change.chosenpicker', 'select');
                    return false;
                }

                $selector.off('click.chosenpicker', '.reveal');

                $selector.off('click.chosenpicker', '.caller');

                $selector.off('keyup.chosenpicker', '.input-search');

                $selector.off('keyup.chosenpicker', '.storey');

            },
        };

        //模拟：执行点击区域外的就隐藏列表;
    	$(document).on('click.chosenpicker', function (event){
    		if($selector && $selector.find(event.target).length < 1) {
    			$selector.find('.listing').addClass('hide');
    		}
        });

        $.fn.smarthse_chosen = function (options) {
            return new smarthse_chosen(options, this);
        };
    
    
	
})(jQuery, window);

