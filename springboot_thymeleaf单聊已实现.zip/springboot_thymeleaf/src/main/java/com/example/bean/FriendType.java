package com.example.bean;

import com.example.bean.base.BaseBean;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;

public @Data class FriendType implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -5872007272165865137L;
	@Id
	private Long id;

    private String typeName;

    private Long userId;

    private Date createDate;

    private Integer isDefault;


    private Boolean isValid;
}