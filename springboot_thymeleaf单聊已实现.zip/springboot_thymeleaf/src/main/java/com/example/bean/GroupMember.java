package com.example.bean;

import com.example.bean.base.BaseBean;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;

public @Data class GroupMember implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -2015212611531490251L;
	@Id
	private Long id;

    private Long userId;

    private Long pid;

    private Long groupId;

    private Boolean roleType;

    private Date createDate;

    private Boolean isValid;

 
}