package com.example.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Transient;

import com.example.bean.base.BaseBean;

import lombok.Data;

public @Data class User implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 5775449284945475088L;
	
	@Id
	private Long id;
	
	private String loginName;
	@Transient
    private String username;

    private String password;
    
    private String token;

    private String nickName;

    private Integer gender;

    private Integer onlineState;

    private String avatar;

    private String email;

    private String phone;

    private String sign;

    private Date createDate;

    private Boolean isValid;
    
    @Transient
    private String status;
}