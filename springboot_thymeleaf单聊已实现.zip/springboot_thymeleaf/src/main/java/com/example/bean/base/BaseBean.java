package com.example.bean.base;

import java.io.Serializable;


import lombok.Data;

public @Data class BaseBean implements Serializable {


	private static final long serialVersionUID = 1556124368872305796L;
	/**
	 * 头像
	 */
	private String avatar;
	
	/**
	 * 用户ID
	 */
	private Long id;
	
	/**
	 * 用户名
	 */
	private String username;
	
	/**
	 * 消息内容
	 */
	private String content;

}
