package com.example.bean;

import com.example.bean.base.BaseBean;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;

public @Data class Group implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 8442243339526203090L;
	@Id
	private Long id;

    private String groupName;

    private String avator;

    private Long ownerId;

    private Integer status;

    private Date createDate;

    private String description;
    
    private Boolean isValid;

 
}