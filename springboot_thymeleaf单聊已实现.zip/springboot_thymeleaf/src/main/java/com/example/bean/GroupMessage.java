package com.example.bean;

import com.example.bean.base.BaseBean;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;

public @Data class GroupMessage implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 3112343314274785424L;
	@Id
	private Long id;

    private Long userId;

    private Long groupId;

    private String content;

    private Integer isDel;

    private Integer isRead;

    private Date sendTime;

    private Integer isBack;
    
    private Date createDate;

    private Boolean isValid;

   
}