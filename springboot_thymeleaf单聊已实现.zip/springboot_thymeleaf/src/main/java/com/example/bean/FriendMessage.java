package com.example.bean;

import com.example.bean.base.BaseBean;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;

public @Data class FriendMessage implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -1218196570010179047L;
	@Id
	private Long id;

    private Long fromUserId;

    private Long toUserId;

    private String content;

    private Date sendTime;

    private Integer isRead;

    private Integer isDel;

    private Integer isBack;

    private Date createDate;

    private Boolean isValid;
    
    private Date updateDate;
    
    /**
     *   <result column="create_by" jdbcType="BIGINT" property="createBy" />
      <result column="update_by" jdbcType="BIGINT" property="updateBy" />
     */
    private Long createBy;
    
    private Long updateBy;
  
}