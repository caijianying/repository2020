package com.example.bean;

import com.example.bean.base.BaseBean;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;

public @Data class Friend implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 9039227748280606411L;

	@Id
	private Long id;

    private Long userId;

    private Long friendId;

    private Long typeId;

    private Date createDate;

    private Boolean isValid;
}