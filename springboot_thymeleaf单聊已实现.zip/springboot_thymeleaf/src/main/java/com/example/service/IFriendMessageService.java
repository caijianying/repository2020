package com.example.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.example.bean.FriendMessage;
import com.example.model.SendMessageModel;
import com.example.service.base.IBaseService;

@Transactional
public interface IFriendMessageService extends IBaseService<FriendMessage> {

	//未读的msg
	List<FriendMessage> getByFormAndToUserId(Long fromUserId,Long toUserId);
	
	void updateByBatch(List<FriendMessage> msgs,Long updateBy);
	
	void processSendFriendMsg(SendMessageModel model);
	
}
