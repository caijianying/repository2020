package com.example.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.bean.FriendMessage;
import com.example.bean.GroupMessage;
import com.example.dao.GroupMessageMapper;
import com.example.model.SendMessageModel;
import com.example.service.IGroupMessageService;
import com.example.service.base.BaseServiceImpl;

import tk.mybatis.mapper.entity.Example;
@Service
@Transactional(readOnly=true)
public class GroupMessageServiceImpl extends BaseServiceImpl<GroupMessageMapper, GroupMessage> implements IGroupMessageService {

	@Override
	@Transactional(readOnly=false)
	public void processSendGroupMsg(SendMessageModel model) {
		if (model==null) {
			logger.info("处理信息失败!实体为空!!");
			throw new RuntimeException("处理信息失败!实体为空!!");
		}
		
		Long userId = model.getFromUserId();
   	 	String content = model.getContent();
        Long groupId = model.getGroupId();
        String type = model.getType();
        
        if (type!=null && type.equals("group")) {
        	//处理好友发送消息
        	logger.info("处理发送群消息,开始!SendMessageModel:{}",model);
        	//1.未读设置为已阅
        	List<GroupMessage> list = this.getByGroupAndUserId(userId, groupId);
        	for (GroupMessage gmsg : list) {
				if (gmsg!=null) {
					gmsg.setIsRead(1);
				}
				this.update(gmsg, userId);
			}
        	
        	//2.保存发送的信息
        	GroupMessage msg = new GroupMessage();
        	msg.setUserId(userId);
        	msg.setContent(content);
        	msg.setGroupId(groupId);
        	msg.setIsRead(0);
        	msg.setSendTime(new Date());
        	
        	this.add(msg, userId);
        }
		
	}

	@Override
	public List<GroupMessage> getByGroupAndUserId(Long userId, Long groupId) {
		Example example = new Example(GroupMessage.class);
		example.createCriteria().andEqualTo("isValid", true).andEqualTo("userId", userId).andEqualTo("isRead", 0).andEqualTo("groupId", groupId);
		example.setOrderByClause("send_time desc");
		
		List<GroupMessage> list = this.getListByExample(example);
		
		return list;
	}

}
