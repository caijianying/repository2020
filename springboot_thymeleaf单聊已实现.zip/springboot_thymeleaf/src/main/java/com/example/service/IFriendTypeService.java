package com.example.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.example.bean.Friend;
import com.example.bean.FriendType;
import com.example.service.base.IBaseService;

@Transactional
public interface IFriendTypeService extends IBaseService<FriendType> {
	
	List<FriendType> getByUserId(Long userId);
}
