package com.example.service;

import org.springframework.transaction.annotation.Transactional;

import com.example.bean.User;
import com.example.model.FriendFormModel;
import com.example.service.base.IBaseService;

@Transactional
public interface IUserService extends IBaseService<User>{
	FriendFormModel getFriendForm(Long userId);
	
	User getByLoginName(String loginName);
	
	User getByToken(String token);
}
