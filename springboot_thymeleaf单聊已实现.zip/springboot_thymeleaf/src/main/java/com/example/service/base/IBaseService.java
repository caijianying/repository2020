/**
 * 
 */
package com.example.service.base;

import java.util.List;

/**
 * 《基础Service接口定义》
 * <li>此处定义的接口可被引用并注册至dobbo
 * 
 * @Project:  GIIANTECH CORE
 * @Module ID:   <(模块)类编号，可以引用系统设计中的类编号>
 * @Comments:  <对此类的描述，可以引用系统设计中的描述>
 * @JDK version used:      <JDK1.7> 
 * @author JannyShao(邵建义) [ksgameboy@qq.com]
 * @since 2017-5-25-上午9:17:44
 */
public interface IBaseService<T> {

	/**
	 * 根据ID获取单条数据
	 * @param id
	 * @return
	 */
	T getById(Long id);
	
	
	/**
	 * 新增数据
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
	 * @since 2017-7-17-下午3:49:17
	 * @param entity
	 * @return
	 */
	T add(T entity);
	
	/**
	 * 新增数据
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
	 * @since 2018年5月28日-上午10:44:19
	 * @param entity
	 * @param createBy
	 * @return
	 */
	T add(T entity,Long createBy);
	
	/**
	 * 保存数据（必须带有关键字段）
	 * @param entity
	 * @return	更新成功条数
	 */
	Integer update(T entity);
	
	/**
	 * 保存数据（必须带有关键字段）
	 * @param entity
	 * @param updateBy 更新用户Id
	 * @return	更新成功条数
	 */
	Integer update(T entity,Long updateBy);
	
	/**
	 * 更新全部数据(包含NULL字段)
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
	 * @since 2017-7-3-下午1:34:50
	 * @param entity
	 * @param updateBy	updateBy 更新用户Id
	 * @return	更新成功条数
	 */
	Integer updateByPrimaryKey(T entity,Long updateBy);
	
	/**
	 * 逻辑删除
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
	 * @since 2017-6-28-上午9:52:30
	 * @param entity
	 * @param updateBy	updateBy 更新用户Id
	 * @return	删除成功条数
	 */
	Integer delete(T entity,Long updateBy);
	
	/**
	 * 根据ID逻辑删除
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
	 * @since 2017-6-28-上午9:52:30
	 * @param id		ID
	 * @param updateBy	updateBy 更新用户Id
	 * @return	删除成功条数
	 */
	Integer deleteById(Long id,Long updateBy);
	
	/**
     * 根据主键字符串进行查询，类中只有存在一个带有@Id注解的字段
     *
     * @param ids 如 "1,2,3,4"
     * @return
     */
	List<T> getListByIds(String ids);
	
	
}
