package com.example.service.impl;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.bean.FriendType;
import com.example.dao.FriendTypeMapper;
import com.example.service.IFriendTypeService;
import com.example.service.base.BaseServiceImpl;

import tk.mybatis.mapper.entity.Example;


@Service
@Transactional(readOnly=true)
public class FriendTypeServiceImpl extends BaseServiceImpl<FriendTypeMapper, FriendType> implements IFriendTypeService {

	@Override
	public List<FriendType> getByUserId(Long userId) {
		Example example = new Example(FriendType.class);
		example.createCriteria().andEqualTo("isValid", true).andEqualTo("userId", userId);
		return this.getListByExample(example);
	}

}
