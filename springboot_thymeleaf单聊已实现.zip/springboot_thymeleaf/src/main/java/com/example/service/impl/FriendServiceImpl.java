package com.example.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.bean.Friend;
import com.example.dao.FriendMapper;
import com.example.service.IFriendService;
import com.example.service.base.BaseServiceImpl;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
@Transactional(readOnly=true)
public class FriendServiceImpl extends BaseServiceImpl<FriendMapper, Friend> implements IFriendService {

	@Override
	public List<Friend> getByUserIdAndTypeId(Long userId, Long typeId) {
		Example example = new Example(Friend.class);
		Criteria c = example.createCriteria();
		c.andEqualTo("isValid", true);
		if (userId!=null) {
			c.andEqualTo("userId", userId);
		}
		if (typeId!=null) {
			c.andEqualTo("typeId", typeId);
		}
		return this.getListByExample(example);
	}

}
