package com.example.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.example.bean.Friend;
import com.example.service.base.IBaseService;

@Transactional
public interface IFriendService extends IBaseService<Friend> {
	List<Friend> getByUserIdAndTypeId(Long userId,Long typeId);
}
