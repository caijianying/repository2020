package com.example.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.example.bean.GroupMessage;
import com.example.model.SendMessageModel;
import com.example.service.base.IBaseService;
@Transactional
public interface IGroupMessageService extends IBaseService<GroupMessage> {
	
	List<GroupMessage> getByGroupAndUserId(Long userId,Long groupId);
	
	void processSendGroupMsg(SendMessageModel model);
}
