/**
 * 
 */
package com.example.service.base;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.example.dao.base.CommonMapper;

import tk.mybatis.mapper.entity.Example;



/**
 * 
 * 《基础Service支持类》
 * <li>基于通用Mapper 增、删、改、查、根据Example查询列表、根据Example统计单表数量
 * 
 * 
 * @Project:  HealthAdvisor-service
 * @Module ID:   <(模块)类编号，可以引用系统设计中的类编号>
 * @Comments:  <对此类的描述，可以引用系统设计中的描述>
 * @JDK version used:      <JDK1.7> 
 * @author JannyShao(邵建义) [ksgameboy@qq.com]
 * @since 2018年1月8日-下午3:13:00
 */
@Transactional(readOnly = true)
public abstract class BaseServiceImpl<D extends CommonMapper<T>, T> implements IBaseService<T> {
	/**
	 * 日志对象
	 */
	protected Logger logger = LogManager.getLogger(this.getClass());
	
	/**
	 * 持久层对象
	 */
	@Autowired(required=false)
	protected D dao;
	
	/**
	 * 
	 * 
	 * @Comments:  获取缓存key值名称
	 * @author Horsy(何世壹) [hsy@smarthse.cn]
	 * @since 2017年6月28日-上午8:50:58
	 * @return
	 */
	private String getMemoryCacheName(){
		String memoryCacheName = dao.getClass().getInterfaces()[0].getName();
		return memoryCacheName;
	}
	
	/**
	 * 从缓存中获取
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author Horsy(何世壹) [hsy@smarthse.cn]
	 * @since 2017年6月27日-下午4:09:36
	 * @param id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	protected T getFromMemoryCache(Long id){
		if(id == null){
			return null;
		}
		
		String memoryCacheName = this.getMemoryCacheName();
//		if(CacheTables.isUseCache(memoryCacheName)){
//			
//			return  (T) m.get(Constants.MEMORY_CACHE_HSE+memoryCacheName + id);
//		}
		
		return null;
	}
	
	/**
	 * 
	 * 
	 * @Comments:  加入缓存
	 * @author Horsy(何世壹) [hsy@smarthse.cn]
	 * @since 2017年6月27日-下午4:09:22
	 * @param id
	 * @param t
	 */
	protected void putToMemoryCache(Long id ,T t){
		if (id == null || t == null){
			return;
		}
		
		String memoryCacheName = this.getMemoryCacheName();
//		if(CacheTables.isUseCache(memoryCacheName)){
//			
//			m.put(Constants.MEMORY_CACHE_HSE+memoryCacheName + id, Constants.MEMORY_CACHE__EXP, t);
//		}
	}
	
	/**
	 * 删除缓存
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author Horsy(何世壹) [hsy@smarthse.cn]
	 * @since 2017年6月27日-下午4:11:58
	 * @param id
	 */
	protected void delFromMemoryCache(Long id){
		if (id == null ) {
			return;
		}
		String memoryCacheName = this.getMemoryCacheName();
//		if(CacheTables.isUseCache(memoryCacheName)){
//			m.delete(Constants.MEMORY_CACHE_HSE+memoryCacheName + id);
//		}
		
	}
	
	/**
	 * 
	 * 
	 * @Comments:  获取ID
	 * @author Horsy(何世壹) [hsy@smarthse.cn]
	 * @since 2017年6月27日-下午4:20:07
	 * @param entity
	 * @return
	 */
	private Long getIdFromT(T entity){
		Class<? extends Object> cls=entity.getClass();
		Method getId;
		Object id =null;
		try {
			
			getId = cls.getDeclaredMethod("getId");
			if(getId != null) {
				id = getId.invoke(entity);
			}
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		return (Long)id;
	}
	
	
	/**
	 * 根据ID获取单条数据
	 * @param id
	 * @return
	 */
	public T getById(Long id) {
		if(id==null || id==0){
			return null;
		}
		
		T t =  this.getFromMemoryCache(id);
		if(t == null){
			t = dao.selectByPrimaryKey(id);
			if(t == null){
				return null;
			}
			this.putToMemoryCache(id, t);
		}
		return t;
	}
	
	/**
	 * 根据Example条件查询列表数据
	 * @param example
	 * @return
	 */
	public List<T> getListByExample(Example example) {
		return dao.selectByExample(example);
	}
	
	/**
	 * 根据Example条件查询数量
	 * @param example
	 * @return
	 */
	public int getCountByExample(Example example) {
		return dao.selectCountByExample(example);
	}
	
	/**
	 * 设置更新相关的信息
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author Horsy(何世壹) [hsy@smarthse.cn]
	 * @since 2017年6月13日-下午2:33:44
	 * @param entity 需要更新的实体类
	 * @param loginStaffId 当前登录员工ID
	 */
	private void setUpdateInfo(T entity,Long updateBy) {
		Class<? extends Object> cls=entity.getClass();
		Method setUpdateDate;
		Method setUpdateBy;
		try {
			
			setUpdateDate = cls.getDeclaredMethod("setUpdateDate",Date.class);
			if(setUpdateDate != null) {
				setUpdateDate.invoke(entity, new Date());
			}
			
			if (updateBy != null) {
				setUpdateBy = cls.getDeclaredMethod("setUpdateBy",Long.class);
				if(setUpdateBy != null) {
					setUpdateBy.invoke(entity, updateBy);
				}
			}
			
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 设置isvalid
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
	 * @since 2017-6-28-上午9:54:53
	 * @param entity
	 * @param bln
	 */
	private void setIsValid(T entity, boolean bln){
		Class<? extends Object> cls=entity.getClass();
		Method setIsValid;
		
		try {
			setIsValid = cls.getDeclaredMethod("setIsValid",Boolean.class);
			if(setIsValid != null) {
				setIsValid.invoke(entity, bln);
			}
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 設置創建記錄相关的信息
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author Horsy(何世壹) [hsy@smarthse.cn]
	 * @since 2017年6月13日-下午2:30:17
	 * @param entity 		实体类
	 * @param createBy 		当前用户ID
	 */
	private void setCreateInfo(T entity,Long createBy){
		Class<? extends Object> cls=entity.getClass();
		Method setCreateDate;
		Method setCreateBy;
		try {
			setCreateDate = cls.getDeclaredMethod("setCreateDate",Date.class);
			if(setCreateDate != null) {
				setCreateDate.invoke(entity, new Date());
			}
			
			//设置有效状态
			setIsValid(entity, true);
			
			if (createBy != null) {
				setCreateBy = cls.getDeclaredMethod("setCreateBy",Long.class);
				if(setCreateBy != null) {
					setCreateBy.invoke(entity, createBy);
				}
			}
			
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	/**
	 * 新增数据（返回entity.id）
	 * @param entity
	 */
	@Transactional(readOnly = false)
	public T add(T entity) {
		dao.insertSelective(entity);
		return entity;
	}
	
	/**
	 * 新增数据（返回entity.id）
	 * @param entity
	 */
	@Transactional(readOnly = false)
	public T add(T entity,Long createBy) {
		this.setCreateInfo(entity, createBy);
		this.setUpdateInfo(entity, createBy);
		
		dao.insertSelective(entity);
		
		this.putToMemoryCache(this.getIdFromT(entity), entity);
		
		return entity;
	}
	
	/**
	 * 保存数据（必须带有关键字段）
	 * @param entity
	 */
	@Transactional(readOnly = false)
	public Integer update(T entity){
		int updateCount = dao.updateByPrimaryKeySelective(entity);
		
		Long id = this.getIdFromT(entity);
		this.delFromMemoryCache(id);
		
		return updateCount;
	}
	
	/**
	 * 保存数据（必须带有关键字段）
	 * @param entity
	 * @param updateBy 当前用户ID
	 */
	@Transactional(readOnly = false)
	public Integer update(T entity,Long updateBy) {
		this.setUpdateInfo(entity, updateBy);
		Integer updateCount = dao.updateByPrimaryKeySelective(entity);
		
		Long id = this.getIdFromT(entity);
		this.delFromMemoryCache(id);
		
		return updateCount;
	}
	
	/**
	 * 更新全部数据(包含NULL字段)
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
	 * @since 2017-7-3-下午1:34:50
	 * @param entity		更新实体
	 * @param updateBy		更新用户Id
	 */
	@Transactional(readOnly = false)
	public Integer updateByPrimaryKey(T entity,Long updateBy) {
		this.setUpdateInfo(entity, updateBy);
		Integer updateCount = dao.updateByPrimaryKey(entity);
		Long id = this.getIdFromT(entity);
		this.delFromMemoryCache(id);
		
		return updateCount;
	}
	
	/**
	 * 逻辑删除
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
	 * @since 2017-6-28-上午9:52:30
	 * @param entity
	 * @param deleteBy			删除操作者用户ID
	 */
	@Transactional(readOnly = false)
	public Integer delete(T entity,Long deleteBy) {
		
		this.setUpdateInfo(entity, deleteBy);
		this.setIsValid(entity, false);
		
		//提交更新
		int updateCount = dao.updateByPrimaryKeySelective(entity);
		
		//根据ID清除缓存
		Long id = this.getIdFromT(entity);
		this.delFromMemoryCache(id);
		
		return updateCount;
	}
	
	/**
	 * 根据Id逻辑删除
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
	 * @param entity
	 * @param updateBy
	 */
	@Transactional(readOnly = false)
	public Integer deleteById(Long id,Long updateBy) {
		//根据Id获取 实体
		T entity = getById(id);
		if(entity!=null) {
			return delete(entity, updateBy);
		}
		//删除失败，返回0
		return 0;
	}
	
	/**
     * 根据主键字符串进行查询，类中只有存在一个带有@Id注解的字段
     *
     * @param ids 如 "1,2,3,4"
     * @return
     */
	public List<T> getListByIds(String ids){
		return dao.selectByIds(ids);
	}
	
	/**
	 * 根据Example读取1条记录
	 * 
	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
	 * @since 2017-7-27-上午9:18:28
	 * @param example
	 * @return
	 */
	protected T getOneByExample(Example example){
		List<T> list = dao.selectByExampleAndRowBounds(example, new RowBounds(0, 1));
		if(list.size()>0){
			return list.get(0);
		}
		
		return null;
	} 
}
