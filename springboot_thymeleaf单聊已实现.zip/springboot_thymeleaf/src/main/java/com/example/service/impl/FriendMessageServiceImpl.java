package com.example.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.bean.FriendMessage;
import com.example.dao.FriendMessageMapper;
import com.example.model.SendMessageModel;
import com.example.service.IFriendMessageService;
import com.example.service.base.BaseServiceImpl;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;
@Service
@Transactional(readOnly=true)
public class FriendMessageServiceImpl extends BaseServiceImpl<FriendMessageMapper, FriendMessage> implements IFriendMessageService {

	@Override
	public List<FriendMessage> getByFormAndToUserId(Long fromUserId,Long toUserId) {
		Example example = new Example(FriendMessage.class);
		Criteria c = example.createCriteria().andEqualTo("isValid", true).andEqualTo("toUserId", toUserId).andEqualTo("isRead", 0);
		if (fromUserId!=null) {
			c.andEqualTo("fromUserId", fromUserId);
		}
		example.setOrderByClause("send_time desc");
		
		List<FriendMessage> list = this.getListByExample(example);
		
		return list;
	}

	@Override
	@Transactional(readOnly=false)
	public void updateByBatch(List<FriendMessage> msgs, Long updateBy) {
		for (FriendMessage msg : msgs) {
			if (msg!=null) {
				logger.info("好友消息id:{}已阅",msg.getId());
				this.update(msg, updateBy);
			}
		}
		
	}

	@Override
	@Transactional(readOnly=false)
	public void processSendFriendMsg(SendMessageModel model) {
		if (model==null) {
			logger.info("处理信息失败!实体为空!!");
			throw new RuntimeException("处理信息失败!实体为空!!");
		}
		
		Long fromUserId = model.getFromUserId();
   	 	String content = model.getContent();
        Long toUserId = model.getToUserId();
        String type = model.getType();
        if (type!=null && type.equals("friend")) {
			//处理好友发送消息
        	logger.info("处理好友发送消息,开始!SendMessageModel:{}",model);
        	//1.发送人 未读设置为已阅
        	List<FriendMessage> list = this.getByFormAndToUserId(toUserId,fromUserId);
        	for (FriendMessage fmsg : list) {
				if (fmsg!=null) {
					fmsg.setIsRead(1);
					logger.info("processSendFriendMsg好友消息id:{}已阅",fmsg.getId());
					this.update(fmsg, toUserId);
				}
			}
        	
        	//2.保存发送的信息
        	FriendMessage msg = new FriendMessage();
        	msg.setFromUserId(fromUserId);
        	msg.setContent(content);
        	msg.setToUserId(toUserId);
        	msg.setSendTime(new Date());
        	msg.setIsRead(0);
        	
        	this.add(msg, fromUserId);
		}
        
	}

}
