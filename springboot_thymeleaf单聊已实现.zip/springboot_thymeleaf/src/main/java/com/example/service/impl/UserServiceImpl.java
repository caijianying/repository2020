package com.example.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.bean.Friend;
import com.example.bean.FriendType;
import com.example.bean.User;
import com.example.dao.FriendMapper;
import com.example.dao.UserMapper;
import com.example.model.FriendFormModel;
import com.example.model.FriendGroupModel;
import com.example.service.IFriendService;
import com.example.service.IFriendTypeService;
import com.example.service.IUserService;
import com.example.service.base.BaseServiceImpl;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
@Transactional(readOnly=true)
public class UserServiceImpl extends BaseServiceImpl<UserMapper, User> implements IUserService {

	@Autowired
	IFriendService friendService;
	
	@Autowired
	IFriendTypeService friendTypeService;
	
	@Override
	public FriendFormModel getFriendForm(Long userId) {
		FriendFormModel model = new FriendFormModel();
		List<FriendGroupModel> friend = new ArrayList<>();
		
		
		
		User mine = this.getById(userId);
		
		mine.setStatus(mine.getOnlineState() == 1?"online":"offline");
		mine.setUsername(mine.getNickName());
		List<FriendType> fTypeList = friendTypeService.getByUserId(userId);
		
		for (FriendType t : fTypeList) {
			FriendGroupModel gmodel = new FriendGroupModel();
			List<Friend> list = friendService.getByUserIdAndTypeId(userId,t.getId());
			List<User> ulist = new ArrayList<>();
			for (Friend f : list) {
				User user = this.getById(f.getFriendId());
				user.setUsername(user.getNickName());
				user.setStatus(user.getOnlineState() == 1?"online":"offline");
				ulist.add(user);
			}
			gmodel.setGroupname(t.getTypeName());
			gmodel.setId(t.getId());
			gmodel.setList(ulist);
			
			friend.add(gmodel);
		}
		
		model.setMine(mine);
		model.setFriend(friend);
		
		return model;
	}

	@Override
	public User getByLoginName(String loginName) {
		Example example = new Example(User.class);
		example.createCriteria().andEqualTo("isValid", true).andEqualTo("loginName", loginName);
		return this.getOneByExample(example);
	}

	@Override
	public User getByToken(String token) {
		Example example = new Example(User.class);
		example.createCriteria().andEqualTo("isValid", true).andEqualTo("token", token);
		return this.getOneByExample(example);
	}


}
