package com.example.controller;
 
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.bean.User;
import com.example.model.ResponseData;
import com.github.pagehelper.PageInfo;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

 
@Controller
@RequestMapping(value="")
public class IndexController {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
//	@Autowired
//	IStandardLawService standardLawService;
 
	
	
	@GetMapping(value="index2",produces = "text/plain;charset=utf-8")
	public String index2(ModelMap model) {
		logger.info("《layUI后台》---->《首页》");
		return "index2";
	}
	
	@GetMapping(value="/toForm",produces = "text/plain;charset=utf-8")
	public String getName(ModelMap model) {
		
		return "view_add";
	}
	
	
//	@GetMapping(value="/getList",produces = "text/plain;charset=utf-8")
//	@ResponseBody
//	public String getList(@RequestParam(required = false, value = "page",defaultValue="1")Integer pageIndex
//			,@RequestParam(required = false, value = "limit",defaultValue="10") Integer pageSize) {
//		PageInfo<StandardLaw> pageInfo = standardLawService.getLawList(pageIndex, pageSize);
//		
//		ResponseData<List<StandardLaw>> data = new ResponseData<>();
//		data.setData(pageInfo.getList());
//		data.setCount(pageInfo.getList().size());
//		data.setCode(0);
//		data.setState(ResponseStateEnum.success.getState());
//		data.setMsg(ResponseStateEnum.success.getValue());
//		String str = data.getJsonString();
//		
//		return str;
//
//	}
}
