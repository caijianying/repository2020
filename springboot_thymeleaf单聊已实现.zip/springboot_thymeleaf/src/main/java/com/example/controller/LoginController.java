package com.example.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.bean.User;
import com.example.shiro.ShiroToken;
import com.example.shiro.ShiroUtil;


@Controller
@RequestMapping(value="")
public class LoginController {
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@GetMapping(value="/login",produces = "text/plain;charset=utf-8")
	public String login(ModelMap model) {
		logger.info("《聊天系统登录》");
		ShiroUtil.loginOut();
		return "login";
	}
	
	
	@PostMapping(value="/doLogin")
    public String login(String username, String password){
		logger.info("login----username:{},password:{}",username,password);
        try {
			ShiroUtil.login(username, password);
		} catch (AuthenticationException e) {
			logger.info("登录失败跳转回登录页!");
			 return "redirect:/login";
		}
        return "redirect:/chat";
    }

	@GetMapping(value="index",produces = "text/plain;charset=utf-8")
	public String index(ModelMap model) {
		logger.info("《聊天系统首页》");
		 Subject subject = SecurityUtils.getSubject();
	     User principal = (User)subject.getPrincipal();
	     logger.info(principal.toString());
		return "index";
	}
	
	@GetMapping(value="/chat",produces = "text/plain;charset=utf-8")
	public String chat(ModelMap model) {
		ShiroToken user = ShiroUtil.getShiroToken();
		logger.info(user.toString());
		logger.info("《进入聊天室》,userId={}",user.getUserId());
		model.put("user", user);
		return "chat";
	}
}
