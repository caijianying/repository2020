package com.example.controller;
 
import java.io.File;
import java.io.IOException;
import java.util.List;
 
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
/**
 * 参考网址
 * http://www.open-open.com/jsoup/working-with-urls.htm
 * @author cjy
 *
 */
@RestController
@RequestMapping("Jsoup")
public class JsoupController {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 解析html片段
	 * @return
	 */
	@GetMapping("/parseHtml")
	public String parseHtml() {
		String html = "<html><head><title>First parse</title></head>"
				  + "<body><p>Parsed HTML into a doc.</p></body></html>";
				Document doc = Jsoup.parse(html);
				
				return doc.childNodes().toString();
	}
	
	/**
	 * 解析html文件
	 * @return
	 */
	@GetMapping("/parsePage")
	public String parseWebPage() {
		try {
			///F:\Program Files\IDE\eclipse\workspace\jsoup/src/main/webapp/WEB-INF/views/test/jsoup.html
			File input = new File("F:\\Program Files\\IDE\\eclipse\\workspace\\jsoup/src/main/webapp/WEB-INF/views/test/jsoup.html");
			Document doc = Jsoup.parse(input, "UTF-8", "http://example.com/");
 
			Element content = doc.getElementById("content");
			Elements links = content.getElementsByTag("a");
			logger.info("linkHref,linkText:");
			for (Element link : links) {
			  String linkHref = link.attr("href");
			  String linkText = link.text();
			  logger.info(linkHref+","+linkText);
			}
			return "Parse successfully!";
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return "Parse fail!";
	}
	
	/**
	 * //解析一个body片断
	 * @return
	 */
	@GetMapping("/parseBody")
	public String parseBody() {
		String html = "<div><p>Lorem ipsum.</p>";
		Document doc = Jsoup.parseBodyFragment(html);
		Element body = doc.body();
		
		return body.childNodes().toString();
	}
	
	/**
	 * 从一个URL加载一个Document
	 * @param url 加载的地址
	 */
	@GetMapping("/getByUrl")
	public String getByURL(String url) {
		Document doc;
		String title = null;
		try {
			doc = Jsoup.connect(url).get();
			title = doc.title();
	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return title;
	}
	
	
	
}
