package com.example.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.bean.FriendMessage;
import com.example.bean.GroupMessage;
import com.example.bean.User;
import com.example.enums.ResponseStateEnum;
import com.example.model.FriendFormModel;
import com.example.model.RecieveMsgModel;
import com.example.model.ResponseData;
import com.example.model.SendMessageModel;
import com.example.service.IFriendMessageService;
import com.example.service.IGroupMessageService;
import com.example.service.IUserService;
import com.example.shiro.ShiroUtil;

@RestController
@RequestMapping(value="im")
public class ImController {
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	IUserService userService;
	
	@Autowired
	IFriendMessageService friendMsgService;
	
	@Autowired
	IGroupMessageService groupMsgService;
	
	@ResponseBody
	@GetMapping(value="getUser",produces = "text/plain;charset=utf-8")
	public String getUser() {
		Long userId = ShiroUtil.getUserId();
		logger.info("获取User,userId={}",userId);
		
		ResponseData<FriendFormModel> data = new ResponseData<>();
//		Long userId = 100000l;
		
		if (userId==null) {
			data.setMsg("登录失效!");
			return data.toJsonString();
		}
		FriendFormModel model = userService.getFriendForm(userId);
		
		data.setData(model);
//		data.setCode(0);
//		data.setState(ResponseStateEnum.success.getState());
//		data.setMsg(ResponseStateEnum.success.getValue());
		
		return data.toJsonString();
	}
	
	@ResponseBody
	@PostMapping(value="sign",produces = "text/plain;charset=utf-8")
	public String sign(@RequestParam(value="sign")String sign) {
		logger.info("保存个性签名,sign={}",sign);
		
		ResponseData<Object> data = new ResponseData<>();
		User user = ShiroUtil.getUser();
		user.setSign(sign);
		userService.update(user);
		
		data.setMsg("修改成功!");
		return data.toJsonString();
	}
	
	@ResponseBody
	@PostMapping(value="saveMsg",produces = "text/plain;charset=utf-8")
	public String saveMsg(SendMessageModel model) {
		logger.info("保存聊天记录,model={}",model);
		
		ResponseData<Object> data = new ResponseData<>();
		if (ShiroUtil.getUserId()==null) {
			data.setState(ResponseStateEnum.fail.getState());
			data.setMsg("登录已失效!");
			return data.toJsonString();
		}
		
		
		
		String content = model.getContent();
		Long userId = model.getFromUserId();
		Long toUserId = model.getToUserId();
		String type = model.getType();
		Date now = new Date();
		
		if (type.equals("friend")) {
			FriendMessage msg = new FriendMessage();
			msg.setContent(content);
			msg.setFromUserId(userId);
			msg.setToUserId(toUserId);
			msg.setIsRead(0);
			msg.setSendTime(now);
			msg.setCreateDate(now);
			friendMsgService.add(msg);
		}
		
		if (type.equals("group")) {
			GroupMessage msg = new GroupMessage();
			msg.setContent(content);
			msg.setGroupId(model.getGroupId());
			msg.setUserId(userId);
			msg.setIsRead(0);
			msg.setSendTime(now);
			msg.setCreateDate(now);
			groupMsgService.add(msg, userId);
		}
		
		data.setMsg("修改成功!");
		return data.toJsonString();
	}
	
	@ResponseBody
	@GetMapping(value="getFriendMsg",produces = "text/plain;charset=utf-8")
	public String getFriendMsg(@RequestParam(value="type",defaultValue="")String type) {
		ResponseData<List<RecieveMsgModel>> data = new ResponseData<>();
		if (type==null) {
			data.setState(ResponseStateEnum.fail.getState());
			data.setMsg("参数错误");
			return data.toJsonString();
		}
		if (type.equals("undefined")) {
			type="0";
		}
		User user = ShiroUtil.getUser();
		logger.info("获取好友消息,type={},user={}",type,user);
		
		List<RecieveMsgModel> mlist = new ArrayList<>();
		if (user==null) {
			data.setState(ResponseStateEnum.fail.getState());
			data.setMsg("登录已失效!");
			return data.toJsonString();
		}
		Long userId = user.getId();
		List<FriendMessage> fmsg = friendMsgService.getByFormAndToUserId(null, userId);
		if (fmsg.size()<=0) {
			data.setState(ResponseStateEnum.success.getState());
			return data.toJsonString();
		}
		
		if (fmsg!=null && fmsg.size()>0) {
			
			if (type.equals("1")) {
				for (FriendMessage msg : fmsg) {
					RecieveMsgModel model = new RecieveMsgModel();
					User fromUser = userService.getById(msg.getFromUserId());
					model.setAvatar(fromUser.getAvatar());
					model.setContent(msg.getContent());
					model.setId(fromUser.getId());
					model.setTimestamp(msg.getSendTime().getTime());
					model.setUsername(fromUser.getNickName());
					model.setType("friend");
					
					mlist.add(model);
				}
				
			}
			
			if (type.equals("0")) {
				FriendMessage msg = fmsg.get(0);
				RecieveMsgModel model = new RecieveMsgModel();
				User fromUser = userService.getById(msg.getFromUserId());
				model.setAvatar(fromUser.getAvatar());
				model.setContent(msg.getContent());
				model.setId(fromUser.getId());
				model.setTimestamp(msg.getSendTime().getTime());
				model.setUsername(fromUser.getNickName());
				model.setType("friend");
				
				mlist.add(model);
			}
			
		}
		
		
		
		data.setData(mlist);
		
		return data.toJsonString();
	}
	
	
//	@ResponseBody
//	@GetMapping(value="getCurrentMsg",produces = "text/plain;charset=utf-8")
//	public String getCurrentMsg() {
//		User user = ShiroUtil.getUser();
//		logger.info("获取即时消息,user={}",user);
//		
//		ResponseData<RecieveMsgModel> data = new ResponseData<>();
//		RecieveMsgModel model = new RecieveMsgModel();
//		if (user==null) {
//			data.setState(ResponseStateEnum.fail.getState());
//			data.setMsg("登录已失效!");
//			return data.toJsonString();
//		}
//		Long userId = user.getId();
//		FriendMessage fmsg = friendMsgService.getByToUserId(userId);
//		User fromUser = userService.getById(fmsg.getFromUserId());
//		model.setAvatar(fromUser.getAvatar());
//		model.setContent(fmsg.getContent());
//		model.setId(fromUser.getId());
//		model.setTimestamp(fmsg.getSendTime().getTime());
//		model.setUsername(fromUser.getNickName());
//		model.setType("friend");
//		
//		data.setData(model);
//		data.setState(ResponseStateEnum.success.getState());
//		return data.toJsonString();
//	}
	@ResponseBody
	@PostMapping(value="setHasView",produces = "text/plain;charset=utf-8")
	public String setHasView() {
		logger.info("设置好友消息已阅");
		
		ResponseData<Object> data = new ResponseData<>();
		User user = ShiroUtil.getUser();
		
		if (user==null) {
			data.setState(ResponseStateEnum.fail.getState());
			data.setMsg("登录已失效!");
			return data.toJsonString();
		}
		
		List<FriendMessage> list = friendMsgService.getByFormAndToUserId(null, user.getId());
		FriendMessage msg = list.size()>0?list.get(0):null;
		
		if (msg==null) {
			data.setMsg("无消息!");
			return data.toJsonString();
		}
		
		for (FriendMessage fmsg : list) {
			fmsg.setIsRead(1);
		}
		friendMsgService.updateByBatch(list, user.getId());
		
		data.setMsg("好友消息已阅!");
		return data.toJsonString();
	}
}
