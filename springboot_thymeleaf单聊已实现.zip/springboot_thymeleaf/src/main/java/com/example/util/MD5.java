package com.example.util;

import org.apache.shiro.crypto.hash.SimpleHash;

public class MD5 {
	public static String encode(String str) {
		String encode = (new SimpleHash("MD5", str)).toString();// md5
		return encode;
	}

}
