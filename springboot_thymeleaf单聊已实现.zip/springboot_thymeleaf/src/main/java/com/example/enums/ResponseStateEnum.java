package com.example.enums;

public enum ResponseStateEnum {
	success(0,"操作成功"),
	fail(1,"操作失败"),
	validateError(500,"数据校验错误")
	;
	
	Integer state;
	String value;
	
	private ResponseStateEnum(Integer code,String value) {
		this.state = code;
		this.value = value;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}


	
	
}
