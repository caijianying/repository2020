package com.example.model;

import java.util.List;

import com.example.bean.User;
import com.example.bean.base.BaseBean;

import lombok.Data;
/**
 * 好友列表
 * @author Administrator
 *
 */
public @Data class FriendFormModel extends BaseBean{/**
	 * 
	 */
	private static final long serialVersionUID = 90737128117697212L;
	
	private User mine;
	
	private List<FriendGroupModel> friend;

}
