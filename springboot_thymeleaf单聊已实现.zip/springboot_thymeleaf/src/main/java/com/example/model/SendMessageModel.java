package com.example.model;

import java.io.Serializable;

import lombok.Data;
/**
 * 
 * @author cyj
 * 聊天model
 */
public @Data class SendMessageModel implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = -7019200454884682760L;
	
	private Long fromUserId;
	
	private Long toUserId;
	
	private Long groupId;
	
	private String content;
	
	private String type;
	
	
}
