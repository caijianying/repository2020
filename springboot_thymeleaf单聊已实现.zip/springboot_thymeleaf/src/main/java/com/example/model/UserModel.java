package com.example.model;

import com.example.bean.base.BaseBean;

import lombok.Data;

public @Data class UserModel extends BaseBean {

	
	private static final long serialVersionUID = 6662021403285469908L;

	//***********mine*************
	/**
	 * 是否是自己
	 */
	private static Boolean mine = true;
	
	/**
	 * 当前userId
	 */
	private Long id;
	
	/**
	 * 当前头像
	 */
	private String avatar;
	
	/**
	 * 消息内容
	 */
	private String content;
	//***********to***************
	
	
	/**
	 * 是发送给好友还是群
	 */
	private String type;
	
	//>>>>>>>>好友>>>>>>>>>
	/**
	 * 是否是临时会话
	 */
	private static Boolean temporary = true;
	
	
	//>>>>>>>>群>>>>>>>>>
	
	/**
	 * 群名
	 */
	private String groupname;
	
	/**
	 * 成员数量
	 */
	private Integer members;
	
}
