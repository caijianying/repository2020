package com.example.model;

import java.io.Serializable;

import com.example.enums.ResponseStateEnum;

import lombok.Data;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public @Data class ResponseData<T> implements Serializable {

	private static final long serialVersionUID = -7938363921918692976L;
	
	//状态枚举
	private static ResponseStateEnum codeEnum = ResponseStateEnum.success;
	
	//状态码
	private Integer code = 0;
	
	//提示文本
	private String msg = codeEnum.getValue();
	
	//提示文本
	private Integer count;
	
	//提示文本
	private Integer state = codeEnum.getState();
	
	private T data;
	
	public String toJsonString() {
		JSONArray jsonArray = JSONArray.fromObject(data);
		String str = "{\"code\":0,\"msg\":\"\",\"count\":"+count+",\"data\":"+jsonArray+",\"state\":0}";
		
		JSONObject object = JSONObject.fromObject(str);
		object.put("msg",msg);
		object.put("state",state);
		object.put("data",data);
		object.put("count",count);
		return object.toString();
	}
	
	
	
}
