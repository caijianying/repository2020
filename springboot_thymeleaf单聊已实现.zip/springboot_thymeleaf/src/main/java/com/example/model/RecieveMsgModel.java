package com.example.model;

import java.io.Serializable;

import lombok.Data;

public @Data class RecieveMsgModel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1338546332955279195L;

	/**
	 * username: "贤心"
      ,avatar: "//tp1.sinaimg.cn/1571889140/180/40030060651/1"
      ,id: "100001"
      ,type: "friend"
      ,content: "嗨，你好！欢迎体验LayIM。演示标记："+ new Date().getTime()
      ,timestamp: new Date().getTime()
	 */
	
	private String username;
	
	private String avatar;
	
	private Long id;
	
	private String type;
	
	private String content;
	
	private Long timestamp;
	
	
}
