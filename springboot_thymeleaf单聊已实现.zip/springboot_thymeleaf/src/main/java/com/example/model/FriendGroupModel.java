package com.example.model;

import java.util.List;

import com.example.bean.User;
import com.example.bean.base.BaseBean;

import lombok.Data;
/**
 * 好友分组
 * @author Administrator
 *
 */
public @Data class FriendGroupModel extends BaseBean{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4114204425016913901L;
	
	/**
	 * 好友分组名
	 */
	private String groupname;
	
	/**
	 * 好友分组id
	 * 
	 */
	private Long id;
	
	/**
	 * 分组的好友列表
	 */
	private List<User> list;

}
