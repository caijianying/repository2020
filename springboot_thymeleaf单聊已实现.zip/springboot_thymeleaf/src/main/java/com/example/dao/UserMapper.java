package com.example.dao;

import com.example.bean.User;
import com.example.dao.base.CommonMapper;

public interface UserMapper extends com.example.dao.base.CommonMapper<User> {
   
}