package com.example.dao;

import com.example.bean.Group;
import com.example.dao.base.CommonMapper;

public interface GroupMapper extends com.example.dao.base.CommonMapper<Group> {
   
}