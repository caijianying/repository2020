package com.example.dao;

import com.example.bean.Friend;
import com.example.dao.base.CommonMapper;

public interface FriendMapper extends com.example.dao.base.CommonMapper<Friend> {
  
}