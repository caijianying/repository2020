package com.example.dao;

import com.example.bean.FriendType;
import com.example.dao.base.CommonMapper;

public interface FriendTypeMapper extends com.example.dao.base.CommonMapper<FriendType> {
    
}