package com.example.dao;

import com.example.bean.GroupMessage;
import com.example.dao.base.CommonMapper;

public interface GroupMessageMapper extends com.example.dao.base.CommonMapper<GroupMessage> {
    
}