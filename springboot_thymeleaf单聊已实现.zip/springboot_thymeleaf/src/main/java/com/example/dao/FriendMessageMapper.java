package com.example.dao;

import com.example.bean.FriendMessage;
import com.example.dao.base.CommonMapper;

public interface FriendMessageMapper extends com.example.dao.base.CommonMapper<FriendMessage> {
   
}