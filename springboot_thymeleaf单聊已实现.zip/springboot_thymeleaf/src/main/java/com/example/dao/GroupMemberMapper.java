package com.example.dao;

import com.example.bean.GroupMember;
import com.example.dao.base.CommonMapper;

public interface GroupMemberMapper extends com.example.dao.base.CommonMapper<GroupMember> {
    
}