package com.example.dao.base;

import tk.mybatis.mapper.common.BaseMapper;
import tk.mybatis.mapper.common.ConditionMapper;
import tk.mybatis.mapper.common.ExampleMapper;
import tk.mybatis.mapper.common.IdsMapper;
import tk.mybatis.mapper.common.MySqlMapper;
import tk.mybatis.mapper.common.RowBoundsMapper;

/**
 * 通用Mapper定义
 * @author SHAO
 *
 * @param <T>
 */
public interface CommonMapper<T> extends BaseMapper<T>, ExampleMapper<T>,
RowBoundsMapper<T>, IdsMapper<T>, MySqlMapper<T>, ConditionMapper<T> {

}

