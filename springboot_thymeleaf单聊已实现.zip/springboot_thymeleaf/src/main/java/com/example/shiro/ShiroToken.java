package com.example.shiro;

import org.apache.shiro.authc.UsernamePasswordToken;


import lombok.Data;

/* 这里必须说一下,必须要继承UsernamePasswordToken,因为realm实现中有个suports方法,
 * 会判断token是否被支持,默认的情况下是只支持UsernamePasswordToken的.如需要完全自定义,
 * 则需要单独再realm配置中添加上新的自定义token的类型支持.  
 */
@Data 
public class ShiroToken extends UsernamePasswordToken {

	private static final long serialVersionUID = 2610892782232490764L;

	private Long userId;

	private String avatar;
	
	private String sign;
	
	private String token;
	
	private String nickName;
	
}
