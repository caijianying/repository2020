package com.example.shiro;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.example.bean.User;

public class ShiroUtil {
	static Logger logger = LoggerFactory.getLogger(ShiroUtil.class);
	
	public static ShiroToken getShiroToken() {
		
		Subject subject = SecurityUtils.getSubject();
		ShiroToken principal = (ShiroToken)subject.getPrincipal();
		logger.info("读取缓存,ShiroToken:{}",principal);
		return principal;
	}
	
	public static Long getUserId() {
		
		ShiroToken token = getShiroToken();
		return token==null?null:token.getUserId();
	}
	
	public static User getUser() {
		ShiroToken token = getShiroToken();
		
		if (token == null) return null;
		
		User user = new User();
		user.setAvatar(token.getAvatar());
		user.setId(token.getUserId());
		user.setNickName(token.getNickName());
		user.setToken(token.getToken());
		user.setSign(token.getSign());
		return user;
	}
	
	
	public static void login(String username, String password) {
		UsernamePasswordToken token = new UsernamePasswordToken(username, password,false);
		SecurityUtils.getSubject().login(token);
	}
	
	public static void loginOut() {
	
		SecurityUtils.getSubject().logout();
	}
	
}
