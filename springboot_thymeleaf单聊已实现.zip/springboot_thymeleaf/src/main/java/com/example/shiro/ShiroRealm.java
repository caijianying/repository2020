package com.example.shiro;

import java.util.HashSet;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.bean.User;
import com.example.service.IUserService;
import com.example.util.MD5;


@Component
public class ShiroRealm extends AuthorizingRealm {
	private Logger logger = LogManager.getLogger(this.getClass());
	
	private static ShiroRealm ShiroRealm;
	
	@Autowired
	private IUserService userService;
	
	@PostConstruct 
	public void setShiroRealm() {
		logger.info("配置ShiroRealm工具类，注入Service");
		ShiroRealm= this; 
		ShiroRealm.userService= this.userService; 
	} 

	
	/**
	 * 登陆授权
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		SimpleAuthorizationInfo info =  new SimpleAuthorizationInfo();
		User user = (User)principals.getPrimaryPrincipal();
		logger.info("登陆授权,user={}",user);
		Set<String> roles = new HashSet<>();
		roles.add(user.getPassword());
		info.setRoles(roles);
		
		return info;
	}

	/**
	 * 认证信息，主要针对用户登录， 
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		 String username = (String) token.getPrincipal();
	     String password = new String((char[]) token.getCredentials());
	     logger.info("登录验证,username={},pwd={}",username,password);
	     
	     ShiroToken stoken = new ShiroToken();
	     stoken.setUsername(username);
	     stoken.setPassword(password != null ? password.toCharArray() : null);;
	     
	     User user = ShiroRealm.userService.getByLoginName(username);
	     if (user==null) {
	    	 throw new AuthenticationException("登录失败,该账号不存在!");
	     }else if(!user.getPassword().equals(password)){
	    	 throw new AuthenticationException("登录失败,密码错误!");
	     }else {
	    	 String sign = this.sign(username, password);
	    	 if (sign.equals(user.getToken())) {
	    		 stoken.setUserId(user.getId());
		    	 stoken.setToken(sign);
		    	 stoken.setAvatar(user.getAvatar());
		    	 stoken.setNickName(user.getNickName());
		    	 stoken.setSign(user.getSign());
			}
	    	
//	    	 user.setToken(sign);
//	    	 ShiroRealm.userService.update(user);
	     }
	     
	     
    	
	     logger.info("登录验证成功!");
	     return new SimpleAuthenticationInfo(stoken,password, getName());
	}
	
	@Override
	public String getAuthorizationCacheName() {
		logger.info("getAuthorizationCacheName:"+super.getAuthorizationCacheName());
		return super.getAuthorizationCacheName();
	}

	@Override
	protected AuthorizationInfo getAuthorizationInfo(PrincipalCollection principals) {
		logger.info("principals:"+principals);
		logger.info("getAuthorizationInfo:"+super.getAuthorizationInfo(principals));
		return super.getAuthorizationInfo(principals);
	}

	@Override
	protected Object getAuthorizationCacheKey(PrincipalCollection principals) {
		logger.info("principals:"+principals);
		logger.info("getAuthorizationCacheKey:"+super.getAuthorizationCacheKey(principals));
		return super.getAuthorizationCacheKey(principals);
	}

    /**
     * 清空当前用户权限信息
     */
    public  void clearCachedAuthorizationInfo() {
    	 logger.info("clearCachedAuthorizationInfo");
        PrincipalCollection principalCollection = SecurityUtils.getSubject().getPrincipals();
        SimplePrincipalCollection principals = new SimplePrincipalCollection(
                principalCollection, getName());
        logger.info("principals:"+principals);
        super.clearCachedAuthorizationInfo(principals);
    }
    /**
     * 指定principalCollection 清除
     */
    public void clearCachedAuthorizationInfo(PrincipalCollection principalCollection) {
        SimplePrincipalCollection principals = new SimplePrincipalCollection(
                principalCollection, getName());
        super.clearCachedAuthorizationInfo(principals);
    }

    private String sign(String username,String password) {
    	if (username!=null && password!=null) {
    		return MD5.encode(username+password);
    	}else throw new RuntimeException("数据为空,生成签名失败");
    	
    }
}
