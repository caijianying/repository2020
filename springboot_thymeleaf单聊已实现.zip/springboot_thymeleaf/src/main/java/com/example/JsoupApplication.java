package com.example;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
 
 
@SpringBootApplication
@EnableAutoConfiguration(exclude=DataSourceAutoConfiguration.class)
@ComponentScan(basePackages= {"com.example.*"})
public class JsoupApplication extends SpringBootServletInitializer{
 
	public static Logger logger = LoggerFactory.getLogger(JsoupApplication.class);
	
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		logger.info("《使用外部tomcat配置启动springboot》");
		application.sources(this.getClass());
		return super.configure(application);
	}
	
	public static void main(String[] args) {
		
		SpringApplication.run(JsoupApplication.class, args);
		logger.info("*****************");
		logger.info("与Jsoup整合springboot_thymeleaf启动完成!!");
		logger.info("*****************");
	}
}
