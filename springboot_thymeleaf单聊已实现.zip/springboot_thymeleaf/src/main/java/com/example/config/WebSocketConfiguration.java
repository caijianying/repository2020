//package com.example.config;
//
//import javax.servlet.http.HttpSession;
//import javax.websocket.HandshakeResponse;
//import javax.websocket.server.HandshakeRequest;
//import javax.websocket.server.ServerEndpointConfig;
//import javax.websocket.server.ServerEndpointConfig.Configurator;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.socket.server.standard.ServerEndpointExporter;
//
//@Configuration
//public class WebSocketConfiguration extends Configurator{
//
//	private Logger logger = LogManager.getLogger(this.getClass());
//	
//	@Autowired
//	private RequestListener requestListener;
//	
//	@Bean
//    public ServerEndpointExporter serverEndpointExporter() {
//		logger.info("注册ServerEndpointExporter");
//        return new ServerEndpointExporter();
//    }
//	
//	@Bean
//    public ServletListenerRegistrationBean<RequestListener> servletListenerRegistrationBean() {
//		logger.info("配置request监听器ServletListenerRegistrationBean");
//        ServletListenerRegistrationBean<RequestListener> servletListenerRegistrationBean = new ServletListenerRegistrationBean<>();
//        servletListenerRegistrationBean.setListener(requestListener);
//        return servletListenerRegistrationBean;
//    }
// 
//	@Override
//	public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response) {
//		// TODO Auto-generated method stub
//		HttpSession httpSession = (HttpSession) request.getHttpSession();
//		
//		sec.getUserProperties().put(HttpSession.class.getName(), httpSession);
//		logger.info("session参数:"+sec.getUserProperties());
////		super.modifyHandshake(sec, request, response);
//	}
//}
