package com.example.config;
//package com.example.jsoup.config;
//
//
//import javax.servlet.ServletContextEvent;
//import javax.servlet.ServletContextListener;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.HandlerInterceptor;
//import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
//import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
//
// 
///**
// * 
// * @author cjy
// *
// */
//@Configuration
//public class WebConfiguration extends WebMvcConfigurationSupport{
// 
//	private Logger logger = LogManager.getLogger(this.getClass());
//	
//	@Override
//	protected void addInterceptors(InterceptorRegistry registry) {
//		logger.info("《配置拦截器》");
//		registry.addInterceptor(getLogInterceptor()).addPathPatterns("/**");
//		super.addInterceptors(registry);
//	}
//    @Override
//    public void addResourceHandlers(ResourceHandlerRegistry registry) {
//    	logger.info("《配置静态资源访问》");
//		registry.addResourceHandler("/static/**").addResourceLocations("/static/").setCachePeriod(31536000);
//		registry.addResourceHandler("/upload/**").addResourceLocations("/upload/").setCachePeriod(31536000);
//        super.addResourceHandlers(registry);
//    }
//    
//    /**
//	 * 日志拦截器
//	 * @Comments:  <对此方法的描述，可以引用系统设计中的描述>
//	 * @author JannyShao(邵建义) [ksgameboy@qq.com]
//	 * @since 2018年5月3日-上午11:22:43
//	 * @return
//	 */
//	@Bean
//	public HandlerInterceptor getLogInterceptor() {
//		return new HandlerInterceptor() {
//		};
//	}
//
//}
