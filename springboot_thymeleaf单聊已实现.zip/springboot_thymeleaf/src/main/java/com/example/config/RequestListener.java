//package com.example.config;
//
//import javax.servlet.ServletRequestEvent;
//import javax.servlet.ServletRequestListener;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.stereotype.Component;
//
//import com.example.shiro.ShiroUtil;
//
///**
// * 
// * @author Administrator
// *由于HTTP协议与websocket协议的不同，导致没法直接从websocket中获取协议，
// *然后在 WebSocketConfiguration 中我们已经写了获取HttpSession的代码，
// *但是如果真的放出去执行，那么会报空指值异常，因为这个HttpSession并没有设置进去。
// */
//@Component
//public class RequestListener implements ServletRequestListener {
//	private Logger logger = LogManager.getLogger(this.getClass());
//	
//	@Override
//	public void requestInitialized(ServletRequestEvent sre) {
//		logger.info("requestInitialized设置HttpSession");
//		 //将所有request请求都携带上httpSession
//       HttpSession session = ((HttpServletRequest) sre.getServletRequest()).getSession();
//       logger.info(session);
//	}
//	
//	@Override
//	public void requestDestroyed(ServletRequestEvent sre) {
//	}
//
//
//}
