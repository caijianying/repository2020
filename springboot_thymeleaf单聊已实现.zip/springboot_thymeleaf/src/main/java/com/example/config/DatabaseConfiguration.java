/**
 * 
 */
package com.example.config;

import java.io.IOException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.alibaba.druid.pool.DruidDataSource;


/**
 * 《数据库相关配置类》
 * 
 * 
 * @Module ID:   <(模块)类编号，可以引用系统设计中的类编号>
 * @Comments:  <对此类的描述，可以引用系统设计中的描述>
 * @JDK version used:      <JDK1.8> 
 * @author JannyShao(邵建义) [ksgameboy@qq.com]
 * @since 2018年6月1日-下午3:31:23
 */
@Configuration
@PropertySources({
@PropertySource("classpath:application.properties")})
public class DatabaseConfiguration {

	private Logger logger = LogManager.getLogger(this.getClass());
	
	@Value("${jdbc.driver}")
	private String driverName;
	
	@Value("${jdbc.url}")
	private String url;
	

	@Value("${jdbc.username}")
	private String userName;
	

	@Value("${jdbc.password}")
	private String pwd;
	
	@Bean("dataSource")
	public DruidDataSource getDruidDataSource() {
		logger.info("配置  dataSource jdbc_url={}", url);
		DruidDataSource dataSource = new DruidDataSource();
//		<!-- 数据源驱动类可不写，Druid默认会自动根据URL识别DriverClass -->
//	    <property name="driverClassName" value="${jdbc.driver}" />
		dataSource.setDriverClassName(driverName);
//		<!-- 基本属性 url、user、password -->
//		<property name="url" value="${jdbc.url}" />
		dataSource.setUrl(url);
//		<property name="username" value="${jdbc.username}" />
		dataSource.setUsername(userName);
//		<property name="password" value="${jdbc.password}" />
		dataSource.setPassword(pwd);
//		<!-- 配置初始化大小、最小、最大 -->
//		<property name="initialSize" value="${jdbc.pool.init}" />
//		dataSource.setInitialSize(dbproperties.getPool_init());
//		<property name="minIdle" value="${jdbc.pool.minIdle}" /> 
//		dataSource.setMinIdle(dbproperties.getPool_minIdle());
//		<property name="maxActive" value="${jdbc.pool.maxActive}" />
//		dataSource.setMaxActive(dbproperties.getPool_maxActive());
//		<!-- 配置获取连接等待超时的时间 -->
//		<property name="maxWait" value="60000" />
		dataSource.setMaxWait(60000);
//		<!-- 配置间隔多久才进行一次检测，检测需要关闭的空闲连接，单位是毫秒 -->
//		<property name="timeBetweenEvictionRunsMillis" value="60000" />
		dataSource.setTimeBetweenEvictionRunsMillis(60000);
//		<!-- 配置一个连接在池中最小生存的时间，单位是毫秒 -->
//		<property name="minEvictableIdleTimeMillis" value="300000" />
		dataSource.setMinEvictableIdleTimeMillis(300000);

//		<!-- 打开PSCache，并且指定每个连接上PSCache的大小（Oracle使用）
//		<property name="poolPreparedStatements" value="true" />
		dataSource.setPoolPreparedStatements(true);
//		<property name="maxPoolPreparedStatementPerConnectionSize" value="20" /> -->
		dataSource.setMaxPoolPreparedStatementPerConnectionSize(20);
//		<!-- 配置监控统计拦截的filters -->
//	    <property name="filters" value="stat" /> 
		
		return dataSource;
	}
	
	@Bean("sqlSessionFactory")
	public org.mybatis.spring.SqlSessionFactoryBean getSqlSessionFactory(@Qualifier("dataSource") DataSource dataSource) throws IOException{
		logger.info("配置 SqlSessionFactoryBean");
		SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
		sqlSessionFactory.setConfigLocation(new ClassPathResource("mybatis/sqlMapConfig.xml"));
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		sqlSessionFactory.setMapperLocations(resolver.getResources("mapper/*Mapper.xml"));
		sqlSessionFactory.setDataSource(dataSource);
		sqlSessionFactory.setTypeAliasesPackage("com.example.bean.*");
		return sqlSessionFactory;
	}

	
	@Bean("transactionManager")
	public DataSourceTransactionManager getDataSourceTransactionManager(@Qualifier("dataSource") DataSource dataSource) {
		logger.info("配置  定义事务");
		DataSourceTransactionManager transactionManager =  new DataSourceTransactionManager();
		transactionManager.setDataSource(dataSource);
		return transactionManager;
	}

	
	
	

}
