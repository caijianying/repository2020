/**
 * 
 */
package com.example.config;

import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.dao.base.CommonMapper;

import tk.mybatis.spring.mapper.MapperScannerConfigurer;

/**
 * 《MapperScanner	通用Mapper配置，扫描》
 * 
 * 
 * @Module ID:   <(模块)类编号，可以引用系统设计中的类编号>
 * @Comments:  <对此类的描述，可以引用系统设计中的描述>
 * @JDK version used:      <JDK1.8> 
 * @author JannyShao(邵建义) [ksgameboy@qq.com]
 * @since 2018年8月29日-下午12:01:58
 */
@Configuration
@AutoConfigureAfter
public class MapperScannerConfiguration{
	private Logger logger = LogManager.getLogger(this.getClass());
	
	@Bean
	public MapperScannerConfigurer getMapperScannerConfigurer() {
		logger.info("配置 自动扫描Mapper {}, ORDER:{}", "com.example.dao", "BEFORE");
		MapperScannerConfigurer scanner  = new MapperScannerConfigurer();
		scanner.setBasePackage("com.example.dao");
		scanner.setMarkerInterface(CommonMapper.class);
		scanner.setSqlSessionFactoryBeanName("sqlSessionFactory");
		 Properties pro=new Properties();  
		 pro.setProperty("mappers", CommonMapper.class.getName());
		 pro.setProperty(" IDENTITY", "select RIGHT(uuid_short(), 19)");
		 pro.setProperty("ORDER", "BEFORE");
		 scanner.setProperties(pro); 
		return scanner;
	}
}
