package com.example.config;
//package com.example.jsoup.config;
//
//import javax.servlet.ServletContextEvent;
//import javax.servlet.ServletContextListener;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.PropertySource;
//import org.springframework.context.annotation.PropertySources;
//import org.springframework.stereotype.Component;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
//import org.thymeleaf.TemplateEngine;
//import org.thymeleaf.templateresolver.ServletContextTemplateResolver;
//
//@Component
//@Configuration
//@PropertySources({
//	@PropertySource("classpath:application.properties")})
//public class ThymeleafConfiguration extends WebMvcConfigurationSupport implements ServletContextListener{
//
//	private Logger logger = LogManager.getLogger(this.getClass());
//	
//	private static TemplateEngine templateEngine;
//	
//	/**
//	 * thymeleaf配置
//	 */
//	@Value("${spring.thymeleaf.encoding}")
//	private String characterEncoding;
//    
//    @Value("${spring.thymeleaf.content-type}")
//    private String contentType;
//    
//    @Value("${spring.thymeleaf.mode}")
//    private String mode;
// 
//    
//    @Value("${spring.thymeleaf.prefix}")
//    private String prefix;
//    
//    @Value("${spring.thymeleaf.suffix}")
//    private String suffix;
//
//	@Override
//	public void contextDestroyed(ServletContextEvent arg0) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void contextInitialized(ServletContextEvent arg0) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Bean
//	public ServletContextTemplateResolver getServletContextTemplateResolver() {
//		logger.info("配置ServletContextTemplateResolver,prefix:{}，suffix:{}",prefix,suffix);
//		ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(getServletContext());
//		 templateResolver.setSuffix(suffix);
//	        templateResolver.setPrefix(prefix);
//	        templateResolver.setTemplateMode(mode);
//	        templateResolver.setCacheable(false);
//	        templateResolver.setCharacterEncoding(characterEncoding);
//	        templateResolver.setOrder(0);
//	        return templateResolver;
//	}
//	
//	@Bean
//	public TemplateEngine getTemplateEngine() {
//		logger.info("配置TemplateEngine");
//		templateEngine = new TemplateEngine();
//		templateEngine.setTemplateResolver(getServletContextTemplateResolver());
//		return templateEngine;
//	} 
//
//}
